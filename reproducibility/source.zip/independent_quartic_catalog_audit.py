#!/usr/bin/env python3
"""Independent exact/ball audit of the complete retained quartic catalog.

This verifier deliberately avoids the generator's recursive Schur transform,
hand-written reducibility search, and rational Sturm implementation:

* strict disk stability uses the Schur-Cohn Hermitian determinant criterion;
* irreducibility uses FLINT factorization;
* real-root classification uses certified Arb complex-root balls.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import time

import flint
from flint import arb, ctx, fmpz_poly

sys.set_int_max_str_digits(0)

R_NUM = 143
R_DEN = 50
BOUNDS = (9, 28, 35, 11)


def determinant(matrix: list[list[int]]) -> int:
    """Fraction-free Bareiss determinant."""
    n = len(matrix)
    if n == 1:
        return matrix[0][0]
    work = [row[:] for row in matrix]
    sign = 1
    previous = 1
    for k in range(n - 1):
        if work[k][k] == 0:
            swap = next((i for i in range(k + 1, n) if work[i][k]), None)
            if swap is None:
                return 0
            work[k], work[swap] = work[swap], work[k]
            sign = -sign
        pivot = work[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                work[i][j] = (
                    work[i][j] * pivot - work[i][k] * work[k][j]
                ) // previous
        previous = pivot
    return sign * work[-1][-1]


def strict_schur_cohn(s3: int, s2: int, s1: int, s0: int) -> bool:
    coefficients = [
        R_NUM**4,
        s3 * R_NUM**3 * R_DEN,
        s2 * R_NUM**2 * R_DEN**2,
        s1 * R_NUM * R_DEN**3,
        s0 * R_DEN**4,
    ]
    n = 4
    forward = [
        [coefficients[i - j] if i >= j else 0 for j in range(n)]
        for i in range(n)
    ]
    reversed_coefficients = coefficients[::-1]
    reverse = [
        [reversed_coefficients[i - j] if i >= j else 0 for j in range(n)]
        for i in range(n)
    ]
    hermitian = [
        [
            sum(
                forward[i][k] * forward[j][k]
                - reverse[i][k] * reverse[j][k]
                for k in range(n)
            )
            for j in range(n)
        ]
        for i in range(n)
    ]
    for size in range(1, n + 1):
        if determinant([row[:size] for row in hermitian[:size]]) <= 0:
            return False
    return True


def irreducible(poly: fmpz_poly) -> bool:
    content, factors = poly.factor()
    return (
        content == 1
        and len(factors) == 1
        and factors[0][0] == poly
        and factors[0][1] == 1
    )


def certified_real_roots(poly: fmpz_poly):
    for precision in (128, 256, 512):
        ctx.prec = precision
        roots = poly.complex_roots()
        if sum(multiplicity for _, multiplicity in roots) != 4:
            continue
        if any(multiplicity != 1 for _, multiplicity in roots):
            continue
        real = []
        decisive = True
        for root, _ in roots:
            if root.imag.is_zero():
                x = root.real
                if (
                    x.contains(0)
                    or x.contains(arb(1) / 2)
                    or x.contains(-2)
                ):
                    decisive = False
                    break
                real.append(x)
            elif root.imag.contains(0):
                decisive = False
                break
        if decisive:
            return sorted(real, key=lambda value: float(value.mid()))
    raise RuntimeError(f"could not certify roots for {poly}")


def interval_contains(ball, left: str, right: str) -> bool:
    left_fraction = Fraction(left)
    right_fraction = Fraction(right)
    lo = arb(left_fraction.numerator) / left_fraction.denominator
    hi = arb(right_fraction.numerator) / right_fraction.denominator
    return ball > lo and ball < hi


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--catalog", type=Path, default=Path("quartic_norm_sieve_exact.json")
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("independent_quartic_catalog_audit.json"),
    )
    args = parser.parse_args()
    started = time.time()
    raw_bytes = args.catalog.read_bytes()
    retained = json.loads(raw_bytes)
    retained_items = retained["candidate_catalog"]
    retained_by_polynomial = {
        tuple(item["minimal_polynomial_coefficients"]): item
        for item in retained_items
    }
    counts = {
        "raw_nonzero_constant": 0,
        "strict_schur_disk": 0,
        "irreducible": 0,
        "target_root": 0,
        "real_conjugate_sieve": 0,
    }
    accepted = []
    accepted_target_root_total = 0
    interval_failures = []
    for s3 in range(-BOUNDS[0], BOUNDS[0] + 1):
        for s2 in range(-BOUNDS[1], BOUNDS[1] + 1):
            for s1 in range(-BOUNDS[2], BOUNDS[2] + 1):
                for s0 in range(-BOUNDS[3], BOUNDS[3] + 1):
                    if s0 == 0:
                        continue
                    counts["raw_nonzero_constant"] += 1
                    if not strict_schur_cohn(s3, s2, s1, s0):
                        continue
                    counts["strict_schur_disk"] += 1
                    polynomial = fmpz_poly([s0, s1, s2, s3, 1])
                    if not irreducible(polynomial):
                        continue
                    counts["irreducible"] += 1
                    real_roots = certified_real_roots(polynomial)
                    target_roots = [
                        root for root in real_roots if root > 0 and root < arb(1) / 2
                    ]
                    if not target_roots:
                        continue
                    counts["target_root"] += 1
                    if any(root < -2 for root in real_roots):
                        continue
                    counts["real_conjugate_sieve"] += 1
                    accepted_target_root_total += len(target_roots)
                    key = (s3, s2, s1, s0)
                    accepted.append(key)
                    retained_item = retained_by_polynomial.get(key)
                    if retained_item is None:
                        interval_failures.append({"polynomial": key, "reason": "missing"})
                        continue
                    intervals = retained_item["target_root_intervals"]
                    if retained_item["target_root_count"] != len(target_roots):
                        interval_failures.append(
                            {"polynomial": key, "reason": "target_count"}
                        )
                        continue
                    for root, interval in zip(target_roots, intervals):
                        if not interval_contains(
                            root, interval["left"], interval["right"]
                        ):
                            interval_failures.append(
                                {"polynomial": key, "reason": "interval"}
                            )
        print(
            f"s3={s3}; accepted={len(accepted)}; counts={counts}; "
            f"elapsed={time.time()-started:.1f}s",
            flush=True,
        )

    retained_order = [
        tuple(item["minimal_polynomial_coefficients"]) for item in retained_items
    ]
    report = {
        "schema_version": 1,
        "proof_status": "independent_exact_schur_cohn_flint_arb_audit",
        "methods": {
            "disk": "exact Schur-Cohn Hermitian leading-principal minors",
            "irreducibility": "FLINT exact factorization",
            "roots": "Arb certified complex-root balls",
        },
        "environment": {
            "python": sys.version.split()[0],
            "python_flint": flint.__version__,
            "arb_precision_bits": [128, 256, 512],
        },
        "catalog_sha256": hashlib.sha256(raw_bytes).hexdigest(),
        "counts": counts,
        "retained_counts": retained["counts"],
        "accepted_polynomial_count": len(accepted),
        "accepted_target_root_count": accepted_target_root_total,
        "retained_polynomial_count": len(retained_order),
        "accepted_order_matches_retained": accepted == retained_order,
        "accepted_set_matches_retained": set(accepted) == set(retained_order),
        "interval_failures": interval_failures,
        "status": "PASS"
        if counts == retained["counts"]
        and accepted == retained_order
        and accepted_target_root_total == 6982
        and not interval_failures
        else "FAIL",
        "elapsed_seconds": time.time() - started,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(report, indent=2), flush=True)
    if report["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
