#!/usr/bin/env python3
"""Independent exact sign audit for the five-block safe-lattice proof.

Every analytic sign claim is reduced to an exact rational Sturm certificate
or to the displayed Taylor-remainder comparison.  The finite exceptional
pairs are checked independently by primitive reduction and gcd computation
over a degree-preserving prime field.  Output is canonical UTF-8/LF.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import sympy as sp


T = sp.Symbol("t")
HALF = sp.Rational(1, 2)

INTERVALS = {
    1: (sp.Rational(248, 1000), sp.Rational(250, 1000)),
    3: (sp.Rational(249, 1000), sp.Rational(251, 1000)),
    5: (sp.Rational(279, 1000), sp.Rational(280, 1000)),
    7: (sp.Rational(310, 1000), sp.Rational(312, 1000)),
    9: (sp.Rational(340, 1000), sp.Rational(341, 1000)),
    11: (sp.Rational(367, 1000), sp.Rational(368, 1000)),
    13: (sp.Rational(392, 1000), sp.Rational(393, 1000)),
    15: (sp.Rational(415, 1000), sp.Rational(416, 1000)),
    17: (sp.Rational(435, 1000), sp.Rational(437, 1000)),
    19: (sp.Rational(454, 1000), sp.Rational(456, 1000)),
    21: (sp.Rational(472, 1000), sp.Rational(474, 1000)),
    23: (sp.Rational(488, 1000), sp.Rational(490, 1000)),
}

EVEN_EXCEPTION_CASES = (
    (5, 0),
    (5, 2),
    (7, 0),
    (9, 0),
    (11, 0),
    (13, 0),
    (15, 0),
)
ODD_EXCEPTION_CASES = ((5, 1), (7, 1), (9, 1), (11, 1))


def partial(k: int, m: int) -> sp.Expr:
    return sp.expand(
        sum((-1) ** ell * sp.binomial(k + ell, ell) * T**ell for ell in range(m + 1))
    )


def minimum_v(offset: int) -> int:
    return 13 if offset == 1 else max(5, offset + 2)


def numerator(expr: sp.Expr) -> sp.Poly:
    num, den = sp.cancel(expr).as_numer_denom()
    den_poly = sp.Poly(den, T, domain=sp.QQ)
    assert den_poly.count_roots(0, HALF) == 0
    return sp.Poly(num, T, domain=sp.QQ)


def certify_sign(
    name: str,
    expr: sp.Expr,
    left: sp.Rational,
    right: sp.Rational,
    expected_sign: int,
) -> dict[str, object]:
    poly = numerator(expr)
    root_count = int(poly.count_roots(left, right))
    left_value = sp.factor(expr.subs(T, left))
    right_value = sp.factor(expr.subs(T, right))
    assert root_count == 0
    assert sp.sign(left_value) == expected_sign
    assert sp.sign(right_value) == expected_sign
    return {
        "name": name,
        "interval": [str(left), str(right)],
        "expected_sign": expected_sign,
        "numerator_degree": int(poly.degree()),
        "sturm_root_count": root_count,
        "left_value": str(left_value),
        "right_value": str(right_value),
    }


def build_sign_certificates() -> list[dict[str, object]]:
    certificates: list[dict[str, object]] = []

    # These lower envelopes cover s=0,2,4,6 after the listed finite cases.
    for offset, v0 in ((0, 17), (2, 7), (4, 5), (6, 7)):
        lower = (
            (1 + T) ** -2
            + partial(3, 3 * v0 + offset)
            + (1 + T) ** -6
            + partial(7, v0 + offset)
            + partial(9, offset)
        )
        certificates.append(
            certify_sign(f"even_offset_{offset}_lower", lower, 0, HALF, 1)
        )

    # Odd offsets at least 25 have a positive monotone lower envelope.
    late_odd = (
        partial(1, 133)
        + (1 + T) ** -4
        + partial(5, 79)
        + (1 + T) ** -8
        + partial(9, 25)
    )
    certificates.append(
        certify_sign("odd_offsets_at_least_25_lower", late_odd, 0, HALF, 1)
    )

    # The remaining uniform roots are confined to twelve rational intervals.
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = (
            partial(1, 4 * v0 + offset)
            + (1 + T) ** -4
            + partial(5, 2 * v0 + offset)
            + (1 + T) ** -8
            + partial(9, offset)
        )
        upper = (
            (1 + T) ** -2
            + partial(3, 3 * v0 + offset)
            + (1 + T) ** -6
            + partial(7, v0 + offset)
            + partial(9, offset)
        )
        certificates.append(
            certify_sign(f"offset_{offset}_lower_before_alpha", lower, 0, alpha, 1)
        )
        certificates.append(
            certify_sign(f"offset_{offset}_upper_after_beta", upper, beta, HALF, -1)
        )

    # Bounds for E_(5v+s), the even-event companion.
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        if offset == 1:
            companion = (
                (1 + T) ** -1
                - T
                * (
                    partial(2, 4 * v0)
                    + (1 + T) ** -5
                    + partial(6, 2 * v0)
                    + (1 + T) ** -9
                    + 1
                )
            )
            expected = 1
            name = "offset_1_even_companion_lower"
        else:
            companion = (
                (1 + T ** (5 * v0 + offset + 1)) / (1 + T)
                - T
                * (
                    (1 + T) ** -3
                    + partial(4, 3 * v0 + offset - 1)
                    + (1 + T) ** -7
                    + partial(8, v0 + offset - 1)
                    + partial(10, offset - 1)
                )
            )
            expected = -1
            name = f"offset_{offset}_even_companion_upper"
        certificates.append(certify_sign(name, companion, alpha, beta, expected))
    return certificates


def even_tail_comparison() -> dict[str, object]:
    """Exact base and monotonicity data for every even offset s >= 8."""
    s = sp.Symbol("s")
    a9 = sp.prod(s + i for i in range(2, 11)) / sp.factorial(9)
    a7 = sp.prod(2 * s + i for i in range(3, 10)) / sp.factorial(7)
    a3 = sp.prod(4 * s + i for i in range(5, 8)) / sp.factorial(3)
    r7 = a7 / a9 * 2 * (s + 2) / (s - 7) / 2 ** (s + 1)
    r3 = a3 / a9 * 2 * (s + 2) / (s - 7) / 2 ** (3 * s + 3)
    base = sp.factor((r7 + r3).subs(s, 8))
    assert base < 1

    ratio7 = sp.cancel(r7.subs(s, s + 2) / r7)
    ratio3 = sp.cancel(r3.subs(s, s + 2) / r3)
    num7 = sp.Poly(sp.together(1 - ratio7).as_numer_denom()[0].subs(s, s + 8), s)
    num3 = sp.Poly(sp.together(1 - ratio3).as_numer_denom()[0].subs(s, s + 8), s)
    assert all(coefficient > 0 for coefficient in num7.all_coeffs())
    assert all(coefficient > 0 for coefficient in num3.all_coeffs())
    return {
        "base_offset": 8,
        "normalized_negative_tail_sum_at_base": str(base),
        "base_strictly_below_one": True,
        "r7_step_ratio_strictly_below_one_for_s_at_least_8": True,
        "r3_step_ratio_strictly_below_one_for_s_at_least_8": True,
        "shifted_one_minus_r7_step_ratio_numerator_coefficients_descending": [
            int(value) for value in num7.all_coeffs()
        ],
        "shifted_one_minus_r3_step_ratio_numerator_coefficients_descending": [
            int(value) for value in num3.all_coeffs()
        ],
    }


ZERO = sp.Poly(0, T, domain=sp.ZZ)
ONE = sp.Poly(1, T, domain=sp.ZZ)


def sequences(v: int, limit: int) -> tuple[list[sp.Poly], list[sp.Poly]]:
    r = [ZERO for _ in range(limit + 1)]
    even = [ZERO for _ in range(limit + 1)]
    for m in range(limit + 1):
        value = ONE
        if m >= 1:
            value -= sp.Poly(2 * T, T, domain=sp.ZZ) * r[m - 1]
        if m >= 2:
            value -= sp.Poly(T**2, T, domain=sp.ZZ) * r[m - 2]
        if m >= v:
            value += r[m - v]
        r[m] = value

        evalue = ONE
        if m >= 1:
            evalue -= sp.Poly(T, T, domain=sp.ZZ) * r[m - 1]
        if m >= 2:
            evalue -= sp.Poly(T**2, T, domain=sp.ZZ) * r[m - 2]
        even[m] = evalue
    return r, even


def finite_exception_gcd_certificates() -> list[dict[str, object]]:
    certificates = []
    for v, offset in EVEN_EXCEPTION_CASES + ODD_EXCEPTION_CASES:
        r, even = sequences(v, 6 * v + 2)
        j = 4 * v + offset
        for companion_name, companion in (("odd", even[j + 2]), ("even", even[j + v])):
            prime = 11 if (v, offset) == (5, 0) or (
                (v, offset, companion_name) == (5, 2, "even")
            ) else 7
            left = r[j]
            assert left.content() == 1 and companion.content() == 1
            left_mod = sp.Poly(left.as_expr(), T, modulus=prime)
            right_mod = sp.Poly(companion.as_expr(), T, modulus=prime)
            assert left_mod.degree() == left.degree()
            assert right_mod.degree() == companion.degree()
            gcd_poly = sp.gcd(left_mod, right_mod).monic()
            assert gcd_poly.degree() == 0 and gcd_poly.as_expr() == 1
            certificates.append(
                {
                    "v": v,
                    "offset": offset,
                    "j": j,
                    "companion": companion_name,
                    "prime": prime,
                    "left_primitive": True,
                    "right_primitive": True,
                    "left_degree": int(left.degree()),
                    "right_degree": int(companion.degree()),
                    "degrees_preserved_mod_p": True,
                    "gcd_degree_mod_p": 0,
                    "gcd_monic_mod_p": "1",
                }
            )
    return certificates


def build_report() -> dict[str, object]:
    signs = build_sign_certificates()
    gcds = finite_exception_gcd_certificates()
    tail = even_tail_comparison()
    assert len(signs) == 41 and len(gcds) == 22
    return {
        "schema_version": 1,
        "line_ending_and_hash_convention": "UTF-8 bytes with canonical LF newlines",
        "proof_status": "independent_exact_audit_supporting_uniform_five_block_manuscript_proof",
        "theorem": {
            "odd_first_escape_index_at_least": "11*v+4",
            "even_first_escape_index_at_least": "12*v+2",
            "scope": "odd v>=5 and 0<t<1/2",
        },
        "sign_certificate_count": len(signs),
        "all_sign_root_counts_zero": all(item["sturm_root_count"] == 0 for item in signs),
        "even_tail_comparison": tail,
        "finite_exception_modular_gcd_certificate_count": len(gcds),
        "sign_certificates": signs,
        "finite_exception_modular_gcd_certificates": gcds,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path("predecessor_five_block_signs_exact.json")
    )
    args = parser.parse_args()
    report = build_report()
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(
        "PASS: five-block audit with "
        f"{report['sign_certificate_count']} exact sign certificates and "
        f"{report['finite_exception_modular_gcd_certificate_count']} modular gcd certificates"
    )
    print(f"wrote canonical LF bytes to {args.output}")


if __name__ == "__main__":
    main()
