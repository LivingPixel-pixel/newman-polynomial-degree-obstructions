#!/usr/bin/env python3
"""Independent exact verifier for the 126-entry uniform cubic catalog.

This script does not import the original degree-75 search generator and does
not use its obsolete Farkas corpus.  It re-enumerates every monic cubic in the
uniform coefficient box, applies generic Fraction-based Sturm and Schur tests,
and compares the resulting ordered catalog and exact certificates with the
retained JSON used by the global recurrence proof.
"""

from __future__ import annotations

from fractions import Fraction
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "cubic_gap2_degree75_results.json"
DISK_BOUND = Fraction(143, 50)
MAX_WIDTH = Fraction(1, 2**36)
REAL_LOWER = Fraction(-2)
BOUNDS = (8, 24, 23)
EXPECTED = {
    "raw_nonzero_constant_candidates": 38318,
    "irreducible_candidates": 35484,
    "exact_target_root_candidates": 4550,
    "exact_disk_sieve_candidates": 137,
    "exact_real_conjugate_sieve_candidates": 126,
}


def parse_fraction(text: str) -> Fraction:
    return Fraction(text)


def fraction_text(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def trim(poly: list[Fraction]) -> list[Fraction]:
    while len(poly) > 1 and poly[-1] == 0:
        poly.pop()
    return poly


def derivative(poly: list[Fraction]) -> list[Fraction]:
    return [Fraction(i) * poly[i] for i in range(1, len(poly))] or [Fraction(0)]


def divmod_poly(a: list[Fraction], b: list[Fraction]) -> tuple[list[Fraction], list[Fraction]]:
    remainder = trim(a.copy())
    divisor = trim(b.copy())
    quotient = [Fraction(0)] * max(1, len(remainder) - len(divisor) + 1)
    while remainder != [0] and len(remainder) >= len(divisor):
        shift = len(remainder) - len(divisor)
        factor = remainder[-1] / divisor[-1]
        quotient[shift] += factor
        for index, coefficient in enumerate(divisor):
            remainder[index + shift] -= factor * coefficient
        trim(remainder)
    return trim(quotient), trim(remainder)


def sturm(poly: list[Fraction]) -> list[list[Fraction]]:
    sequence = [poly, derivative(poly)]
    while True:
        _, remainder = divmod_poly(sequence[-2], sequence[-1])
        if remainder == [0]:
            return sequence
        sequence.append([-value for value in remainder])


def evaluate(poly: list[Fraction], point: Fraction) -> Fraction:
    value = Fraction(0)
    for coefficient in reversed(poly):
        value = value * point + coefficient
    return value


def variations(sequence: list[list[Fraction]], point: Fraction) -> int:
    signs: list[int] = []
    for poly in sequence:
        value = evaluate(poly, point)
        if value:
            signs.append(1 if value > 0 else -1)
    return sum(left != right for left, right in zip(signs, signs[1:]))


def root_count(sequence: list[list[Fraction]], left: Fraction, right: Fraction) -> int:
    return variations(sequence, left) - variations(sequence, right)


def isolate(sequence: list[list[Fraction]], left: Fraction, right: Fraction) -> list[tuple[Fraction, Fraction]]:
    pending = [(left, right, root_count(sequence, left, right))]
    isolated: list[tuple[Fraction, Fraction]] = []
    while pending:
        lo, hi, count = pending.pop()
        if count == 0:
            continue
        if count == 1 and hi - lo <= MAX_WIDTH:
            isolated.append((lo, hi))
            continue
        mid = (lo + hi) / 2
        left_count = root_count(sequence, lo, mid)
        right_count = count - left_count
        if right_count:
            pending.append((mid, hi, right_count))
        if left_count:
            pending.append((lo, mid, left_count))
    return sorted(isolated)


def reducible(s2: int, s1: int, s0: int) -> bool:
    for divisor in range(1, abs(s0) + 1):
        if s0 % divisor:
            continue
        for root in (divisor, -divisor):
            if root**3 + s2 * root**2 + s1 * root + s0 == 0:
                return True
    return False


def schur_margins(s2: int, s1: int, s0: int) -> list[str] | None:
    radius = DISK_BOUND
    coefficients = [
        radius**3,
        Fraction(s2) * radius**2,
        Fraction(s1) * radius,
        Fraction(s0),
    ]
    margins: list[str] = []
    while len(coefficients) > 1:
        degree = len(coefficients) - 1
        leading, constant = coefficients[0], coefficients[-1]
        margin = leading * leading - constant * constant
        if margin <= 0:
            return None
        margins.append(fraction_text(margin))
        coefficients = [
            leading * coefficients[index] - constant * coefficients[degree - index]
            for index in range(degree)
        ]
    return margins


def enumerate_catalog() -> tuple[list[dict], dict[str, int]]:
    catalog: list[dict] = []
    counts = {key: 0 for key in EXPECTED}
    for s2 in range(-BOUNDS[0], BOUNDS[0] + 1):
        for s1 in range(-BOUNDS[1], BOUNDS[1] + 1):
            for s0 in range(-BOUNDS[2], BOUNDS[2] + 1):
                if s0 == 0:
                    continue
                counts["raw_nonzero_constant_candidates"] += 1
                if reducible(s2, s1, s0):
                    continue
                counts["irreducible_candidates"] += 1
                poly = [Fraction(s0), Fraction(s1), Fraction(s2), Fraction(1)]
                sequence = sturm(poly)
                target_count = root_count(sequence, Fraction(0), Fraction(1, 2))
                if target_count == 0:
                    continue
                counts["exact_target_root_candidates"] += 1
                margins = schur_margins(s2, s1, s0)
                if margins is None:
                    continue
                counts["exact_disk_sieve_candidates"] += 1
                if evaluate(poly, REAL_LOWER) == 0 or root_count(sequence, Fraction(-3), REAL_LOWER):
                    continue
                counts["exact_real_conjugate_sieve_candidates"] += 1
                real_intervals = isolate(sequence, Fraction(-3), Fraction(3))
                target_intervals = isolate(sequence, Fraction(0), Fraction(1, 2))
                separation = min(
                    min(left, Fraction(1, 2) - right)
                    for left, right in target_intervals
                )
                catalog.append(
                    {
                        "polynomial": (s2, s1, s0),
                        "target_root_count": target_count,
                        "real_root_intervals": real_intervals,
                        "schur_margins": margins,
                        "separation": fraction_text(separation),
                    }
                )
    return catalog, counts


def main() -> None:
    report = json.loads(INPUT.read_text(encoding="utf-8"))
    assert report["schema_version"] == 5
    exact = report["exact_sieve"]
    assert exact["disk_bound"] == fraction_text(DISK_BOUND)
    assert exact["uniform_coefficient_bounds"] == {"s2": 8, "s1": 24, "s0": 23}
    assert exact["target_interval"] == ["0/1", "1/2"]
    assert exact["real_root_isolation_width_at_most"] == fraction_text(MAX_WIDTH)
    assert exact["real_conjugate_lower_bound"] == fraction_text(REAL_LOWER)

    independent, counts = enumerate_catalog()
    assert counts == EXPECTED == report["sieve_counts"]
    retained = report["candidate_catalog"]
    assert len(retained) == len(independent) == 126
    assert [item["candidate_id"] for item in retained] == list(range(1, 127))

    for item, expected in zip(retained, independent):
        polynomial = tuple(item["minimal_polynomial_coefficients"])
        assert polynomial == expected["polynomial"]
        record = item["sturm"]
        assert record["target_root_count"] == expected["target_root_count"]
        expected_intervals = [
            {"left": fraction_text(left), "right": fraction_text(right)}
            for left, right in expected["real_root_intervals"]
        ]
        assert record["real_root_intervals"] == expected_intervals
        assert item["schur_margins"] == expected["schur_margins"]
        assert item["exact_separation_bounds"] == {
            "target_endpoint_distance_lower_bound": expected["separation"]
        }

    print(
        "PASS: independently enumerated 38,318 nonzero-constant cubics and "
        "reproduced the exact ordered 126-entry uniform catalog"
    )


if __name__ == "__main__":
    main()
