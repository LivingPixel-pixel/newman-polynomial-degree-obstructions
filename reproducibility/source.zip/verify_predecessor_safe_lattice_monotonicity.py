#!/usr/bin/env python3
"""Exact symbolic sign audit for the safe-lattice proof inequalities.

The manuscript proof is analytic.  This independent SymPy audit clears
denominators, counts all real roots of the relevant derivative numerators on
their rational intervals, and records exact endpoint/sample signs.  It does
not replace the proof.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import sympy as sp


t = sp.symbols("t")


def partial(k: int, m: int) -> sp.Expr:
    return sp.expand(
        sum((-1) ** ell * sp.binomial(k + ell, ell) * t**ell for ell in range(m + 1))
    )


def rational_text(value: sp.Expr) -> str:
    value = sp.factor(value)
    return str(value)


def sign(value: sp.Expr) -> int:
    value = sp.factor(value)
    assert value.is_Rational and value != 0, value
    return 1 if value > 0 else -1


def derivative_certificate(name: str, expr: sp.Expr, left: sp.Rational, right: sp.Rational) -> dict:
    derivative = sp.factor(sp.diff(expr, t))
    numerator, denominator = map(sp.factor, sp.together(derivative).as_numer_denom())
    poly = sp.Poly(numerator, t, domain=sp.QQ)
    root_count = int(poly.count_roots(left, right))
    sample = sp.factor(numerator.subs(t, (left + right) / 2))
    assert root_count == 0, (name, root_count)
    assert sign(sample) < 0, (name, sample)
    assert denominator.subs(t, left) > 0 and denominator.subs(t, right) > 0
    return {
        "name": name,
        "interval": [str(left), str(right)],
        "derivative_numerator_coefficients_high_to_low": [str(x) for x in poly.all_coeffs()],
        "derivative_denominator": rational_text(denominator),
        "open_interval_root_count": root_count,
        "midpoint_numerator": str(sample),
        "certified_derivative_sign": "negative",
    }


def positivity_certificate(name: str, expr: sp.Expr, left: sp.Rational, right: sp.Rational) -> dict:
    numerator, denominator = map(sp.factor, sp.together(expr).as_numer_denom())
    poly = sp.Poly(numerator, t, domain=sp.QQ)
    root_count = int(poly.count_roots(left, right))
    sample = sp.factor(numerator.subs(t, (left + right) / 2))
    assert root_count == 0, (name, root_count)
    assert sign(sample) > 0, (name, sample)
    assert denominator.subs(t, left) > 0 and denominator.subs(t, right) > 0
    return {
        "name": name,
        "interval": [str(left), str(right)],
        "numerator_coefficients_high_to_low": [str(x) for x in poly.all_coeffs()],
        "denominator": rational_text(denominator),
        "open_interval_root_count": root_count,
        "midpoint_numerator": str(sample),
        "certified_sign": "positive",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("predecessor_safe_lattice_monotonicity_exact.json"),
    )
    args = parser.parse_args()

    zero, half = sp.Rational(0), sp.Rational(1, 2)
    t383, t433, t487 = sp.Rational(383, 1000), sp.Rational(433, 1000), sp.Rational(487, 1000)

    expressions = {
        "late_root_exclusion": (1 + t) ** -2 + partial(3, 7),
        "s1_root_threshold": partial(1, 6) - (4 * t - 1),
        "s1_companion_lower_bound": 1 - 2 * t - t / (1 + t) ** 3,
        "s3_root_threshold": (1 + t) ** -2 + partial(3, 3),
        "s3_companion_upper_bound": (1 + t) ** -1 - t * partial(4, 2),
        "s5_root_threshold": (1 + t) ** -2 + partial(3, 5),
        "s5_companion_upper_bound": (1 + t) ** -1 - t * partial(4, 4),
        "P2_5": partial(2, 5),
        "common_odd_pair_lower_bound": 1
        - t * ((1 + t) ** -2 + partial(3, 2)),
    }

    derivative_specs = [
        ("late_root_exclusion", zero, half),
        ("s1_root_threshold", zero, half),
        ("s1_companion_lower_bound", zero, half),
        ("s3_root_threshold", zero, half),
        ("s3_companion_upper_bound", t433, half),
        ("s5_root_threshold", zero, half),
        ("s5_companion_upper_bound", t487, half),
        ("P2_5", zero, half),
    ]
    derivative_certificates = [
        derivative_certificate(name, expressions[name], left, right)
        for name, left, right in derivative_specs
    ]
    positivity_certificates = [
        positivity_certificate("P2_5", expressions["P2_5"], zero, half),
        positivity_certificate(
            "common_odd_pair_lower_bound",
            expressions["common_odd_pair_lower_bound"],
            zero,
            half,
        ),
    ]

    endpoint_values = {
        "late_root_exclusion_at_1_over_2": str(sp.factor(expressions["late_root_exclusion"].subs(t, half))),
        "s1_root_threshold_at_383_over_1000": str(sp.factor(expressions["s1_root_threshold"].subs(t, t383))),
        "s1_companion_lower_bound_at_383_over_1000": str(sp.factor(expressions["s1_companion_lower_bound"].subs(t, t383))),
        "s3_root_threshold_at_433_over_1000": str(sp.factor(expressions["s3_root_threshold"].subs(t, t433))),
        "s3_companion_upper_bound_at_433_over_1000": str(sp.factor(expressions["s3_companion_upper_bound"].subs(t, t433))),
        "s5_root_threshold_at_487_over_1000": str(sp.factor(expressions["s5_root_threshold"].subs(t, t487))),
        "s5_companion_upper_bound_at_487_over_1000": str(sp.factor(expressions["s5_companion_upper_bound"].subs(t, t487))),
        "P2_5_at_1_over_2": str(sp.factor(expressions["P2_5"].subs(t, half))),
    }
    expected_signs = {
        "late_root_exclusion_at_1_over_2": 1,
        "s1_root_threshold_at_383_over_1000": -1,
        "s1_companion_lower_bound_at_383_over_1000": 1,
        "s3_root_threshold_at_433_over_1000": 1,
        "s3_companion_upper_bound_at_433_over_1000": -1,
        "s5_root_threshold_at_487_over_1000": 1,
        "s5_companion_upper_bound_at_487_over_1000": -1,
        "P2_5_at_1_over_2": 1,
    }
    for name, expected in expected_signs.items():
        assert sign(sp.sympify(endpoint_values[name])) == expected, name

    report = {
        "schema_version": 1,
        "proof_status": "exact_symbolic_sign_audit_supporting_infinite_manuscript_proof",
        "method": (
            "After exact differentiation and denominator clearing, SymPy counts all real roots "
            "of each numerator on the stated rational interval; a rational sample fixes its sign."
        ),
        "derivative_certificates": derivative_certificates,
        "positivity_certificates": positivity_certificates,
        "exact_endpoint_values": endpoint_values,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(f"PASS: {len(derivative_certificates)} derivative signs and {len(positivity_certificates)} positive expressions")
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
