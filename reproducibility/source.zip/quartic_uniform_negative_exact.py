#!/usr/bin/env python3
"""Exact final uniform negative-coefficient certificates for quartic roots."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction
import json
import math
from pathlib import Path
import sys

sys.set_int_max_str_digits(0)


Interval = tuple[Fraction, Fraction]
TAIL_START_V = 23


def add(x: Interval, y: Interval) -> Interval:
    return x[0] + y[0], x[1] + y[1]


def neg(x: Interval) -> Interval:
    return -x[1], -x[0]


def sub(x: Interval, y: Interval) -> Interval:
    return add(x, neg(y))


def mul(x: Interval, y: Interval) -> Interval:
    products = (x[0] * y[0], x[0] * y[1], x[1] * y[0], x[1] * y[1])
    return min(products), max(products)


def positive_pow(x: Interval, exponent: int) -> Interval:
    return x[0] ** exponent, x[1] ** exponent


def reciprocal(x: Interval) -> Interval:
    return 1 / x[1], 1 / x[0]


def polynomial_interval(coefficients: list[int], x: Interval) -> Interval:
    value = (Fraction(coefficients[-1]), Fraction(coefficients[-1]))
    for coefficient in reversed(coefficients[:-1]):
        value = add(mul(value, x), (Fraction(coefficient), Fraction(coefficient)))
    return value


def quartic_value(polynomial: tuple[int, int, int, int], x: Fraction) -> Fraction:
    s3, s2, s1, s0 = polynomial
    return (((x + s3) * x + s2) * x + s1) * x + s0


@dataclass
class Root:
    polynomial: tuple[int, int, int, int]
    interval: Interval

    def refine(self) -> None:
        left, right = self.interval
        middle = (left + right) / 2
        fl = quartic_value(self.polynomial, left)
        fm = quartic_value(self.polynomial, middle)
        fr = quartic_value(self.polynomial, right)
        assert fl and fr and fl * fr < 0
        if fl * fm < 0:
            self.interval = left, middle
        elif fm * fr < 0:
            self.interval = middle, right
        else:
            raise AssertionError("rational root contradicts irreducibility")


def partial(k: int, m: int, a: Interval) -> Interval:
    return polynomial_interval([(-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1)], a)


def limit_interval(k: int, offset: int, a: Interval) -> Interval:
    top_m = (offset - 2) // 2
    top = mul(a, partial(k, top_m, a))
    one_plus = add((Fraction(1), Fraction(1)), a)
    if k % 2:
        value = top
        for j in range(1, k, 2):
            value = add(value, mul(a, reciprocal(positive_pow(one_plus, j + 1))))
        return value
    value = reciprocal(one_plus)
    value = sub(value, top)
    for j in range(2, k, 2):
        value = sub(value, mul(a, reciprocal(positive_pow(one_plus, j + 1))))
    return value


def limit_float(k: int, offset: int, a: float) -> float:
    top_m = (offset - 2) // 2
    top = a * sum((-1) ** ell * math.comb(k + ell, ell) * a**ell for ell in range(top_m + 1))
    if k % 2:
        return top + sum(a / (1 + a) ** (j + 1) for j in range(1, k, 2))
    return 1 / (1 + a) - top - sum(a / (1 + a) ** (j + 1) for j in range(2, k, 2))


def tail_error(k: int, offset: int, v: int, upper_a: Fraction) -> Fraction | None:
    error = Fraction(0)
    if k % 2 == 0:
        base_m = (k * v + offset) // 2
        error += upper_a ** (base_m + 1)
        lower = range(2, k, 2)
    else:
        lower = range(1, k, 2)
    for j in lower:
        m = ((k - j) * v + offset - 2) // 2
        if upper_a * (j + m + 2) >= m + 2:
            return None
        error += upper_a * Fraction(math.comb(j + m + 1, m + 1)) * upper_a ** (m + 1)
    return error


def candidate_order(max_k: int, max_offset: int):
    values = []
    for k in range(1, max_k + 1):
        # With m=(offset-2)/2, the potentially negative limiting partial sums
        # have odd m for odd k and even m for even k.
        offsets = range(4, max_offset + 1, 4) if k % 2 else range(2, max_offset + 1, 4)
        values.extend((k, offset) for offset in offsets)
    return sorted(values, key=lambda item: item[0] * TAIL_START_V + item[1])


def certify(root: Root, max_k: int, max_offset: int) -> dict:
    midpoint = float(sum(root.interval) / 2)
    ordered = candidate_order(max_k, max_offset)
    likely = [item for item in ordered if limit_float(*item, midpoint) < -1e-10]
    # Check numerically selected candidates first, then fall back to all.
    for k, offset in likely + [item for item in ordered if item not in set(likely)]:
        for _ in range(20):
            limit = limit_interval(k, offset, root.interval)
            error = tail_error(k, offset, TAIL_START_V, root.interval[1])
            if error is not None and limit[1] + error < 0:
                return {
                    "status": "certified",
                    "k": k,
                    "offset": offset,
                    "index": f"{k}*v+{offset}",
                    "limit_interval": [str(limit[0]), str(limit[1])],
                    "tail_error_v23": str(error),
                    "upper_bound": str(limit[1] + error),
                    "root_interval": [str(root.interval[0]), str(root.interval[1])],
                }
            root.refine()
    return {"status": "failed", "root_interval": [str(x) for x in root.interval]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-k", type=int, default=130)
    parser.add_argument("--max-offset", type=int, default=100)
    args = parser.parse_args()
    catalog = json.loads(args.catalog.read_text(encoding="utf-8"))
    records = []
    failures = 0
    max_k_used = 0
    root_number = 0
    total_roots = sum(item["target_root_count"] for item in catalog["candidate_catalog"])
    for item in catalog["candidate_catalog"]:
        polynomial = tuple(item["minimal_polynomial_coefficients"])
        for root_index, interval in enumerate(item["target_root_intervals"], 1):
            root_number += 1
            root = Root(polynomial, (Fraction(interval["left"]), Fraction(interval["right"])))
            result = certify(root, args.max_k, args.max_offset)
            if result["status"] == "failed":
                failures += 1
            else:
                max_k_used = max(max_k_used, result["k"])
            records.append(
                {
                    "candidate_id": item["candidate_id"],
                    "root_index": root_index,
                    "polynomial": list(polynomial),
                    "certificate": result,
                }
            )
            if root_number % 100 == 0 or root_number == total_roots:
                print(f"{root_number}/{total_roots}; failures={failures}; max_k={max_k_used}", flush=True)
    report = {
        "schema_version": 1,
        "proof_status": "exact_complete_uniform_quartic_negative_coefficients",
        "tail_start_v": TAIL_START_V,
        "root_count": total_roots,
        "failures": failures,
        "max_k_used": max_k_used,
        "max_offset_searched": args.max_offset,
        "records": records,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps({"failures": failures, "max_k_used": max_k_used}, indent=2))


if __name__ == "__main__":
    main()
