"""Exact checker for the retained theorem-scope counterexample.

The coefficient ring is Z[a]/(a^3 - 3a + 1). No symbolic algebra,
floating-point arithmetic, or external package is used.
"""

from fractions import Fraction


Coeff = tuple[int, int, int]


def add(left: Coeff, right: Coeff) -> Coeff:
    return tuple(x + y for x, y in zip(left, right))


def multiply(left: Coeff, right: Coeff) -> Coeff:
    raw: dict[int, int] = {}
    for i, x in enumerate(left):
        for j, y in enumerate(right):
            raw[i + j] = raw.get(i + j, 0) + x * y
    for degree in range(max(raw, default=0), 2, -1):
        value = raw.get(degree, 0)
        if value:
            # a^degree = 3 a^(degree-2) - a^(degree-3)
            raw[degree - 2] = raw.get(degree - 2, 0) + 3 * value
            raw[degree - 3] = raw.get(degree - 3, 0) - value
    return tuple(raw.get(i, 0) for i in range(3))


def multiply_x_polynomials(
    left: dict[int, Coeff], right: dict[int, Coeff]
) -> dict[int, Coeff]:
    result: dict[int, Coeff] = {}
    for i, x in left.items():
        for j, y in right.items():
            result[i + j] = add(result.get(i + j, (0, 0, 0)), multiply(x, y))
    return {degree: value for degree, value in result.items() if value != (0, 0, 0)}


def minimal_polynomial(t: Fraction) -> Fraction:
    return t**3 - 3 * t + 1


def main() -> None:
    # The rational-root test leaves only +/-1, and neither is a root.
    assert minimal_polynomial(Fraction(1)) == -1
    assert minimal_polynomial(Fraction(-1)) == 3

    # On (0, 1/2), m'(t)=3(t^2-1)<0; these endpoint signs locate one root.
    assert minimal_polynomial(Fraction(0)) == 1
    assert minimal_polynomial(Fraction(1, 2)) == Fraction(-3, 8)

    one = (1, 0, 0)
    a = (0, 1, 0)
    minus_a = (0, -1, 0)
    a_squared_minus_one = (-1, 0, 1)
    one_minus_a = (1, -1, 0)

    factor = {0: one, 2: a, 4: one}
    quotient = {
        0: one,
        2: minus_a,
        4: a_squared_minus_one,
        6: one_minus_a,
        8: one_minus_a,
        10: a_squared_minus_one,
        12: minus_a,
        14: one,
    }
    product = multiply_x_polynomials(factor, quotient)
    assert product == {0: one, 18: one}

    print("verified irreducible cubic m(t)=t^3-3t+1")
    print("verified its unique root a in (0,1/2)")
    print("verified (1+a*x^2+x^4)*B(x)=1+x^18 exactly")
    print("verified B is not nonnegative because -a<0 and a^2-1<0")


if __name__ == "__main__":
    main()
