#!/usr/bin/env python3
"""Cross-check manuscript claims against the complete retained data bundle."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "manuscript.tex"


def load(name: str) -> dict:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def require(condition: bool, message: str, checks: list[str]) -> None:
    if not condition:
        raise AssertionError(message)
    checks.append(message)


def main() -> None:
    checks: list[str] = []
    source = SOURCE.read_text(encoding="utf-8")
    labels = re.findall(r"\\label\{([^}]+)\}", source)
    references = re.findall(r"\\(?:eq)?ref\{([^}]+)\}", source)
    citations = {
        key
        for group in re.findall(r"\\cite\{([^}]+)\}", source)
        for key in group.split(",")
    }
    bibliography = set(re.findall(r"\\bibitem\{([^}]+)\}", source))
    require(len(labels) == len(set(labels)), "all LaTeX labels are unique", checks)
    require(
        set(references) <= set(labels),
        "every LaTeX reference resolves to a manuscript label",
        checks,
    )
    require(
        citations <= bibliography,
        "every citation resolves to a bibliography item",
        checks,
    )
    require(
        re.search(r"\bversion\s+\d+\b", source, re.IGNORECASE) is None
        and "temporary" not in source.lower()
        and "Global portable" not in source,
        "the manuscript contains no revision or temporary labels",
        checks,
    )
    require(
        r"1\le j<K\\j\ \mathrm{odd}" in source
        and r"2\le j<K\\j\ \mathrm{even}" in source
        and "\nm odd" not in source
        and "\nm even" not in source,
        "the block-limit summations display the correct parity conditions",
        checks,
    )

    cubic_forced = load("forced_recurrence_global_exact.json")
    require(
        cubic_forced["candidate_count"] == 126
        and all(
            result["status"] == "negative"
            and result["structural_zero_indices"] == [int(v)]
            for record in cubic_forced["records"]
            for v, result in record["finite_odd_v_5_through_21"].items()
        )
        and all(
            record["direct_v23_first_negative"]["status"] == "negative"
            and record["direct_v23_first_negative"]["structural_zero_indices"]
            == [23]
            for record in cubic_forced["records"]
        ),
        "all 126 cubic finite and uniform obstruction records pass",
        checks,
    )
    cubic_blocks = load("forced_block_positivity_exact.json")
    require(
        cubic_blocks["candidate_count"] == 126
        and all(
            result["status"] == "positive"
            for record in cubic_blocks["records"]
            for result in record[
                "complete_positive_blocks_before_obstruction"
            ].values()
        )
        and all(
            record["positive_prefix_in_obstruction_block"]["status"]
            == "positive"
            for record in cubic_blocks["records"]
        ),
        "all 126 cubic uniform positive-prefix records pass",
        checks,
    )

    catalog = load("quartic_norm_sieve_exact.json")
    tail = load("quartic_uniform_negative_exact.json")
    finite = load("quartic_finite_recurrence_exact.json")
    prefixes = [load(f"quartic_prefix_q{i}_exact.json") for i in range(1, 5)]
    require(
        catalog["proof_status"] == "exact_complete_uniform_quartic_norm_sieve",
        "quartic catalog is marked complete",
        checks,
    )
    require(
        catalog["counts"]
        == {
            "raw_nonzero_constant": 1691646,
            "strict_schur_disk": 63546,
            "irreducible": 57238,
            "target_root": 10671,
            "real_conjugate_sieve": 6977,
        },
        "quartic catalog counts agree with the manuscript",
        checks,
    )
    require(
        len(catalog["candidate_catalog"]) == 6977
        and sum(x["target_root_count"] for x in catalog["candidate_catalog"])
        == 6982,
        "quartic catalog has 6,977 polynomials and 6,982 target roots",
        checks,
    )
    require(
        tail["proof_status"]
        == "exact_complete_uniform_quartic_negative_coefficients"
        and tail["root_count"] == 6982
        and tail["failures"] == 0
        and tail["max_k_used"] == 110,
        "uniform quartic tail certificate is complete",
        checks,
    )
    require(
        finite["proof_status"] == "exact_complete_quartic_finite_v"
        and finite["root_count"] == 6982
        and finite["finite_v"] == list(range(5, 22, 2))
        and finite["failures"] == [],
        "finite quartic recurrence certificate is complete",
        checks,
    )
    require(
        sum(part["root_count"] for part in prefixes) == 6982
        and all(
            part["proof_status"] == "exact_complete_uniform_quartic_prefix"
            and part["failures"] == []
            for part in prefixes
        ),
        "all four quartic prefix shards pass",
        checks,
    )

    independent = load("independent_quartic_audit.json")
    require(
        independent["status"] == "PASS"
        and independent["totals"]
        == {
            "target_roots": 6982,
            "finite_root_exponent_pairs": 62838,
            "finite_coefficient_inequalities": 12369079,
            "uniform_target_roots": 6982,
            "uniform_negative_tail_certificates": 6982,
            "uniform_positive_blocks": 99340,
            "uniform_inequalities": 4979348,
        },
        "independent Schur-Cohn, FLINT, and Arb audits pass",
        checks,
    )
    direct_uniform = load("independent_uniform_direct_stress.json")
    require(
        direct_uniform["status"] == "PASS"
        and direct_uniform["logical_scope"]
        == "finite redundant stress only; not an infinite proof"
        and direct_uniform["target_roots"] == 6982
        and direct_uniform["exponents"] == [23, 251]
        and direct_uniform["cases_checked"] == 13964
        and direct_uniform["coefficients_checked"] == 28246032
        and direct_uniform["failures"] == [],
        "direct Arb recurrence stress passes all 13,964 uniform cases",
        checks,
    )

    six = load("predecessor_six_block_exact.json")
    six_signs = load("predecessor_six_block_signs_exact.json")
    require(
        six["totals"]
        == {
            "finite_exception_modular_gcd_certificates": 48,
            "parity_checks": 111228,
            "predecessor_pair_checks": 190464,
            "six_block_checks": 95232,
            "v_count": 124,
        },
        "six-block exact audit totals agree with the manuscript",
        checks,
    )
    require(
        six_signs["exact_interval_horner_sign_certificate_count"] == 53
        and six_signs["finite_exception_modular_gcd_certificate_count"] == 48,
        "independent six-block sign and gcd certificate totals agree",
        checks,
    )

    stress = load("coefficient_one_modular_stress_v151_n12000.json")
    stress_pairs = sum(item["tested_pair_count"] for item in stress["records"])
    unresolved = sum(len(item["unresolved_indices"]) for item in stress["records"])
    require(
        stress_pairs == 876456 and unresolved == 0,
        "retained 876,456-pair coprimality stress has no unresolved index",
        checks,
    )

    seventh = load("predecessor_seventh_block_reconnaissance.json")
    require(
        seventh["proof_status"] == "exact_finite_reconnaissance_only"
        and seventh["all_recorded_companion_gcds_constant"]
        and sum(item["root_count"] for item in seventh["records"]) == 158,
        "seventh-block scan is correctly limited to finite reconnaissance",
        checks,
    )

    cubic_stress = load("stress_exact_recurrence_v23_v99.json")
    require(
        cubic_stress["candidate_count"] == 126
        and cubic_stress["case_count"] == 4914,
        "all 4,914 direct cubic recurrence stress cases pass",
        checks,
    )
    identity_v23 = load("block_identity_exact_audit.json")
    identity_v99 = load("block_identity_exact_audit_v99.json")
    identity_rational = load("block_identity_rational_audit.json")
    require(
        identity_v23["coefficient_identity_count"] == 29193
        and identity_v99["coefficient_identity_count"] == 123053
        and identity_rational["coefficient_identity_count"] == 9009,
        "all cubic block-identity audit counts agree with the manuscript",
        checks,
    )

    canonical_names = [
        "quartic_norm_sieve_exact.json",
        "quartic_uniform_negative_exact.json",
        "quartic_finite_recurrence_exact.json",
        *(f"quartic_prefix_q{i}_exact.json" for i in range(1, 5)),
        "independent_quartic_catalog_audit.json",
        *(f"independent_finite_arb_q{i}.json" for i in range(1, 5)),
        *(f"independent_uniform_arb_q{i}.json" for i in range(1, 5)),
        "independent_quartic_audit.json",
        *(f"independent_uniform_direct_q{i}.json" for i in range(1, 5)),
        "independent_uniform_direct_stress.json",
        "predecessor_seventh_block_reconnaissance.json",
        "forced_recurrence_global_exact.json",
        "forced_block_positivity_exact.json",
        "stress_exact_recurrence_v23_v99.json",
        "block_identity_exact_audit.json",
        "block_identity_exact_audit_v99.json",
        "block_identity_rational_audit.json",
    ]
    require(
        all(b"\r" not in (ROOT / name).read_bytes() for name in canonical_names),
        "all retained proof and audit JSON uses canonical LF newlines",
        checks,
    )

    report = {
        "schema_version": 1,
        "proof_status": "manuscript_consistency_verified",
        "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "check_count": len(checks),
        "checks": checks,
        "status": "PASS",
    }
    output = ROOT / "manuscript_consistency_audit.json"
    output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
