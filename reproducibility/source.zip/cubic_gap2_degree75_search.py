"""Exact-audited cubic smaller-gap-two search.

The pre-sieve uses only rational arithmetic:

* the rational-root theorem for irreducibility of monic cubics;
* Sturm sequences for the required root in (0, 1/2) and real-root isolation;
* the Schur recursion for the necessary disk bound |alpha| < 143/50.
* the exact uniform real-conjugate bound alpha > -2;
* exact dyadic upper bounds for the sharper case-dependent kappa(2, v).

For every retained norm polynomial, the script seeks a rational LP
infeasibility proof.  A deterministic HiGHS portfolio is used only to locate a
sparse dual support; SymPy reconstructs the multipliers exactly, and the script
accepts a certificate only after exact integer row cancellation and a negative
  right-hand side.  Every retained system must receive a portable certificate.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
import platform
from pathlib import Path
from typing import Iterable

import numpy as np
import scipy
from scipy.optimize import linprog
import sympy as sp

DEGREE_LIMIT = 75
DISK_BOUND = Fraction(143, 50)
COEFFICIENT_BOUNDS = (8, 24, 23)
ISOLATION_WIDTH = Fraction(1, 2**36)
REAL_CONJUGATE_LOWER_BOUND = Fraction(-2)
CASE_VALUES = tuple(range(5, 26, 2))
KAPPA_DYADIC_BITS = 80


def fraction_text(value: Fraction) -> str:
    """Return a canonical, exactly parseable rational."""
    return f"{value.numerator}/{value.denominator}"


def trim(poly: list[Fraction]) -> list[Fraction]:
    """Remove high-degree zero coefficients from an ascending polynomial."""
    while len(poly) > 1 and poly[-1] == 0:
        poly.pop()
    return poly


def derivative(poly: list[Fraction]) -> list[Fraction]:
    if len(poly) == 1:
        return [Fraction(0)]
    return [Fraction(i) * poly[i] for i in range(1, len(poly))]


def polynomial_divmod(
    dividend: list[Fraction], divisor: list[Fraction]
) -> tuple[list[Fraction], list[Fraction]]:
    """Exact Euclidean division for ascending Fraction polynomials."""
    remainder = trim(dividend.copy())
    divisor = trim(divisor.copy())
    if divisor == [0]:
        raise ZeroDivisionError("polynomial division by zero")
    quotient = [Fraction(0)] * max(1, len(remainder) - len(divisor) + 1)
    while remainder != [0] and len(remainder) >= len(divisor):
        shift = len(remainder) - len(divisor)
        factor = remainder[-1] / divisor[-1]
        quotient[shift] += factor
        for i, coefficient in enumerate(divisor):
            remainder[i + shift] -= factor * coefficient
        trim(remainder)
    return trim(quotient), trim(remainder)


def sturm_sequence(poly: list[Fraction]) -> list[list[Fraction]]:
    """Construct the exact Sturm sequence of a squarefree polynomial."""
    sequence = [trim(poly.copy()), trim(derivative(poly))]
    while sequence[-1] != [0]:
        _, remainder = polynomial_divmod(sequence[-2], sequence[-1])
        if remainder == [0]:
            break
        sequence.append([-coefficient for coefficient in remainder])
    return sequence


def evaluate(poly: list[Fraction], point: Fraction) -> Fraction:
    value = Fraction(0)
    for coefficient in reversed(poly):
        value = value * point + coefficient
    return value


def variations(sequence: Iterable[list[Fraction]], point: Fraction) -> int:
    signs: list[int] = []
    for poly in sequence:
        value = evaluate(poly, point)
        if value:
            signs.append(1 if value > 0 else -1)
    return sum(left != right for left, right in zip(signs, signs[1:]))


def root_count(
    sequence: list[list[Fraction]], left: Fraction, right: Fraction
) -> int:
    """Count distinct roots in (left, right); endpoints are never roots here."""
    return variations(sequence, left) - variations(sequence, right)


def isolate_real_roots(
    sequence: list[list[Fraction]], left: Fraction, right: Fraction
) -> list[tuple[Fraction, Fraction]]:
    """Return disjoint rational intervals, each containing exactly one root."""
    pending = [(left, right, root_count(sequence, left, right))]
    isolated: list[tuple[Fraction, Fraction]] = []
    while pending:
        lo, hi, count = pending.pop()
        if count == 0:
            continue
        if count == 1 and hi - lo <= ISOLATION_WIDTH:
            isolated.append((lo, hi))
            continue
        mid = (lo + hi) / 2
        left_count = root_count(sequence, lo, mid)
        right_count = count - left_count
        if right_count:
            pending.append((mid, hi, right_count))
        if left_count:
            pending.append((lo, mid, left_count))
    return sorted(isolated)


def reducible_cubic(s2: int, s1: int, s0: int) -> bool:
    """A monic integral cubic is reducible iff it has an integral root."""
    for divisor in range(1, abs(s0) + 1):
        if s0 % divisor == 0:
            for root in (divisor, -divisor):
                if root**3 + s2 * root**2 + s1 * root + s0 == 0:
                    return True
    return False


def integer_sign_variations(values: Iterable[int]) -> int:
    signs = [1 if value > 0 else -1 for value in values if value]
    return sum(left != right for left, right in zip(signs, signs[1:]))


def target_root_certificate(s2: int, s1: int, s0: int) -> tuple[int, int, int]:
    """Fast exact Sturm variations for a monic cubic at 0 and 1/2.

    Positive rescalings give the Sturm sequence
      p, p', A*x+B, C,
    with A=2(s2^2-3s1), B=s2*s1-9s0, and
    C=2*s2*A*B-s1*A^2-3*B^2.  The exceptional A=0 case ends
    with the nonzero constant B.
    """
    a, b, c = s2, s1, s0
    A = 2 * (a * a - 3 * b)
    B = a * b - 9 * c
    if A == 0:
        at_zero_values = [c, b, B]
        at_half_values = [1 + 2 * a + 4 * b + 8 * c, 3 + 4 * a + 4 * b, B]
    else:
        C = 2 * a * A * B - b * A * A - 3 * B * B
        at_zero_values = [c, b, B, C]
        at_half_values = [
            1 + 2 * a + 4 * b + 8 * c,
            3 + 4 * a + 4 * b,
            A + 2 * B,
            C,
        ]
    at_zero = integer_sign_variations(at_zero_values)
    at_half = integer_sign_variations(at_half_values)
    return at_zero, at_half, at_zero - at_half


def schur_disk_certificate(s2: int, s1: int, s0: int) -> list[Fraction] | None:
    """Certify all roots have modulus < DISK_BOUND by exact Schur recursion."""
    radius = DISK_BOUND
    coefficients = [
        radius**3,
        Fraction(s2) * radius**2,
        Fraction(s1) * radius,
        Fraction(s0),
    ]
    margins: list[Fraction] = []
    while len(coefficients) > 1:
        degree = len(coefficients) - 1
        leading = coefficients[0]
        constant = coefficients[-1]
        margin = leading * leading - constant * constant
        if margin <= 0:
            return None
        margins.append(margin)
        coefficients = [
            leading * coefficients[i] - constant * coefficients[degree - i]
            for i in range(degree)
        ]
    return margins


def candidate_minimal_polynomials():
    """Enumerate the exact uniform candidate catalog for all ten v cases."""
    candidates = []
    counts = {
        "raw_nonzero_constant_candidates": 0,
        "irreducible_candidates": 0,
        "exact_target_root_candidates": 0,
        "exact_disk_sieve_candidates": 0,
        "exact_real_conjugate_sieve_candidates": 0,
    }
    for s2 in range(-COEFFICIENT_BOUNDS[0], COEFFICIENT_BOUNDS[0] + 1):
        for s1 in range(-COEFFICIENT_BOUNDS[1], COEFFICIENT_BOUNDS[1] + 1):
            for s0 in range(-COEFFICIENT_BOUNDS[2], COEFFICIENT_BOUNDS[2] + 1):
                if s0 == 0:
                    continue
                counts["raw_nonzero_constant_candidates"] += 1
                if reducible_cubic(s2, s1, s0):
                    continue
                counts["irreducible_candidates"] += 1
                at_zero, at_half, target_count = target_root_certificate(s2, s1, s0)
                if target_count < 1:
                    continue
                counts["exact_target_root_candidates"] += 1
                poly = [Fraction(s0), Fraction(s1), Fraction(s2), Fraction(1)]
                sequence = sturm_sequence(poly)
                assert root_count(sequence, Fraction(0), Fraction(1, 2)) == target_count
                schur_margins = schur_disk_certificate(s2, s1, s0)
                if schur_margins is None:
                    continue
                counts["exact_disk_sieve_candidates"] += 1

                # Schur gives |alpha| < 143/50 < 3.  Lemma 6.1 and the real
                # conjugate obstruction require every real alpha > -2, so an
                # exact Sturm count on (-3,-2), plus the endpoint check,
                # certifies the uniform lower-bound filter.
                if evaluate(poly, REAL_CONJUGATE_LOWER_BOUND) == 0 or root_count(
                    sequence, Fraction(-3), REAL_CONJUGATE_LOWER_BOUND
                ):
                    continue
                counts["exact_real_conjugate_sieve_candidates"] += 1

                intervals = isolate_real_roots(sequence, Fraction(-3), Fraction(3))
                target_intervals = isolate_real_roots(
                    sequence, Fraction(0), Fraction(1, 2)
                )
                assert len(target_intervals) == target_count
                endpoint_distance_lower_bound = min(
                    min(left, Fraction(1, 2) - right)
                    for left, right in target_intervals
                )
                assert endpoint_distance_lower_bound > 0
                candidates.append(
                    {
                        "polynomial": (s2, s1, s0),
                        "sturm": {
                            "variations_at_0": at_zero,
                            "variations_at_1_over_2": at_half,
                            "target_root_count": target_count,
                            "real_root_intervals": [
                                {"left": fraction_text(lo), "right": fraction_text(hi)}
                                for lo, hi in intervals
                            ],
                        },
                        "schur_margins": [fraction_text(margin) for margin in schur_margins],
                        "exact_separation_bounds": {
                            "target_endpoint_distance_lower_bound": fraction_text(
                                endpoint_distance_lower_bound
                            ),
                        },
                    }
                )
    return candidates, counts


def norm_coefficients(v: int, polynomial: tuple[int, int, int]) -> list[int]:
    """Exact coefficients of the cubic norm polynomial."""
    s2, s1, s0 = polynomial
    coefficients = [0] * (3 * v + 1)
    for k, coefficient in enumerate((1, 3, 3, 1)):
        coefficients[k * v] += coefficient
    for k, coefficient in enumerate((1, 2, 1)):
        coefficients[2 + k * v] -= s2 * coefficient
    for k, coefficient in enumerate((1, 1)):
        coefficients[4 + k * v] += s1 * coefficient
    coefficients[6] -= s0
    return coefficients


def kappa_upper_bound(v: int) -> Fraction:
    """Return the least 2^-80 dyadic strictly above kappa(2, v).

    If y^v=(v-2)/2, then kappa(2,v)=v*y^2/(v-2), hence
    kappa(2,v)^v=v^v/(4*(v-2)^(v-2)).  The comparison below is therefore
    exact integer arithmetic, not a floating-point approximation.
    """
    denominator = 1 << KAPPA_DYADIC_BITS
    target = v**v * denominator**v
    scale = 4 * (v - 2) ** (v - 2)
    lower, upper = 0, 2 * denominator
    while lower + 1 < upper:
        middle = (lower + upper) // 2
        if scale * middle**v > target:
            upper = middle
        else:
            lower = middle
    bound = Fraction(upper, denominator)
    assert scale * bound.numerator**v > v**v * bound.denominator**v
    previous = Fraction(upper - 1, denominator)
    assert scale * previous.numerator**v <= v**v * previous.denominator**v
    return bound


def violates_case_real_bound(candidate: dict, v: int) -> bool:
    """Certify a real conjugate below -kappa(2,v) using a rational endpoint."""
    s2, s1, s0 = candidate["polynomial"]
    polynomial = [Fraction(s0), Fraction(s1), Fraction(s2), Fraction(1)]
    sequence = sturm_sequence(polynomial)
    endpoint = -kappa_upper_bound(v)
    return (
        root_count(sequence, Fraction(-3), endpoint) > 0
        or evaluate(polynomial, endpoint) == 0
    )


def bounded_system_inequalities(
    v: int, polynomial: tuple[int, int, int]
) -> tuple[list[list[int]], list[int], list[str]]:
    """Return A, b, labels for Aq<=b, including q_0=1 as two rows."""
    h = norm_coefficients(v, polynomial)
    quotient_count = DEGREE_LIMIT - 3 * v + 1
    rows: list[list[int]] = []
    rhs: list[int] = []
    labels: list[str] = []
    q0 = [0] * quotient_count
    q0[0] = 1
    rows.extend((q0, [-value for value in q0]))
    rhs.extend((1, -1))
    labels.extend(("q0_upper", "q0_lower"))
    for n in range(DEGREE_LIMIT + 1):
        row = [0] * quotient_count
        for i, coefficient in enumerate(h):
            j = n - i
            if coefficient and 0 <= j < quotient_count:
                row[j] = coefficient
        rows.extend((row, [-value for value in row]))
        rhs.extend((1, 0))
        labels.extend((f"c{n}_upper", f"c{n}_lower"))
    return rows, rhs, labels


def exact_farkas_from_float_support(
    rows: list[list[int]],
    rhs: list[int],
    labels: list[str],
    floating_solution: np.ndarray,
    threshold: float,
) -> dict | None:
    """Reconstruct and verify an exact ray from one numerical support."""
    variable_count = len(rows[0])
    support = np.flatnonzero(floating_solution > threshold).tolist()
    if not support:
        return None
    exact_matrix = sp.Matrix(
        [[rows[j][i] for j in support] for i in range(variable_count)]
        + [[rhs[j] for j in support]]
    )
    exact_rhs = sp.Matrix([0] * variable_count + [-1])
    pivot_rows = exact_matrix.T.rref()[1]
    if len(pivot_rows) != len(support):
        return None
    square = exact_matrix[list(pivot_rows), :]
    solution = square.inv() * sp.Matrix([exact_rhs[i] for i in pivot_rows])
    if exact_matrix * solution != exact_rhs or not all(value >= 0 for value in solution):
        return None

    common_denominator = 1
    for value in solution:
        common_denominator = math.lcm(common_denominator, int(sp.denom(value)))
    multipliers = [int(value * common_denominator) for value in solution]
    common_gcd = 0
    for value in multipliers:
        common_gcd = math.gcd(common_gcd, value)
    multipliers = [value // common_gcd for value in multipliers]
    row_sum = [
        sum(
            multiplier * rows[row_index][column]
            for multiplier, row_index in zip(multipliers, support)
        )
        for column in range(variable_count)
    ]
    rhs_sum = sum(
        multiplier * rhs[row_index]
        for multiplier, row_index in zip(multipliers, support)
    )
    if any(row_sum) or rhs_sum >= 0:
        return None
    return {
        "multipliers": [
            [labels[row_index], str(multiplier)]
            for multiplier, row_index in zip(multipliers, support)
            if multiplier
        ],
        "rhs_sum": str(rhs_sum),
    }


def farkas_certificate(v: int, polynomial: tuple[int, int, int]) -> dict | None:
    """Export a checked integer Farkas ray using a deterministic LP portfolio."""
    rows, rhs, labels = bounded_system_inequalities(v, polynomial)
    variable_count = len(rows[0])
    matrix = np.asarray(rows, dtype=float)
    vector = np.asarray(rhs, dtype=float)
    primal = linprog(
        np.zeros(variable_count),
        A_ub=matrix,
        b_ub=vector,
        bounds=[(None, None)] * variable_count,
        method="highs",
    )
    if primal.status != 2:
        primal = linprog(
            np.zeros(variable_count),
            A_ub=matrix,
            b_ub=vector,
            bounds=[(None, None)] * variable_count,
            method="highs-ipm",
        )
    if primal.status != 2:
        return None

    equality_matrix = np.vstack((matrix.T, vector))
    equality_rhs = np.concatenate((np.zeros(variable_count), np.asarray([-1.0])))
    methods = ("highs", "highs-ipm", "highs-ds")
    attempts = [(method, 0) for method in methods]
    attempts.extend(
        (method, seed) for seed in range(1, 13) for method in methods
    )
    for method, seed in attempts:
        if seed == 0:
            objective = np.zeros(len(rows))
        else:
            objective = np.asarray(
                [
                    ((index * 1103515245 + seed * 12345) % 1000003)
                    / 1000003
                    * 1e-6
                    for index in range(len(rows))
                ]
            )
        dual = linprog(
            objective,
            A_eq=equality_matrix,
            b_eq=equality_rhs,
            bounds=(0, None),
            method=method,
            options={"presolve": seed % 2 == 0},
        )
        if dual.status != 0:
            continue
        for threshold in (0.0, 1e-14, 1e-12, 1e-10, 1e-8, 1e-7, 1e-6, 1e-5):
            certificate = exact_farkas_from_float_support(
                rows, rhs, labels, dual.x, threshold
            )
            if certificate is not None:
                return certificate
    return None


def build_report() -> tuple[dict, dict]:
    report = {
        "schema_version": 5,
        "claim_status": "complete_portable_farkas_certification",
        "degree_limit": DEGREE_LIMIT,
        "case_values": list(CASE_VALUES),
        "exact_command": "python cubic_gap2_degree75_search.py",
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "sympy": sp.__version__,
        },
        "exact_sieve": {
            "disk_bound": fraction_text(DISK_BOUND),
            "disk_bound_justification": (
                "For odd v>=5, R_phi(2,v)<=phi^2+phi^-3=(3*sqrt(5)-1)/2"
                "<143/50; the last inequality follows from 5<(56/25)^2."
            ),
            "uniform_coefficient_bounds": {
                "s2": COEFFICIENT_BOUNDS[0],
                "s1": COEFFICIENT_BOUNDS[1],
                "s0": COEFFICIENT_BOUNDS[2],
            },
            "target_interval": ["0/1", "1/2"],
            "real_root_isolation_width_at_most": fraction_text(ISOLATION_WIDTH),
            "methods": [
                "integral_rational_root_test",
                "fraction_sturm_sequence",
                "fraction_schur_recursion",
                "fraction_sturm_real_conjugate_lower_bound",
            ],
            "real_conjugate_lower_bound": fraction_text(
                REAL_CONJUGATE_LOWER_BOUND
            ),
            "real_conjugate_bound_justification": (
                "Theorem 4.2(c) gives alpha>-kappa(2,v), while Lemma 6.1 gives"
                " kappa(2,v)<2; hence every real conjugate alpha>-2."
            ),
            "superset_note": (
                "The 126-entry uniform catalog is retained for stable candidate identifiers;"
                " every case then applies an exact dyadic upper bound for kappa(2,v)."
            ),
            "kappa_dyadic_bits": KAPPA_DYADIC_BITS,
        },
        "decision_method": {
            "portable_method": "integer_farkas_multipliers_for_rational_lp_infeasibility",
            "arithmetic": "exact_unbounded_integers",
            "timeout": None,
            "support_search": "deterministic_highs_portfolio_with_exact_reconstruction",
            "portable_certificate_file": "cubic_gap2_degree75_farkas.json",
        },
        "candidate_catalog": [],
        "cases": [],
    }
    certificate_report = {
        "schema_version": 2,
        "degree_limit": DEGREE_LIMIT,
        "inequality_order": [
            "q0_upper",
            "q0_lower",
            "then cN_upper,cN_lower for N=0,...,75",
        ],
        "certificate_rule": (
            "Nonnegative integer multipliers cancel every quotient-variable coefficient"
            " and give the recorded negative rhs_sum, proving 0<=rhs_sum."
        ),
        "certificates": [],
    }
    candidates, sieve_counts = candidate_minimal_polynomials()
    report["candidate_catalog"] = [
        {
            "candidate_id": index,
            "minimal_polynomial_coefficients": list(candidate["polynomial"]),
            "sturm": candidate["sturm"],
            "schur_margins": candidate["schur_margins"],
            "exact_separation_bounds": candidate["exact_separation_bounds"],
        }
        for index, candidate in enumerate(candidates, start=1)
    ]
    report["sieve_counts"] = sieve_counts
    for v in CASE_VALUES:
        kappa_upper = kappa_upper_bound(v)
        retained = [
            (index, candidate)
            for index, candidate in enumerate(candidates, start=1)
            if not violates_case_real_bound(candidate, v)
        ]
        retained_ids = [index for index, _ in retained]
        rejected_ids = [
            index for index in range(1, len(candidates) + 1) if index not in retained_ids
        ]
        print(
            f"v={v}: case cutoff retained {len(retained)} candidates; starting certificates",
            flush=True,
        )
        status_counts = {"unsat": 0, "sat": 0}
        status_by_candidate_id = {"unsat": [], "sat": []}
        witnesses_by_candidate_id = {}
        portable_ids = []
        residual_ids = []
        for position, (index, candidate) in enumerate(retained, start=1):
            certificate = farkas_certificate(v, candidate["polynomial"])
            if certificate is None:
                raise RuntimeError(
                    f"portable Farkas extraction failed for v={v}, candidate={index}"
                )
            status, witness = "unsat", None
            portable_ids.append(index)
            certificate_report["certificates"].append(
                {"v": v, "candidate_id": index, **certificate}
            )
            status_counts[status] += 1
            status_by_candidate_id[status].append(index)
            if witness is not None:
                witnesses_by_candidate_id[str(index)] = witness
            if position % 25 == 0 or position == len(retained):
                print(f"v={v}: decided {position}/{len(retained)} systems", flush=True)
        target_distance_lower_bound = min(
            Fraction(
                candidate["exact_separation_bounds"][
                    "target_endpoint_distance_lower_bound"
                ]
            )
            for candidate in candidates
        )
        report["cases"].append(
            {
                "v": v,
                **sieve_counts,
                "kappa_upper_bound": fraction_text(kappa_upper),
                "kappa_upper_power_comparison": (
                    "4*(v-2)^(v-2)*upper^v > v^v"
                ),
                "exact_v_dependent_sieve_candidates": len(retained),
                "v_dependent_rejected_candidate_ids": rejected_ids,
                "decision_status_counts": status_counts,
                "decision_status_by_candidate_id": status_by_candidate_id,
                "portable_farkas_candidate_ids": portable_ids,
                "residual_z3_candidate_ids": residual_ids,
                "witnesses_by_candidate_id": witnesses_by_candidate_id,
                "aggregate_exact_separation_bounds": {
                    "target_endpoint_distance_lower_bound": fraction_text(
                        target_distance_lower_bound
                    ),
                },
            }
        )
        print(
            f"v={v}: {len(retained)} tests, {len(portable_ids)} portable certificates, "
            f"{len(residual_ids)} residual decisions, {status_counts['sat']} survivors",
            flush=True,
        )
    report["decision_method"]["portable_certificate_count"] = len(
        certificate_report["certificates"]
    )
    report["decision_method"]["residual_z3_count"] = sum(
        len(case["residual_z3_candidate_ids"]) for case in report["cases"]
    )
    certificate_report["certificate_count"] = len(certificate_report["certificates"])
    return report, certificate_report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--certificate-output", type=Path)
    args = parser.parse_args()
    report, certificate_report = build_report()
    if args.output is not None:
        output = args.output
    else:
        output = Path(__file__).with_name("cubic_gap2_degree75_results.json")
    certificate_output = args.certificate_output or Path(__file__).with_name(
        "cubic_gap2_degree75_farkas.json"
    )
    payload = json.dumps(report, indent=2, sort_keys=False) + "\n"
    certificate_payload = json.dumps(certificate_report, indent=2, sort_keys=False) + "\n"
    try:
        output.write_bytes(payload.encode("utf-8"))
        print(f"wrote {output}")
        certificate_output.write_bytes(certificate_payload.encode("utf-8"))
        print(f"wrote {certificate_output}")
    except OSError:
        print("BEGIN_JSON_PAYLOAD")
        print(payload, end="")
        print("END_JSON_PAYLOAD")


if __name__ == "__main__":
    main()
