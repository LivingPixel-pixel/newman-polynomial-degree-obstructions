#!/usr/bin/env python3
"""Dependency-free exact audit for the predecessor safe-lattice theorem.

The proof in the manuscript is infinite and analytic.  This script audits its
polynomial identities over Z[t] for every odd 5 <= v <= 151 and records the
exact rational margins used in the uniform inequalities.  It is an
independent audit, not a replacement for the proof.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path


Poly = tuple[int, ...]  # coefficients from low to high degree


def trim(values: list[int]) -> Poly:
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return tuple(values)


def add(left: Poly, right: Poly) -> Poly:
    size = max(len(left), len(right))
    values = [0] * size
    for index, value in enumerate(left):
        values[index] += value
    for index, value in enumerate(right):
        values[index] += value
    return trim(values)


def neg(poly: Poly) -> Poly:
    return tuple(-value for value in poly)


def sub(left: Poly, right: Poly) -> Poly:
    return add(left, neg(right))


def shift(poly: Poly, amount: int = 1, scale: int = 1) -> Poly:
    if poly == (0,) or scale == 0:
        return (0,)
    return (0,) * amount + tuple(scale * value for value in poly)


ZERO: Poly = (0,)
ONE: Poly = (1,)


def partial(k: int, m: int) -> Poly:
    return tuple((-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1))


def sequences(v: int, limit: int) -> tuple[list[Poly], list[Poly], list[Poly]]:
    r = [ZERO for _ in range(limit + 1)]
    even = [ZERO for _ in range(limit + 1)]
    q = [ZERO for _ in range(6 * v + 1)]
    q[0] = ONE
    for m in range(limit + 1):
        value = ONE
        if m >= 1:
            value = sub(value, shift(r[m - 1], scale=2))
        if m >= 2:
            value = sub(value, shift(r[m - 2], amount=2))
        if m >= v:
            value = add(value, r[m - v])
        r[m] = value

        e = ONE
        if m >= 1:
            e = sub(e, shift(r[m - 1]))
        if m >= 2:
            e = sub(e, shift(r[m - 2], amount=2))
        even[m] = e

    for n in range(1, 6 * v + 1):
        value = ONE if n % 2 == 0 or n >= v else ZERO
        if n >= 2:
            value = sub(value, shift(q[n - 2]))
        if n >= v:
            value = sub(value, q[n - v])
        q[n] = value
    return r, even, q


def fvalue(k: int, power: int, t: Fraction) -> Fraction:
    return Fraction(1, 1) / (1 + t) ** power + sum(
        Fraction((-1) ** ell * math.comb(k + ell, ell)) * t**ell
        for ell in range(k + 1)
    )


def pvalue(k: int, m: int, t: Fraction) -> Fraction:
    return sum(
        Fraction((-1) ** ell * math.comb(k + ell, ell)) * t**ell
        for ell in range(m + 1)
    )


def rational_margins() -> dict[str, str]:
    t383 = Fraction(383, 1000)
    t433 = Fraction(433, 1000)
    t487 = Fraction(487, 1000)
    half = Fraction(1, 2)

    p1_6_gap = pvalue(1, 6, t383) - (4 * t383 - 1)
    assert p1_6_gap < 0

    lower_s1 = 1 - 2 * t383 - t383 / (1 + t383) ** 3
    assert lower_s1 > 0

    lower_root_s3 = Fraction(1, 1) / (1 + t433) ** 2 + pvalue(3, 3, t433)
    upper_even_s3 = Fraction(1, 1) / (1 + t433) - t433 * pvalue(4, 2, t433)
    assert lower_root_s3 > 0 and upper_even_s3 < 0

    lower_root_s5 = Fraction(1, 1) / (1 + t487) ** 2 + pvalue(3, 5, t487)
    upper_even_s5 = Fraction(1, 1) / (1 + t487) - t487 * pvalue(4, 4, t487)
    assert lower_root_s5 > 0 and upper_even_s5 < 0

    lower_no_late_roots = Fraction(1, 1) / (1 + half) ** 2 + pvalue(3, 7, half)
    assert lower_no_late_roots == Fraction(37, 144) > 0
    assert pvalue(2, 5, half) == Fraction(1, 32) > 0

    # The common odd-event bound is positive because its numerator is at
    # least 1/16 on 0 < t <= 1/2 (the manuscript gives the grouping).
    common_odd_margin = Fraction(1, 16)

    return {
        "P1_6_minus_4t_minus_1_at_383_over_1000": str(p1_6_gap),
        "s1_block_lower_bound_at_383_over_1000": str(lower_s1),
        "s3_root_exclusion_margin_at_433_over_1000": str(lower_root_s3),
        "s3_even_event_upper_bound_at_433_over_1000": str(upper_even_s3),
        "s5_root_exclusion_margin_at_487_over_1000": str(lower_root_s5),
        "s5_even_event_upper_bound_at_487_over_1000": str(upper_even_s5),
        "late_odd_partial_lower_bound_at_one_half": str(lower_no_late_roots),
        "P2_5_at_one_half": str(pvalue(2, 5, half)),
        "common_odd_event_numerator_margin": str(common_odd_margin),
    }


def audit_v(v: int) -> dict[str, int]:
    assert v >= 5 and v % 2 == 1
    r, even, q = sequences(v, 3 * v)
    closed_form_checks = 0
    for m in range(2 * v):
        expected = partial(1, m)
        if m >= v:
            expected = add(expected, partial(3, m - v))
        assert r[m] == expected, (v, m)
        closed_form_checks += 1

    parity_checks = 0
    safe_pair_checks = 0
    for m in range(3 * v + 1):
        assert q[2 * m] == even[m], (v, "even", m)
        if m >= 1 and v + 2 * m <= 6 * v:
            assert q[v + 2 * m] == shift(r[m - 1]), (v, "odd", m)
        parity_checks += 1

    for j in range(2 * v):
        odd_n = v + 2 * j + 4
        assert q[odd_n - 2] == shift(r[j])
        assert q[odd_n - v] == even[j + 2]
        safe_pair_checks += 1

        even_n = 2 * j + 2 * v + 2
        assert q[even_n - v] == shift(r[j])
        assert q[even_n - 2] == even[j + v]
        safe_pair_checks += 1

    return {
        "v": v,
        "closed_form_checks": closed_form_checks,
        "parity_checks": parity_checks,
        "safe_pair_checks": safe_pair_checks,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v-max", type=int, default=151)
    parser.add_argument("--output", type=Path, default=Path("predecessor_safe_lattice_exact.json"))
    args = parser.parse_args()
    assert args.v_max >= 5
    v_values = list(range(5, args.v_max + 1, 2))
    records = [audit_v(v) for v in v_values]
    report = {
        "schema_version": 1,
        "proof_status": "exact_identity_audit_supporting_infinite_manuscript_proof",
        "theorem": {
            "odd_first_escape_index_at_least": "5*v+4",
            "even_first_escape_index_at_least": "6*v+2",
            "scope": "odd v>=5 and 0<a<1/2, assuming all preceding forced coefficients are nonnegative",
        },
        "audited_v_values": v_values,
        "totals": {
            "v_count": len(records),
            "closed_form_checks": sum(item["closed_form_checks"] for item in records),
            "parity_checks": sum(item["parity_checks"] for item in records),
            "safe_pair_checks": sum(item["safe_pair_checks"] for item in records),
        },
        "exact_rational_margins": rational_margins(),
        "records": records,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(
        "PASS: exact safe-lattice identities for "
        f"{len(records)} odd exponents through v={v_values[-1]}"
    )
    print(json.dumps(report["totals"], sort_keys=True))
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
