#!/usr/bin/env python3
"""Independent exact sign and gcd audit for the six-block theorem."""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path

import sympy as sp

T = sp.Symbol("t")
S = sp.Symbol("s")
HALF = sp.Rational(1, 2)
ZERO = sp.Poly(0, T, domain=sp.ZZ)
ONE = sp.Poly(1, T, domain=sp.ZZ)

INTERVALS = {
    1: (sp.Rational(226, 1000), sp.Rational(228, 1000)),
    3: (sp.Rational(220, 1000), sp.Rational(222, 1000)),
    5: (sp.Rational(246, 1000), sp.Rational(248, 1000)),
    7: (sp.Rational(274, 1000), sp.Rational(276, 1000)),
    9: (sp.Rational(301, 1000), sp.Rational(303, 1000)),
    11: (sp.Rational(326, 1000), sp.Rational(329, 1000)),
    13: (sp.Rational(350, 1000), sp.Rational(352, 1000)),
    15: (sp.Rational(371, 1000), sp.Rational(374, 1000)),
    17: (sp.Rational(391, 1000), sp.Rational(394, 1000)),
    19: (sp.Rational(410, 1000), sp.Rational(413, 1000)),
    21: (sp.Rational(427, 1000), sp.Rational(430, 1000)),
    23: (sp.Rational(443, 1000), sp.Rational(446, 1000)),
    25: (sp.Rational(458, 1000), sp.Rational(462, 1000)),
    27: (sp.Rational(472, 1000), sp.Rational(476, 1000)),
    29: (sp.Rational(486, 1000), sp.Rational(489, 1000)),
    31: (sp.Rational(499, 1000), sp.Rational(4999, 10000)),
}
EXCEPTION_CASES = tuple(
    [(v, 0) for v in range(5, 22, 2)]
    + [(v, 2) for v in range(5, 14, 2)]
    + [(v, 1) for v in range(5, 18, 2)]
    + [(v, 3) for v in range(5, 10, 2)]
)


def partial(k: int, m: int) -> sp.Expr:
    return sp.expand(sum((-1) ** ell * sp.binomial(k + ell, ell) * T**ell for ell in range(m + 1)))


def minimum_v(offset: int) -> int:
    if offset == 1:
        return 19
    if offset == 3:
        return 11
    return offset + 2


def as_fraction(value: sp.Rational) -> Fraction:
    value = sp.Rational(value)
    return Fraction(int(value.p), int(value.q))


def interval_multiply(left: tuple[Fraction, Fraction], right: tuple[Fraction, Fraction]) -> tuple[Fraction, Fraction]:
    products = tuple(a * b for a in left for b in right)
    return min(products), max(products)


def horner_enclosure(coefficients: list[Fraction], left: Fraction, right: Fraction) -> tuple[Fraction, Fraction]:
    enclosure = (coefficients[-1], coefficients[-1])
    interval = (left, right)
    for coefficient in reversed(coefficients[:-1]):
        lo, hi = interval_multiply(enclosure, interval)
        enclosure = (lo + coefficient, hi + coefficient)
    return enclosure


def certify_sign(name: str, expr: sp.Expr, left: sp.Rational, right: sp.Rational, expected: int) -> dict[str, object]:
    numerator, denominator = sp.cancel(expr).as_numer_denom()
    den = sp.Poly(denominator, T, domain=sp.QQ)
    assert all(value > 0 for value in (den.eval(left), den.eval(right)))
    poly = sp.Poly(numerator, T, domain=sp.QQ)
    coefficients = [as_fraction(value) for value in reversed(poly.all_coeffs())]
    stack = [(as_fraction(left), as_fraction(right), 0)]
    leaves: list[tuple[Fraction, Fraction, Fraction, Fraction, int]] = []
    while stack:
        a, b, depth = stack.pop()
        lo, hi = horner_enclosure(coefficients, a, b)
        if (expected > 0 and lo > 0) or (expected < 0 and hi < 0):
            leaves.append((a, b, lo, hi, depth))
            continue
        assert depth < 40, (name, a, b, lo, hi)
        mid = (a + b) / 2
        stack.append((mid, b, depth + 1))
        stack.append((a, mid, depth + 1))
    assert sp.sign(expr.subs(T, left)) == expected
    assert sp.sign(expr.subs(T, right)) == expected
    return {
        "name": name,
        "interval": [str(left), str(right)],
        "expected_sign": expected,
        "numerator_degree": int(poly.degree()),
        "exact_horner_leaf_count": len(leaves),
        "exact_horner_max_depth": max(item[4] for item in leaves),
        "left_value": str(sp.factor(expr.subs(T, left))),
        "right_value": str(sp.factor(expr.subs(T, right))),
    }


def build_sign_certificates() -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for offset, v0 in ((0, 23), (2, 15), (4, 5), (6, 7), (8, 9)):
        lower = (
            partial(1, 5 * v0 + offset) + (1 + T) ** -4
            + partial(5, 3 * v0 + offset) + (1 + T) ** -8
            + partial(9, v0 + offset) + partial(11, offset)
        )
        records.append(certify_sign(f"even_offset_{offset}_lower", lower, 0, HALF, 1))

    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = (
            (1 + T) ** -2 + partial(3, 4 * v0 + offset)
            + (1 + T) ** -6 + partial(7, 2 * v0 + offset)
            + (1 + T) ** -10 + partial(11, offset)
        )
        upper = (
            partial(1, 5 * v0 + offset) + (1 + T) ** -4
            + partial(5, 3 * v0 + offset) + (1 + T) ** -8
            + partial(9, v0 + offset) + partial(11, offset)
        )
        records.append(certify_sign(f"offset_{offset}_lower_before_alpha", lower, 0, alpha, 1))
        records.append(certify_sign(f"offset_{offset}_upper_after_beta", upper, beta, HALF, -1))
        if offset == 1:
            companion = (
                (1 - T ** (6 * v0 + offset + 1)) / (1 + T)
                - T * ((1 + T) ** -3 + partial(4, 4 * v0 + offset - 1)
                       + (1 + T) ** -7 + partial(8, 2 * v0 + offset - 1)
                       + (1 + T) ** -11 + partial(12, offset - 1))
            )
            expected = 1
        else:
            companion = (
                (1 + T) ** -1
                - T * (partial(2, 5 * v0 + offset - 1) + (1 + T) ** -5
                       + partial(6, 3 * v0 + offset - 1) + (1 + T) ** -9
                       + partial(10, v0 + offset - 1) + partial(12, offset - 1))
            )
            expected = -1
        records.append(certify_sign(f"offset_{offset}_even_companion_bound", companion, alpha, beta, expected))
    assert len(records) == 53
    return records


def positive_coefficients(expr: sp.Expr, shift: int) -> list[int]:
    numerator = sp.together(expr).as_numer_denom()[0]
    poly = sp.Poly(sp.expand(numerator.subs(S, S + shift)), S, domain=sp.QQ)
    coefficients = [int(value) for value in poly.all_coeffs()]
    assert all(value > 0 for value in coefficients)
    return coefficients


def tail_certificates() -> dict[str, object]:
    a11 = sp.prod(S + i for i in range(2, 13)) / sp.factorial(11)
    a9 = sp.prod(2 * S + i for i in range(3, 12)) / sp.factorial(9)
    a5 = sp.prod(4 * S + i for i in range(5, 10)) / sp.factorial(5)
    a1 = 6 * S + 7
    factor = 2 * (S + 2) / (S - 9)
    even_terms = [
        a9 / a11 * factor / 2 ** (S + 1),
        a5 / a11 * factor / 2 ** (3 * S + 3),
        a1 / a11 * factor / 2 ** (5 * S + 5),
    ]
    even_base = sp.factor(sum(term.subs(S, 10) for term in even_terms))
    assert even_base < 1
    even_step = [positive_coefficients(1 - sp.cancel(term.subs(S, S + 2) / term), 10) for term in even_terms]

    odd_terms = [
        sp.prod(S + i for i in range(2, 13)) / sp.factorial(11) / 2 ** (S + 1),
        sp.prod(3 * S + i for i in range(6, 13)) / sp.factorial(7) / 2 ** (3 * S + 5),
        sp.prod(5 * S + i for i in range(10, 13)) / sp.factorial(3) / 2 ** (5 * S + 9),
    ]
    odd_base = sp.factor(sum(term.subs(S, 33) for term in odd_terms))
    odd_limit = sp.factor(sum(sp.Rational(2, 3) ** (2 * k + 2) for k in range(6)))
    assert odd_base < odd_limit
    odd_step = [positive_coefficients(1 - sp.cancel(term.subs(S, S + 2) / term), 33) for term in odd_terms]
    return {
        "even_offsets_at_least_10": {
            "normalized_tail_sum_at_s_10": str(even_base),
            "strictly_below_one": True,
            "shifted_one_minus_step_ratio_numerator_coefficients_descending": even_step,
        },
        "odd_offsets_at_least_33": {
            "tail_error_at_s_33": str(odd_base),
            "six_limit_terms_lower_bound": str(odd_limit),
            "error_strictly_below_limit_lower_bound": True,
            "shifted_one_minus_step_ratio_numerator_coefficients_descending": odd_step,
        },
    }


def sequences(v: int, limit: int) -> tuple[list[sp.Poly], list[sp.Poly]]:
    r = [ZERO for _ in range(limit + 1)]
    even = [ZERO for _ in range(limit + 1)]
    for m in range(limit + 1):
        value = ONE
        if m >= 1:
            value -= sp.Poly(2 * T, T, domain=sp.ZZ) * r[m - 1]
        if m >= 2:
            value -= sp.Poly(T**2, T, domain=sp.ZZ) * r[m - 2]
        if m >= v:
            value += r[m - v]
        r[m] = value
        evalue = ONE
        if m >= 1:
            evalue -= sp.Poly(T, T, domain=sp.ZZ) * r[m - 1]
        if m >= 2:
            evalue -= sp.Poly(T**2, T, domain=sp.ZZ) * r[m - 2]
        even[m] = evalue
    return r, even


def gcd_certificates() -> list[dict[str, object]]:
    records = []
    for v, offset in EXCEPTION_CASES:
        r, even = sequences(v, 7 * v + 2)
        j = 5 * v + offset
        for name, companion in (("odd", even[j + 2]), ("even", even[j + v])):
            left = r[j]
            assert left.content() == companion.content() == 1
            found = None
            for prime in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31):
                left_mod = sp.Poly(left.as_expr(), T, modulus=prime)
                right_mod = sp.Poly(companion.as_expr(), T, modulus=prime)
                if left_mod.degree() != left.degree() or right_mod.degree() != companion.degree():
                    continue
                gcd_poly = sp.gcd(left_mod, right_mod).monic()
                if gcd_poly.degree() == 0:
                    found = prime
                    break
            assert found is not None
            records.append({"v": v, "offset": offset, "j": j, "companion": name,
                            "prime": found, "left_primitive": True, "right_primitive": True,
                            "degrees_preserved_mod_p": True, "gcd_degree_mod_p": 0, "gcd_monic_mod_p": "1"})
    assert len(records) == 48
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("predecessor_six_block_signs_exact.json"))
    args = parser.parse_args()
    signs = build_sign_certificates()
    gcds = gcd_certificates()
    report = {
        "schema_version": 1,
        "line_ending_and_hash_convention": "UTF-8 bytes with canonical LF newlines",
        "proof_status": "independent_exact_audit_supporting_uniform_six_block_manuscript_proof",
        "theorem": {"odd_first_escape_index_at_least": "13*v+4", "even_first_escape_index_at_least": "14*v+2", "scope": "odd v>=5 and 0<t<1/2"},
        "exact_interval_horner_sign_certificate_count": len(signs),
        "tail_certificates": tail_certificates(),
        "finite_exception_modular_gcd_certificate_count": len(gcds),
        "sign_certificates": signs,
        "finite_exception_modular_gcd_certificates": gcds,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(f"PASS: {len(signs)} exact interval signs and {len(gcds)} modular gcds")


if __name__ == "__main__":
    main()
