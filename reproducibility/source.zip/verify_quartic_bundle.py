#!/usr/bin/env python3
"""Cross-check the exact retained quartic proof-object bundle."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def load(path: Path):
    data = path.read_bytes()
    return json.loads(data), hashlib.sha256(data).hexdigest(), len(data)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", type=Path, required=True)
    parser.add_argument("--tail", type=Path, required=True)
    parser.add_argument("--finite", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, action="append", required=True)
    args = parser.parse_args()

    catalog, catalog_hash, catalog_size = load(args.catalog)
    tail, tail_hash, tail_size = load(args.tail)
    finite, finite_hash, finite_size = load(args.finite)
    prefix_parts = [load(path) for path in args.prefix]

    assert catalog["counts"] == {
        "raw_nonzero_constant": 1691646,
        "strict_schur_disk": 63546,
        "irreducible": 57238,
        "target_root": 10671,
        "real_conjugate_sieve": 6977,
    }
    assert len(catalog["candidate_catalog"]) == 6977
    assert sum(x["target_root_count"] for x in catalog["candidate_catalog"]) == 6982

    tail_records = tail["records"]
    assert tail["root_count"] == len(tail_records) == 6982
    assert tail["failures"] == 0 and tail["max_k_used"] <= 110
    assert tail["max_offset_searched"] == 100
    tail_keys = []
    for record in tail_records:
        key = record["candidate_id"], record["root_index"]
        tail_keys.append(key)
        cert = record["certificate"]
        assert cert["status"] == "certified"
        assert 1 <= cert["k"] <= 110 and 2 <= cert["offset"] <= 100
        if cert["k"] % 2:
            assert cert["offset"] % 4 == 0
        else:
            assert cert["offset"] % 4 == 2
    assert len(set(tail_keys)) == 6982

    assert finite["root_count"] == len(finite["records"]) == 6982
    assert finite["failures"] == []
    assert finite["finite_v"] == list(range(5, 22, 2))
    finite_keys = []
    for record in finite["records"]:
        finite_keys.append((record["candidate_id"], record["root_index"]))
        for v in finite["finite_v"]:
            result = record["finite"][str(v)]
            assert result["status"] == "negative" and result["zeros"] == [v]
    assert finite_keys == tail_keys

    prefix_records = []
    expected_start = 1
    prefix_meta = []
    for path, (part, digest, size) in zip(args.prefix, prefix_parts):
        assert part["start_root"] == expected_start
        assert part["root_count"] == part["end_root"] - part["start_root"] + 1
        assert part["failures"] == []
        assert all(x["status"] == "positive" for x in part["records"])
        prefix_records.extend(part["records"])
        expected_start = part["end_root"] + 1
        prefix_meta.append({"path": str(path), "sha256": digest, "size": size, "blocks": part["total_blocks_checked"]})
    assert expected_start == 6983 and len(prefix_records) == 6982
    prefix_keys = [(x["candidate_id"], x["root_index"]) for x in prefix_records]
    assert prefix_keys == tail_keys
    for prefix, tail_record in zip(prefix_records, tail_records):
        cert = tail_record["certificate"]
        assert prefix["obstruction_k"] == cert["k"]
        assert prefix["obstruction_offset"] == cert["offset"]

    report = {
        "status": "PASS",
        "catalog_polynomials": 6977,
        "target_roots": 6982,
        "finite_root_exponent_pairs": 6982 * 9,
        "maximum_obstruction_block": tail["max_k_used"],
        "catalog": {"sha256": catalog_hash, "size": catalog_size},
        "tail": {"sha256": tail_hash, "size": tail_size},
        "finite": {"sha256": finite_hash, "size": finite_size},
        "prefix_parts": prefix_meta,
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
