#!/usr/bin/env python3
"""Exact verifier for a global forced-recurrence cubic obstruction.

The target-root catalog is taken from the independently checked cubic sieve.
For each cubic, the verifier does two things:

1. It uses exact arithmetic in Z[a]/(m_a) and rational interval signs to find
   a negative forced cofactor coefficient for each odd v=5,...,21.
2. It proves one coefficient b_{K v+r} is negative for every odd v>=23 by
   comparing its exact block expansion with its v->infinity limit and bounding
   every alternating-binomial tail by its first omitted rational term.

No floating point, LP, or SMT result is used.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import json
import math
from pathlib import Path
import sys

sys.set_int_max_str_digits(0)


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "cubic_gap2_degree75_results.json"
OUTPUT = ROOT / "forced_recurrence_global_exact.json"
FINITE_V = tuple(range(5, 22, 2))
TAIL_START_V = 23

Element = tuple[int, int, int]
Interval = tuple[Fraction, Fraction]


def parse_fraction(text: str) -> Fraction:
    return Fraction(text)


def interval_add(x: Interval, y: Interval) -> Interval:
    return x[0] + y[0], x[1] + y[1]


def interval_neg(x: Interval) -> Interval:
    return -x[1], -x[0]


def interval_sub(x: Interval, y: Interval) -> Interval:
    return interval_add(x, interval_neg(y))


def interval_mul(x: Interval, y: Interval) -> Interval:
    products = (x[0] * y[0], x[0] * y[1], x[1] * y[0], x[1] * y[1])
    return min(products), max(products)


def interval_pow(x: Interval, exponent: int) -> Interval:
    assert 0 <= x[0] <= x[1] and exponent >= 0
    return x[0] ** exponent, x[1] ** exponent


def interval_reciprocal(x: Interval) -> Interval:
    assert 0 < x[0] <= x[1]
    return 1 / x[1], 1 / x[0]


def polynomial_interval(coefficients: list[int], x: Interval) -> Interval:
    value = (Fraction(coefficients[-1]), Fraction(coefficients[-1]))
    for coefficient in reversed(coefficients[:-1]):
        value = interval_add(interval_mul(value, x), (Fraction(coefficient), Fraction(coefficient)))
    return value


def cubic_value(polynomial: tuple[int, int, int], x: Fraction) -> Fraction:
    s2, s1, s0 = polynomial
    return ((x + s2) * x + s1) * x + s0


@dataclass
class AlgebraicRoot:
    polynomial: tuple[int, int, int]
    interval: Interval

    def refine(self) -> None:
        left, right = self.interval
        middle = (left + right) / 2
        f_left = cubic_value(self.polynomial, left)
        f_middle = cubic_value(self.polynomial, middle)
        f_right = cubic_value(self.polynomial, right)
        assert f_left and f_right and f_left * f_right < 0
        if f_left * f_middle < 0:
            self.interval = left, middle
        elif f_middle * f_right < 0:
            self.interval = middle, right
        else:
            raise AssertionError("target root unexpectedly hit a rational midpoint")

    def sign(self, element: Element) -> int:
        if element == (0, 0, 0):
            return 0
        for _ in range(10000):
            value = polynomial_interval(list(element), self.interval)
            if value[0] > 0:
                return 1
            if value[1] < 0:
                return -1
            self.refine()
        raise RuntimeError("failed to separate an algebraic-element sign")


def add(x: Element, y: Element) -> Element:
    return tuple(a + b for a, b in zip(x, y))  # type: ignore[return-value]


def neg(x: Element) -> Element:
    return -x[0], -x[1], -x[2]


def multiply_by_a(x: Element, polynomial: tuple[int, int, int]) -> Element:
    s2, s1, s0 = polynomial
    c0, c1, c2 = x
    return -s0 * c2, c0 - s1 * c2, c1 - s2 * c2


def forced_negative(root: AlgebraicRoot, v: int, limit: int) -> dict:
    zero: Element = (0, 0, 0)
    one: Element = (1, 0, 0)
    b: list[Element] = [zero] * (limit + 1)
    b[0] = one
    positive_count = 1
    zero_indices: list[int] = []
    for n in range(1, limit + 1):
        if n < v and n % 2:
            b[n] = zero
            continue
        forcing = zero
        if n >= 2:
            forcing = add(forcing, multiply_by_a(b[n - 2], root.polynomial))
        if n >= v:
            forcing = add(forcing, b[n - v])
        forcing_sign = root.sign(forcing)
        if forcing_sign <= 0:
            return {"status": "failed", "reason": "nonpositive_forcing", "n": n, "forcing": list(forcing)}
        b[n] = add(one, neg(forcing))
        coefficient_sign = root.sign(b[n])
        if coefficient_sign < 0:
            return {
                "status": "negative",
                "n": n,
                "coefficient": list(b[n]),
                "strictly_positive_predecessor_count": positive_count,
                "structural_zero_indices": zero_indices,
            }
        if coefficient_sign == 0:
            zero_indices.append(n)
        else:
            positive_count += 1
    return {"status": "failed", "reason": "limit_reached", "limit": limit}


def partial_binomial_interval(k: int, m: int, a: Interval) -> Interval:
    coefficients = [(-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1)]
    return polynomial_interval(coefficients, a)


def limit_interval(k: int, offset: int, a: Interval) -> Interval:
    """Interval for lim_{odd v->infinity} b_{k v+offset}."""
    assert offset in (4, 6, 8)
    top_m = (offset - 2) // 2
    top = interval_mul(a, partial_binomial_interval(k, top_m, a))
    one_plus_a = interval_add((Fraction(1), Fraction(1)), a)
    if k % 2:
        assert offset in (4, 8)
        value = top
        for j in range(1, k, 2):
            inverse = interval_reciprocal(interval_pow(one_plus_a, j + 1))
            value = interval_add(value, interval_mul(a, inverse))
        return value
    assert offset == 6
    value = interval_reciprocal(one_plus_a)
    value = interval_sub(value, top)
    for j in range(2, k, 2):
        inverse = interval_reciprocal(interval_pow(one_plus_a, j + 1))
        value = interval_sub(value, interval_mul(a, inverse))
    return value


def tail_error_bound(k: int, offset: int, v: int, upper_a: Fraction) -> Fraction | None:
    """Absolute difference between b_{kv+offset} and its limiting value."""
    assert v % 2 and v >= TAIL_START_V
    error = Fraction(0)
    if k % 2 == 0:
        base_m = (k * v + offset) // 2
        error += upper_a ** (base_m + 1)
        lower_indices = range(2, k, 2)
    else:
        lower_indices = range(1, k, 2)
    for j in lower_indices:
        m = ((k - j) * v + offset - 2) // 2
        # From this point onward the alternating term magnitudes decrease.
        if upper_a * (j + m + 2) >= m + 2:
            return None
        first_omitted = Fraction(math.comb(j + m + 1, m + 1)) * upper_a ** (m + 1)
        error += upper_a * first_omitted
    return error


def find_tail_certificate(root: AlgebraicRoot) -> dict:
    candidates: list[tuple[int, int]] = []
    for k in range(3, 28):
        if k % 2:
            candidates.extend(((k, 4), (k, 8)))
        else:
            candidates.append((k, 6))
    candidates.sort(key=lambda item: item[0] * TAIL_START_V + item[1])
    for k, offset in candidates:
        limit = limit_interval(k, offset, root.interval)
        error = tail_error_bound(k, offset, TAIL_START_V, root.interval[1])
        if error is None:
            continue
        if limit[1] + error < 0:
            return {
                "status": "certified",
                "k": k,
                "offset": offset,
                "coefficient_index": f"{k}*v+{offset}",
                "limit_interval": [str(limit[0]), str(limit[1])],
                "uniform_tail_error_bound_from_v23": str(error),
                "certified_upper_bound": str(limit[1] + error),
            }
    return {"status": "failed"}


def main() -> None:
    baseline = json.loads(RESULTS.read_text(encoding="utf-8"))
    records = []
    for item in baseline["candidate_catalog"]:
        candidate_id = int(item["candidate_id"])
        polynomial = tuple(item["minimal_polynomial_coefficients"])
        target_intervals = [
            (parse_fraction(interval["left"]), parse_fraction(interval["right"]))
            for interval in item["sturm"]["real_root_intervals"]
            if Fraction(0) < parse_fraction(interval["left"])
            and parse_fraction(interval["right"]) < Fraction(1, 2)
        ]
        assert len(target_intervals) == 1
        root = AlgebraicRoot(polynomial, target_intervals[0])
        finite = {}
        for v in FINITE_V:
            result = forced_negative(root, v, 40 * v)
            assert result["status"] == "negative", (candidate_id, v, result)
            assert result["structural_zero_indices"] == [v], (
                candidate_id,
                v,
                result["structural_zero_indices"],
            )
            finite[str(v)] = result
        tail = find_tail_certificate(root)
        assert tail["status"] == "certified", (candidate_id, tail)
        # Direct exact recurrence at v=23 independently checks the chosen block.
        check_limit = tail["k"] * TAIL_START_V + tail["offset"]
        direct = forced_negative(root, TAIL_START_V, check_limit)
        assert direct["status"] == "negative" and direct["n"] <= check_limit
        assert direct["structural_zero_indices"] == [TAIL_START_V], (
            candidate_id,
            direct["structural_zero_indices"],
        )
        records.append(
            {
                "candidate_id": candidate_id,
                "minimal_polynomial_coefficients": list(polynomial),
                "final_target_root_interval": [str(root.interval[0]), str(root.interval[1])],
                "finite_odd_v_5_through_21": finite,
                "uniform_odd_v_at_least_23": tail,
                "direct_v23_first_negative": direct,
            }
        )
        print(
            f"candidate {candidate_id}/126: finite exact signs and tail {tail['coefficient_index']}",
            flush=True,
        )
    report = {
        "schema_version": 1,
        "proof_status": "exact_global_forced_recurrence_obstruction_for_catalog",
        "candidate_count": len(records),
        "finite_case_values": list(FINITE_V),
        "uniform_tail_start_v": TAIL_START_V,
        "tail_argument": (
            "Exact block expansion plus first-omitted-term bounds for decreasing "
            "alternating binomial tails; every certified upper bound is negative."
        ),
        "records": records,
    }
    OUTPUT.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(f"wrote {OUTPUT}")


if __name__ == "__main__":
    main()
