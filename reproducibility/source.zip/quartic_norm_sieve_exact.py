#!/usr/bin/env python3
"""Exact quartic norm-sieve catalog for the retained proof bundle.

The output is independently replayed by the Schur--Cohn/FLINT/Arb audit shipped
with this version.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path


R_NUM = 143
R_DEN = 50
BOUNDS = (9, 28, 35, 11)
MAX_WIDTH = Fraction(1, 2**36)


def trim(poly: list[Fraction]) -> list[Fraction]:
    while len(poly) > 1 and poly[-1] == 0:
        poly.pop()
    return poly


def derivative(poly: list[Fraction]) -> list[Fraction]:
    return [Fraction(i) * poly[i] for i in range(1, len(poly))] or [Fraction(0)]


def divmod_poly(a: list[Fraction], b: list[Fraction]):
    rem = trim(a.copy())
    div = trim(b.copy())
    quo = [Fraction(0)] * max(1, len(rem) - len(div) + 1)
    while rem != [0] and len(rem) >= len(div):
        shift = len(rem) - len(div)
        factor = rem[-1] / div[-1]
        quo[shift] += factor
        for i, coefficient in enumerate(div):
            rem[i + shift] -= factor * coefficient
        trim(rem)
    return trim(quo), trim(rem)


def sturm(poly: list[Fraction]) -> list[list[Fraction]]:
    seq = [poly, derivative(poly)]
    while True:
        _, rem = divmod_poly(seq[-2], seq[-1])
        if rem == [0]:
            return seq
        seq.append([-x for x in rem])


def evaluate(poly: list[Fraction], x: Fraction) -> Fraction:
    value = Fraction(0)
    for coefficient in reversed(poly):
        value = value * x + coefficient
    return value


def variations(seq: list[list[Fraction]], x: Fraction) -> int:
    signs = []
    for poly in seq:
        value = evaluate(poly, x)
        if value:
            signs.append(1 if value > 0 else -1)
    return sum(a != b for a, b in zip(signs, signs[1:]))


def root_count(seq: list[list[Fraction]], left: Fraction, right: Fraction) -> int:
    return variations(seq, left) - variations(seq, right)


def isolate(seq: list[list[Fraction]], left: Fraction, right: Fraction):
    pending = [(left, right, root_count(seq, left, right))]
    result = []
    while pending:
        lo, hi, count = pending.pop()
        if count == 0:
            continue
        if count == 1 and hi - lo <= MAX_WIDTH:
            result.append((lo, hi))
            continue
        mid = (lo + hi) / 2
        lc = root_count(seq, lo, mid)
        rc = count - lc
        if rc:
            pending.append((mid, hi, rc))
        if lc:
            pending.append((lo, mid, lc))
    return sorted(result)


def strict_schur(s3: int, s2: int, s1: int, s0: int) -> bool:
    # Coefficients high-to-low of 50^4 p((143/50)z).
    coefficients = [
        R_NUM**4,
        s3 * R_NUM**3 * R_DEN,
        s2 * R_NUM**2 * R_DEN**2,
        s1 * R_NUM * R_DEN**3,
        s0 * R_DEN**4,
    ]
    while len(coefficients) > 1:
        leading, constant = coefficients[0], coefficients[-1]
        if leading * leading <= constant * constant:
            return False
        degree = len(coefficients) - 1
        coefficients = [
            leading * coefficients[i] - constant * coefficients[degree - i]
            for i in range(degree)
        ]
    return True


def reducible(s3: int, s2: int, s1: int, s0: int) -> bool:
    # Integer linear factors.
    for d in range(1, abs(s0) + 1):
        if s0 % d:
            continue
        for root in (d, -d):
            if root**4 + s3 * root**3 + s2 * root**2 + s1 * root + s0 == 0:
                return True
    # Monic quadratic factors. Disk-bounded roots force |linear coeff|<=5
    # and |constant|<=8, so this finite test is complete after Schur.
    for b in range(-8, 9):
        if b == 0 or s0 % b:
            continue
        d = s0 // b
        if abs(d) > 8:
            continue
        for a in range(-5, 6):
            c = s3 - a
            if abs(c) > 5:
                continue
            if a * c + b + d == s2 and a * d + b * c == s1:
                return True
    return False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    counts = {
        "raw_nonzero_constant": 0,
        "strict_schur_disk": 0,
        "irreducible": 0,
        "target_root": 0,
        "real_conjugate_sieve": 0,
    }
    catalog = []
    for s3 in range(-BOUNDS[0], BOUNDS[0] + 1):
        for s2 in range(-BOUNDS[1], BOUNDS[1] + 1):
            for s1 in range(-BOUNDS[2], BOUNDS[2] + 1):
                for s0 in range(-BOUNDS[3], BOUNDS[3] + 1):
                    if s0 == 0:
                        continue
                    counts["raw_nonzero_constant"] += 1
                    if not strict_schur(s3, s2, s1, s0):
                        continue
                    counts["strict_schur_disk"] += 1
                    if reducible(s3, s2, s1, s0):
                        continue
                    counts["irreducible"] += 1
                    poly = [Fraction(s0), Fraction(s1), Fraction(s2), Fraction(s3), Fraction(1)]
                    seq = sturm(poly)
                    target_count = root_count(seq, Fraction(0), Fraction(1, 2))
                    if target_count == 0:
                        continue
                    counts["target_root"] += 1
                    if evaluate(poly, Fraction(-2)) == 0 or root_count(seq, Fraction(-3), Fraction(-2)):
                        continue
                    counts["real_conjugate_sieve"] += 1
                    intervals = isolate(seq, Fraction(0), Fraction(1, 2))
                    catalog.append(
                        {
                            "candidate_id": len(catalog) + 1,
                            "minimal_polynomial_coefficients": [s3, s2, s1, s0],
                            "target_root_count": target_count,
                            "target_root_intervals": [
                                {"left": str(a), "right": str(b)} for a, b in intervals
                            ],
                        }
                    )
        print(f"s3={s3}: catalog={len(catalog)} counts={counts}", flush=True)
    report = {
        "schema_version": 1,
        "proof_status": "exact_complete_uniform_quartic_norm_sieve",
        "disk_bound": f"{R_NUM}/{R_DEN}",
        "coefficient_bounds_s3_s2_s1_s0": list(BOUNDS),
        "target_interval": ["0", "1/2"],
        "real_conjugate_lower_bound": "-2",
        "counts": counts,
        "candidate_catalog": catalog,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    main()
