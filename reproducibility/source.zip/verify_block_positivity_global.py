#!/usr/bin/env python3
"""Exact uniform positivity check before each global recurrence obstruction.

For odd v, write the forced formal cofactor as

 (1+x^v) / ((1-x^2)(1+a*x^2+x^v)).

After expanding in powers of x^v, coefficients in parity block K are finite
alternating-binomial sums.  This verifier proves every coefficient before the
selected obstruction is positive, apart from the already known zeros below v
on the odd ray and b_v=0.  It uses rational root intervals and explicit
first-omitted-term bounds, uniformly for every odd v>=23.
"""

from __future__ import annotations

from fractions import Fraction
import json
import math
from pathlib import Path
import sys

sys.set_int_max_str_digits(0)

ROOT = Path(__file__).resolve().parent
GLOBAL = ROOT / "forced_recurrence_global_exact.json"
OUTPUT = ROOT / "forced_block_positivity_exact.json"
TAIL_START_V = 23
SCAN_M_MAX = 40
ROOT_INTERVAL_DYADIC_BITS = 48

Interval = tuple[Fraction, Fraction]


def add(x: Interval, y: Interval) -> Interval:
    return x[0] + y[0], x[1] + y[1]


def neg(x: Interval) -> Interval:
    return -x[1], -x[0]


def sub(x: Interval, y: Interval) -> Interval:
    return add(x, neg(y))


def mul(x: Interval, y: Interval) -> Interval:
    products = (x[0] * y[0], x[0] * y[1], x[1] * y[0], x[1] * y[1])
    return min(products), max(products)


def positive_pow(x: Interval, exponent: int) -> Interval:
    assert 0 < x[0] <= x[1] and exponent >= 0
    return x[0] ** exponent, x[1] ** exponent


def reciprocal(x: Interval) -> Interval:
    assert 0 < x[0] <= x[1]
    return 1 / x[1], 1 / x[0]


def polynomial_interval(coefficients: list[int], x: Interval) -> Interval:
    value = (Fraction(coefficients[-1]), Fraction(coefficients[-1]))
    for coefficient in reversed(coefficients[:-1]):
        value = add(mul(value, x), (Fraction(coefficient), Fraction(coefficient)))
    return value


def partial(k: int, m: int, a: Interval) -> Interval:
    coefficients = [(-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1)]
    return polynomial_interval(coefficients, a)


def reciprocal_power(j: int, a: Interval) -> Interval:
    one_plus = add((Fraction(1), Fraction(1)), a)
    return reciprocal(positive_pow(one_plus, j + 1))


def outward_dyadic_interval(a: Interval, bits: int) -> Interval:
    denominator = 1 << bits
    lower_numerator = (a[0].numerator * denominator) // a[0].denominator
    upper_numerator = -((-a[1].numerator * denominator) // a[1].denominator)
    result = Fraction(lower_numerator, denominator), Fraction(upper_numerator, denominator)
    assert result[0] <= a[0] <= a[1] <= result[1]
    return result


def block_limit(k: int, m: int, a: Interval) -> Interval:
    """Limit as odd v tends to infinity for block K at internal offset m."""
    top = mul(a, partial(k, m, a))
    if k % 2:
        value = top
        for j in range(1, k, 2):
            value = add(value, mul(a, reciprocal_power(j, a)))
        return value
    value = reciprocal_power(0, a)
    value = sub(value, top)
    for j in range(2, k, 2):
        value = sub(value, mul(a, reciprocal_power(j, a)))
    return value


def full_block_limit(k: int, a: Interval) -> Interval:
    """Limit after also sending the internal offset m to infinity."""
    if k % 2:
        value = (Fraction(0), Fraction(0))
        for j in range(1, k + 1, 2):
            value = add(value, mul(a, reciprocal_power(j, a)))
        return value
    value = reciprocal_power(0, a)
    for j in range(2, k + 1, 2):
        value = sub(value, mul(a, reciprocal_power(j, a)))
    return value


def first_omitted_bound(j: int, m: int, upper_a: Fraction) -> Fraction | None:
    if upper_a * (j + m + 2) >= m + 2:
        return None
    return Fraction(math.comb(j + m + 1, m + 1)) * upper_a ** (m + 1)


def finite_v_error(k: int, m: int, v: int, upper_a: Fraction) -> Fraction | None:
    """Bound block(K,m,v) minus its v-infinity limit."""
    error = Fraction(0)
    if k % 2 == 0:
        base_index = (k // 2) * v + 1 + m
        error += upper_a ** (base_index + 1)
    for s in range(1, (k + 1) // 2):
        j = k - 2 * s
        index = m + s * v
        tail = first_omitted_bound(j, index, upper_a)
        if tail is None:
            return None
        error += upper_a * tail
    return error


def verify_positive_block(k: int, a: Interval) -> dict:
    upper_a = a[1]
    minimum_lower: Fraction | None = None
    minimum_m: int | None = None
    for m in range(SCAN_M_MAX + 1):
        limit = block_limit(k, m, a)
        error = finite_v_error(k, m, TAIL_START_V, upper_a)
        if error is None:
            return {"status": "failed", "reason": "tail_not_decreasing", "m": m}
        lower = limit[0] - error
        if lower <= 0:
            return {
                "status": "failed",
                "reason": "nonpositive_lower_bound",
                "m": m,
                "limit_lower": str(limit[0]),
                "finite_v_error": str(error),
            }
        if minimum_lower is None or lower < minimum_lower:
            minimum_lower, minimum_m = lower, m

    m = SCAN_M_MAX + 1
    limiting = full_block_limit(k, a)
    top_tail = first_omitted_bound(k, m, upper_a)
    finite_error = finite_v_error(k, m, TAIL_START_V, upper_a)
    if top_tail is None or finite_error is None:
        return {"status": "failed", "reason": "eventual_tail_not_decreasing"}
    # The top term is multiplied by a in either parity.
    eventual_lower = limiting[0] - upper_a * top_tail - finite_error
    if eventual_lower <= 0:
        return {
            "status": "failed",
            "reason": "eventual_nonpositive_lower_bound",
            "eventual_lower": str(eventual_lower),
        }
    return {
        "status": "positive",
        "checked_internal_offsets": [0, SCAN_M_MAX],
        "minimum_checked_lower_bound": str(minimum_lower),
        "minimum_checked_at_m": minimum_m,
        "eventual_internal_offsets_from": m,
        "eventual_lower_bound": str(eventual_lower),
    }


def verify_selected_prefix(k: int, offset: int, a: Interval) -> dict:
    obstruction_m = (offset - 2) // 2
    records = []
    for m in range(obstruction_m):
        limit = block_limit(k, m, a)
        error = finite_v_error(k, m, TAIL_START_V, a[1])
        assert error is not None
        lower = limit[0] - error
        if lower <= 0:
            return {"status": "failed", "m": m, "lower_bound": str(lower)}
        records.append({"m": m, "lower_bound": str(lower)})
    return {"status": "positive", "records": records}


def main() -> None:
    global_report = json.loads(GLOBAL.read_text(encoding="utf-8"))
    records = []
    for entry in global_report["records"]:
        candidate_id = int(entry["candidate_id"])
        exact_a = tuple(Fraction(value) for value in entry["final_target_root_interval"])
        a = outward_dyadic_interval(exact_a, ROOT_INTERVAL_DYADIC_BITS)
        selected = entry["uniform_odd_v_at_least_23"]
        obstruction_k = int(selected["k"])
        obstruction_offset = int(selected["offset"])
        blocks = {}
        for k in range(1, obstruction_k):
            result = verify_positive_block(k, a)
            assert result["status"] == "positive", (candidate_id, k, result)
            blocks[str(k)] = result
        prefix = verify_selected_prefix(obstruction_k, obstruction_offset, a)
        assert prefix["status"] == "positive", (candidate_id, obstruction_k, prefix)
        records.append(
            {
                "candidate_id": candidate_id,
                "obstruction": {"k": obstruction_k, "offset": obstruction_offset},
                "complete_positive_blocks_before_obstruction": blocks,
                "positive_prefix_in_obstruction_block": prefix,
            }
        )
        print(
            f"candidate {candidate_id}/126: blocks 1..{obstruction_k - 1} positive; "
            f"block {obstruction_k} positive before offset {obstruction_offset}",
            flush=True,
        )
    report = {
        "schema_version": 1,
        "proof_status": "exact_uniform_positivity_before_global_obstruction",
        "uniform_odd_v_at_least": TAIL_START_V,
        "candidate_count": len(records),
        "internal_offset_scan_max": SCAN_M_MAX,
        "outward_root_interval_dyadic_bits": ROOT_INTERVAL_DYADIC_BITS,
        "argument": (
            "Every pre-obstruction parity block is positive for all internal offsets. "
            "Offsets through the scan maximum use exact rational interval lower bounds; "
            "all later offsets use the full-block limit and first omitted alternating terms."
        ),
        "records": records,
    }
    OUTPUT.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(f"wrote {OUTPUT}")


if __name__ == "__main__":
    main()
