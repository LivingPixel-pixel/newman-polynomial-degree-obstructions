#!/usr/bin/env python3
"""Merge and validate the independently produced quartic audit shards."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def load(name: str) -> dict:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def digest(name: str) -> str:
    return hashlib.sha256((ROOT / name).read_bytes()).hexdigest()


def main() -> None:
    catalog_name = "independent_quartic_catalog_audit.json"
    finite_names = [f"independent_finite_arb_q{i}.json" for i in range(1, 5)]
    uniform_names = [f"independent_uniform_arb_q{i}.json" for i in range(1, 5)]
    catalog = load(catalog_name)
    finite = [load(name) for name in finite_names]
    uniform = [load(name) for name in uniform_names]

    finite_ranges = [(item["start_root"], item["end_root"]) for item in finite]
    uniform_ranges = [(item["start_root"], item["end_root"]) for item in uniform]
    expected_ranges = [(1, 1746), (1747, 3491), (3492, 5237), (5238, 6982)]
    catalog_input_hash = digest("quartic_norm_sieve_exact.json")
    finite_input_hash = digest("quartic_finite_recurrence_exact.json")
    tail_input_hash = digest("quartic_uniform_negative_exact.json")
    totals = {
        "target_roots": sum(item["root_count"] for item in finite),
        "finite_root_exponent_pairs": sum(item["pairs_checked"] for item in finite),
        "finite_coefficient_inequalities": sum(
            item["coefficients_checked"] for item in finite
        ),
        "uniform_target_roots": sum(item["root_count"] for item in uniform),
        "uniform_negative_tail_certificates": sum(
            item["tail_certificates_checked"] for item in uniform
        ),
        "uniform_positive_blocks": sum(
            item["positive_blocks_checked"] for item in uniform
        ),
        "uniform_inequalities": sum(
            item["certified_inequalities_checked"] for item in uniform
        ),
    }
    failures = (
        catalog["interval_failures"]
        + [failure for item in finite for failure in item["failures"]]
        + [failure for item in uniform for failure in item["failures"]]
    )
    status = "PASS"
    if (
        catalog["status"] != "PASS"
        or catalog["catalog_sha256"] != catalog_input_hash
        or not all(item["status"] == "PASS" for item in finite + uniform)
        or not all(item["environment"] == finite[0]["environment"] for item in finite)
        or not all(item["environment"] == uniform[0]["environment"] for item in uniform)
        or finite_ranges != expected_ranges
        or uniform_ranges != expected_ranges
        or any(item["finite_sha256"] != finite_input_hash for item in finite)
        or any(item["tail_sha256"] != tail_input_hash for item in uniform)
        or totals
        != {
            "target_roots": 6982,
            "finite_root_exponent_pairs": 62838,
            "finite_coefficient_inequalities": 12369079,
            "uniform_target_roots": 6982,
            "uniform_negative_tail_certificates": 6982,
            "uniform_positive_blocks": 99340,
            "uniform_inequalities": 4979348,
        }
        or failures
    ):
        status = "FAIL"

    names = [catalog_name, *finite_names, *uniform_names]
    report = {
        "schema_version": 1,
        "proof_status": "merged_independent_quartic_audit",
        "methods": catalog["methods"],
        "environment": {
            "catalog": catalog["environment"],
            "finite": finite[0]["environment"],
            "uniform": uniform[0]["environment"],
        },
        "catalog_counts": catalog["counts"],
        "proof_input_sha256": {
            "quartic_norm_sieve_exact.json": catalog_input_hash,
            "quartic_finite_recurrence_exact.json": finite_input_hash,
            "quartic_uniform_negative_exact.json": tail_input_hash,
        },
        "ranges": expected_ranges,
        "totals": totals,
        "failures": failures,
        "input_sha256": {name: digest(name) for name in names},
        "status": status,
    }
    output = ROOT / "independent_quartic_audit.json"
    output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(report, indent=2))
    if status != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
