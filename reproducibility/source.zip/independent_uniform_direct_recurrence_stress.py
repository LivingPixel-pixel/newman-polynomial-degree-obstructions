#!/usr/bin/env python3
"""Direct Arb replay of selected exponents covered by the uniform certificate.

This is a redundant finite stress test, not part of the infinite proof.  It
does not use the parity-block formulas: for each retained target root it
iterates the scalar forced recurrence through the certificate's obstruction
index and certifies every intervening sign with 4096-bit Arb balls.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import time

import flint
from flint import arb, ctx


sys.set_int_max_str_digits(0)
ctx.prec = 4096


def binary_tuple(value: Fraction) -> tuple[int, int]:
    denominator = value.denominator
    if denominator & (denominator - 1):
        raise ValueError(f"non-dyadic endpoint: {value}")
    return value.numerator, -(denominator.bit_length() - 1)


def root_ball(interval: list[str]) -> arb:
    left, right = map(Fraction, interval)
    if not left < right:
        raise ValueError(interval)
    midpoint = (left + right) / 2
    radius = (right - left) / 2
    return arb(binary_tuple(midpoint), binary_tuple(radius))


def replay(a: arb, v: int, obstruction: int):
    q = [arb(0) for _ in range(obstruction + 1)]
    q[0] = arb(1)
    checked = 0
    for n in range(1, obstruction + 1):
        if n < v and n % 2:
            continue
        forcing = arb(0)
        if n >= 2:
            forcing += a * q[n - 2]
        if n >= v:
            forcing += q[n - v]
        q[n] = 1 - forcing
        if n == v:
            if not q[n].is_zero():
                return False, checked, {"n": n, "reason": "q_v_not_zero"}
            continue
        checked += 1
        if n < obstruction:
            if not q[n] > 0:
                return False, checked, {
                    "n": n,
                    "reason": "positive_sign_not_certified",
                    "value": str(q[n]),
                }
            if not q[n] < 1:
                return False, checked, {
                    "n": n,
                    "reason": "upper_sign_not_certified",
                    "value": str(q[n]),
                }
            if not forcing > 0:
                return False, checked, {
                    "n": n,
                    "reason": "forcing_not_positive",
                    "value": str(forcing),
                }
        else:
            if not q[n] < 0:
                return False, checked, {
                    "n": n,
                    "reason": "obstruction_not_negative",
                    "value": str(q[n]),
                }
            if not forcing > 1:
                return False, checked, {
                    "n": n,
                    "reason": "forcing_not_above_one",
                    "value": str(forcing),
                }
    return True, checked, None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--v", type=int, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--tail",
        type=Path,
        default=Path("quartic_uniform_negative_exact.json"),
    )
    args = parser.parse_args()
    exponents = sorted(set(args.v))
    if any(v < 23 or not v % 2 for v in exponents):
        raise ValueError(exponents)
    tail_bytes = args.tail.read_bytes()
    records = json.loads(tail_bytes)["records"]
    if not 1 <= args.start <= args.end <= len(records):
        raise ValueError((args.start, args.end, len(records)))

    started = time.time()
    failures = []
    cases = 0
    coefficients = 0
    maximum_obstruction = 0
    for one_based in range(args.start, args.end + 1):
        record = records[one_based - 1]
        certificate = record["certificate"]
        a = root_ball(certificate["root_interval"])
        k = int(certificate["k"])
        offset = int(certificate["offset"])
        for v in exponents:
            obstruction = k * v + offset
            maximum_obstruction = max(maximum_obstruction, obstruction)
            ok, count, failure = replay(a, v, obstruction)
            cases += 1
            coefficients += count
            if not ok:
                failures.append(
                    {
                        "root_number": one_based,
                        "candidate_id": record["candidate_id"],
                        "root_index": record["root_index"],
                        "v": v,
                        "obstruction": obstruction,
                        **failure,
                    }
                )
        if one_based % 25 == 0 or one_based == args.end:
            print(
                f"{one_based}/{args.end}; cases={cases}; "
                f"coefficients={coefficients}; failures={len(failures)}; "
                f"elapsed={time.time()-started:.1f}s",
                flush=True,
            )

    report = {
        "schema_version": 1,
        "proof_status": "independent_finite_direct_uniform_recurrence_stress",
        "logical_scope": "finite redundant stress only; not an infinite proof",
        "tail_sha256": hashlib.sha256(tail_bytes).hexdigest(),
        "environment": {
            "python": sys.version.split()[0],
            "python_flint": flint.__version__,
            "arb_precision_bits": ctx.prec,
        },
        "start_root": args.start,
        "end_root": args.end,
        "root_count": args.end - args.start + 1,
        "exponents": exponents,
        "cases_checked": cases,
        "coefficients_checked": coefficients,
        "maximum_obstruction_index": maximum_obstruction,
        "failures": failures,
        "status": "PASS" if not failures else "FAIL",
        "elapsed_seconds": time.time() - started,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(report, indent=2), flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
