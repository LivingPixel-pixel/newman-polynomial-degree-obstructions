#!/usr/bin/env python3
"""Certified Arb-ball replay of every finite quartic recurrence sign.

The retained finite verifier works exactly in Z[a]/(m_a) and separates signs
with rational polynomial intervals. This independent replay instead encloses
the already independently certified target root in an Arb ball and propagates
the scalar recurrence directly with 4096-bit ball arithmetic.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import time

import flint
from flint import arb, ctx

sys.set_int_max_str_digits(0)
ctx.prec = 4096

def binary_tuple(value: Fraction) -> tuple[int, int]:
    denominator = value.denominator
    if denominator & (denominator - 1):
        raise ValueError(f"non-dyadic endpoint: {value}")
    exponent = -(denominator.bit_length() - 1)
    return value.numerator, exponent


def root_ball(interval: list[str]) -> arb:
    left, right = map(Fraction, interval)
    if not left < right:
        raise ValueError(interval)
    midpoint = (left + right) / 2
    radius = (right - left) / 2
    return arb(binary_tuple(midpoint), binary_tuple(radius))


def check_pair(a: arb, v: int, first_negative: int):
    q = [arb(0) for _ in range(first_negative + 1)]
    q[0] = arb(1)
    checked = 0
    for n in range(1, first_negative + 1):
        if n < v and n % 2:
            continue
        forcing = arb(0)
        if n >= 2:
            forcing += a * q[n - 2]
        if n >= v:
            forcing += q[n - v]
        target = arb(1)
        q[n] = target - forcing
        if n == v:
            if not q[n].is_zero():
                return False, checked, {"n": n, "reason": "q_v_not_exact_zero"}
            continue
        checked += 1
        if n < first_negative:
            if not q[n] > 0:
                return False, checked, {
                    "n": n,
                    "reason": "positive_sign_not_certified",
                    "value": str(q[n]),
                }
            if not q[n] < 1:
                return False, checked, {
                    "n": n,
                    "reason": "strict_upper_bound_not_certified",
                    "value": str(q[n]),
                }
            if not forcing > 0:
                return False, checked, {
                    "n": n,
                    "reason": "forcing_not_positive",
                    "value": str(forcing),
                }
        else:
            if not q[n] < 0:
                return False, checked, {
                    "n": n,
                    "reason": "negative_sign_not_certified",
                    "value": str(q[n]),
                }
            if not forcing > 1:
                return False, checked, {
                    "n": n,
                    "reason": "forcing_not_above_one",
                    "value": str(forcing),
                }
    return True, checked, None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--finite",
        type=Path,
        default=Path("quartic_finite_recurrence_exact.json"),
    )
    args = parser.parse_args()
    finite_bytes = args.finite.read_bytes()
    retained = json.loads(finite_bytes)
    records = retained["records"]
    if not 1 <= args.start <= args.end <= len(records):
        raise ValueError((args.start, args.end, len(records)))
    started = time.time()
    failures = []
    pairs_checked = 0
    coefficients_checked = 0
    for one_based in range(args.start, args.end + 1):
        record = records[one_based - 1]
        a = root_ball(record["final_root_interval"])
        for v_text, result in record["finite"].items():
            v = int(v_text)
            if result["status"] != "negative" or result["zeros"] != [v]:
                failures.append(
                    {
                        "root_number": one_based,
                        "v": v,
                        "reason": "retained_record_shape",
                    }
                )
                continue
            ok, count, failure = check_pair(a, v, int(result["n"]))
            pairs_checked += 1
            coefficients_checked += count
            if not ok:
                failures.append(
                    {
                        "root_number": one_based,
                        "candidate_id": record["candidate_id"],
                        "root_index": record["root_index"],
                        "v": v,
                        **failure,
                    }
                )
        if one_based % 25 == 0 or one_based == args.end:
            print(
                f"{one_based}/{args.end}; pairs={pairs_checked}; "
                f"coefficients={coefficients_checked}; failures={len(failures)}; "
                f"elapsed={time.time()-started:.1f}s",
                flush=True,
            )
    report = {
        "schema_version": 1,
        "proof_status": "independent_4096_bit_arb_finite_recurrence_audit",
        "finite_sha256": hashlib.sha256(finite_bytes).hexdigest(),
        "environment": {
            "python": sys.version.split()[0],
            "python_flint": flint.__version__,
            "arb_precision_bits": ctx.prec,
        },
        "start_root": args.start,
        "end_root": args.end,
        "root_count": args.end - args.start + 1,
        "pairs_checked": pairs_checked,
        "coefficients_checked": coefficients_checked,
        "failures": failures,
        "status": "PASS" if not failures else "FAIL",
        "elapsed_seconds": time.time() - started,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(report, indent=2), flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
