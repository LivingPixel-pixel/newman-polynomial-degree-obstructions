#!/usr/bin/env python3
"""Exact coefficient audit for the parity-rationalization lemma."""

from __future__ import annotations

import sympy as sp


t = sp.symbols("t")
ZERO = sp.Poly(0, t, domain=sp.ZZ)
ONE = sp.Poly(1, t, domain=sp.ZZ)
T = sp.Poly(t, t, domain=sp.ZZ)
T2 = sp.Poly(t**2, t, domain=sp.ZZ)


def forced_coefficients(v: int, limit: int) -> list[sp.Poly]:
    q = [ZERO for _ in range(limit + 1)]
    q[0] = ONE
    for n in range(1, limit + 1):
        value = ONE if n % 2 == 0 or n >= v else ZERO
        if n >= 2:
            value -= T * q[n - 2]
        if n >= v:
            value -= q[n - v]
        q[n] = value
    return q


def reciprocal_coefficients(v: int, limit: int) -> list[sp.Poly]:
    r = [ZERO for _ in range(limit + 1)]
    for m in range(limit + 1):
        value = ONE
        if m >= 1:
            value -= 2 * T * r[m - 1]
        if m >= 2:
            value -= T2 * r[m - 2]
        if m >= v:
            value += r[m - v]
        r[m] = value
    return r


def at(sequence: list[sp.Poly], index: int) -> sp.Poly:
    return ZERO if index < 0 else sequence[index]


def main() -> None:
    comparisons = 0
    for v in range(5, 32, 2):
        m_limit = 200
        q = forced_coefficients(v, v + 2 * m_limit)
        r = reciprocal_coefficients(v, m_limit)
        for m in range(m_limit + 1):
            if 2 * m < len(q):
                assert q[2 * m] == at(r, m) + T * at(r, m - 1) - at(r, m - v)
                comparisons += 1
            assert q[v + 2 * m] == T * at(r, m - 1)
            comparisons += 1
    print(
        f"PASS: {comparisons} exact polynomial coefficient identities for "
        "odd 5<=v<=31 and 0<=m<=200"
    )


if __name__ == "__main__":
    main()
