#!/usr/bin/env python3
"""Independent rational-specialization audit of the parity-block identity.

This checker does not use the cubic catalog or arithmetic modulo a minimal
polynomial.  It compares direct formal division with the block expansion over
ordinary exact rational numbers at several rational specializations of a.
The symbolic derivation in the manuscript is the proof; this is a separate
implementation audit intended to expose shared algebraic-number-code errors.
"""

from __future__ import annotations

from fractions import Fraction
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "block_identity_rational_audit.json"
VALUES = (Fraction(1, 7), Fraction(2, 9), Fraction(49, 100))
EXPONENTS = (5, 23, 99)
LIMIT = 1000


def direct_coefficients(a: Fraction, v: int, limit: int) -> list[Fraction]:
    q = [Fraction(0)] * (limit + 1)
    for n in range(limit + 1):
        product_bit = int(n % 2 == 0 or n >= v)
        q[n] = Fraction(product_bit)
        if n >= 2:
            q[n] -= a * q[n - 2]
        if n >= v:
            q[n] -= q[n - v]
    return q


def partial_table(a: Fraction, max_k: int, max_m: int) -> list[list[Fraction]]:
    powers = [Fraction(1)]
    for _ in range(max_m):
        powers.append(powers[-1] * a)
    table: list[list[Fraction]] = []
    for k in range(max_k + 1):
        value = Fraction(0)
        row = []
        for m in range(max_m + 1):
            value += (-1) ** m * math.comb(k + m, m) * powers[m]
            row.append(value)
        table.append(row)
    return table


def expanded_coefficient(n: int, v: int, a: Fraction, partial) -> Fraction:
    value = partial[0][n // 2] if n % 2 == 0 else Fraction(0)
    for k in range(1, (n - 2) // v + 1):
        remainder = n - k * v - 2
        if remainder < 0 or remainder % 2:
            continue
        term = a * partial[k][remainder // 2]
        value += term if k % 2 else -term
    return value


def main() -> None:
    records = []
    for a in VALUES:
        for v in EXPONENTS:
            direct = direct_coefficients(a, v, LIMIT)
            partial = partial_table(a, LIMIT // v, LIMIT // 2)
            for n, expected in enumerate(direct):
                actual = expanded_coefficient(n, v, a, partial)
                assert actual == expected, (a, v, n, actual, expected)
            records.append(
                {
                    "a": str(a),
                    "v": v,
                    "coefficient_count": LIMIT + 1,
                }
            )
    report = {
        "schema_version": 1,
        "proof_role": "independent_exact_rational_specialization_audit",
        "case_count": len(records),
        "coefficient_identity_count": len(records) * (LIMIT + 1),
        "records": records,
    }
    OUTPUT.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(
        f"verified {report['coefficient_identity_count']} exact rational identities; "
        f"wrote {OUTPUT}",
        flush=True,
    )


if __name__ == "__main__":
    main()
