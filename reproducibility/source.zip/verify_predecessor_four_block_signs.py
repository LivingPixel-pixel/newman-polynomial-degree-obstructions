#!/usr/bin/env python3
"""Independent exact sign audit for the four-block safe-lattice proof.

Each analytic sign claim is reduced to exact rational endpoint signs and a
Sturm root count.  The three finite exceptional (v, s) pairs are independently
checked by primitive polynomial reduction and gcd computation over GF(7).
Output bytes are UTF-8 with canonical LF newlines on every platform.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import sympy as sp


T = sp.Symbol("t")
HALF = sp.Rational(1, 2)


INTERVALS = {
    1: (sp.Rational(277, 1000), sp.Rational(279, 1000)),
    3: (sp.Rational(288, 1000), sp.Rational(290, 1000)),
    5: (sp.Rational(323, 1000), sp.Rational(325, 1000)),
    7: (sp.Rational(359, 1000), sp.Rational(360, 1000)),
    9: (sp.Rational(391, 1000), sp.Rational(392, 1000)),
    11: (sp.Rational(420, 1000), sp.Rational(421, 1000)),
    13: (sp.Rational(446, 1000), sp.Rational(447, 1000)),
    15: (sp.Rational(469, 1000), sp.Rational(471, 1000)),
    17: (sp.Rational(490, 1000), sp.Rational(492, 1000)),
}


def partial(k: int, m: int) -> sp.Expr:
    return sp.expand(
        sum((-1) ** ell * sp.binomial(k + ell, ell) * T**ell for ell in range(m + 1))
    )


def minimum_v(offset: int) -> int:
    if offset == 1:
        return 7
    return max(5, offset + 2)


def numerator(expr: sp.Expr) -> sp.Poly:
    num, den = sp.cancel(expr).as_numer_denom()
    den_poly = sp.Poly(den, T, domain=sp.QQ)
    assert den_poly.count_roots(0, HALF) == 0
    return sp.Poly(num, T, domain=sp.QQ)


def certify_sign(
    name: str,
    expr: sp.Expr,
    left: sp.Rational,
    right: sp.Rational,
    expected_sign: int,
) -> dict[str, object]:
    assert left < right
    poly = numerator(expr)
    root_count = int(poly.count_roots(left, right))
    left_value = sp.factor(expr.subs(T, left))
    right_value = sp.factor(expr.subs(T, right))
    assert root_count == 0
    assert sp.sign(left_value) == expected_sign
    assert sp.sign(right_value) == expected_sign
    return {
        "name": name,
        "interval": [str(left), str(right)],
        "expected_sign": expected_sign,
        "numerator_degree": int(poly.degree()),
        "sturm_root_count": root_count,
        "left_value": str(left_value),
        "right_value": str(right_value),
    }


def build_sign_certificates() -> list[dict[str, object]]:
    certificates: list[dict[str, object]] = []

    # Every even offset except s=0 is analytic.  The eight small offsets use
    # their least admissible v, while s>=18 follows from P_(5,37)>0.
    for offset in range(2, 18, 2):
        v0 = max(5, offset + 1)
        lower = (
            partial(1, 3 * v0 + offset)
            + (1 + T) ** -4
            + partial(5, v0 + offset)
            + partial(7, offset)
        )
        certificates.append(
            certify_sign(f"even_offset_{offset}_lower", lower, 0, HALF, 1)
        )

    offset_zero_v9 = partial(1, 27) + (1 + T) ** -4 + partial(5, 9) + 1
    certificates.append(
        certify_sign("even_offset_zero_v_at_least_9", offset_zero_v9, 0, HALF, 1)
    )
    certificates.append(certify_sign("p5_37_positive", partial(5, 37), 0, HALF, 1))

    late_odd = (
        (1 + T) ** -2 + partial(3, 61) + (1 + T) ** -6 + partial(7, 19)
    )
    certificates.append(
        certify_sign("odd_offsets_at_least_19_lower", late_odd, 0, HALF, 1)
    )

    # All remaining uniform roots are confined to nine short rational
    # intervals by lower and upper envelopes.
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = (
            (1 + T) ** -2
            + partial(3, 2 * v0 + offset)
            + (1 + T) ** -6
            + partial(7, offset)
        )
        upper = (
            partial(1, 3 * v0 + offset)
            + (1 + T) ** -4
            + partial(5, v0 + offset)
            + partial(7, offset)
        )
        certificates.append(
            certify_sign(f"offset_{offset}_lower_before_alpha", lower, 0, alpha, 1)
        )
        certificates.append(
            certify_sign(f"offset_{offset}_upper_after_beta", upper, beta, HALF, -1)
        )

    # At s=1 the even-event companion is bounded below by a positive
    # function.  At the other eight offsets it is bounded above by a negative
    # function.  The odd-event companion margins are rational inequalities in
    # the dependency-free audit and need no Sturm step.
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        if offset == 1:
            tail = beta ** (4 * v0 + offset + 1)
            companion = (
                (1 - tail) / (1 + T)
                - T
                * (
                    (1 + T) ** -3
                    + partial(4, 2 * v0 + offset - 1)
                    + (1 + T) ** -7
                    + partial(8, offset - 1)
                )
            )
            certificates.append(
                certify_sign("offset_1_even_companion_lower", companion, alpha, beta, 1)
            )
        else:
            companion = (
                (1 + T) ** -1
                - T
                * (
                    partial(2, 3 * v0 + offset - 1)
                    + (1 + T) ** -5
                    + partial(6, v0 + offset - 1)
                    + partial(8, offset - 1)
                )
            )
            certificates.append(
                certify_sign(
                    f"offset_{offset}_even_companion_upper",
                    companion,
                    alpha,
                    beta,
                    -1,
                )
            )
    return certificates


ZERO = sp.Poly(0, T, domain=sp.ZZ)
ONE = sp.Poly(1, T, domain=sp.ZZ)


def sequences(v: int, limit: int) -> tuple[list[sp.Poly], list[sp.Poly]]:
    r = [ZERO for _ in range(limit + 1)]
    even = [ZERO for _ in range(limit + 1)]
    for m in range(limit + 1):
        value = ONE
        if m >= 1:
            value -= sp.Poly(2 * T, T, domain=sp.ZZ) * r[m - 1]
        if m >= 2:
            value -= sp.Poly(T**2, T, domain=sp.ZZ) * r[m - 2]
        if m >= v:
            value += r[m - v]
        r[m] = value

        evalue = ONE
        if m >= 1:
            evalue -= sp.Poly(T, T, domain=sp.ZZ) * r[m - 1]
        if m >= 2:
            evalue -= sp.Poly(T**2, T, domain=sp.ZZ) * r[m - 2]
        even[m] = evalue
    return r, even


def finite_exception_gcd_certificates() -> list[dict[str, object]]:
    certificates = []
    prime = 7
    for v, offset in ((5, 0), (7, 0), (5, 1)):
        r, even = sequences(v, 5 * v + 2)
        j = 3 * v + offset
        for companion_name, companion in (("odd", even[j + 2]), ("even", even[j + v])):
            left = r[j]
            assert left.content() == 1 and companion.content() == 1
            left_mod = sp.Poly(left.as_expr(), T, modulus=prime)
            right_mod = sp.Poly(companion.as_expr(), T, modulus=prime)
            assert left_mod.degree() == left.degree()
            assert right_mod.degree() == companion.degree()
            gcd_poly = sp.gcd(left_mod, right_mod).monic()
            assert gcd_poly.degree() == 0 and gcd_poly.as_expr() == 1
            certificates.append(
                {
                    "v": v,
                    "offset": offset,
                    "j": j,
                    "companion": companion_name,
                    "prime": prime,
                    "left_primitive": True,
                    "right_primitive": True,
                    "left_degree": int(left.degree()),
                    "right_degree": int(companion.degree()),
                    "degrees_preserved_mod_p": True,
                    "gcd_degree_mod_p": int(gcd_poly.degree()),
                    "gcd_monic_mod_p": str(gcd_poly.as_expr()),
                }
            )
    return certificates


def build_report() -> dict[str, object]:
    signs = build_sign_certificates()
    gcds = finite_exception_gcd_certificates()
    assert len(signs) == 38
    assert len(gcds) == 6
    return {
        "schema_version": 1,
        "line_ending_and_hash_convention": "UTF-8 bytes with canonical LF newlines",
        "proof_status": "independent_exact_audit_supporting_uniform_four_block_manuscript_proof",
        "theorem": {
            "odd_first_escape_index_at_least": "9*v+4",
            "even_first_escape_index_at_least": "10*v+2",
            "scope": "odd v>=5 and 0<t<1/2",
        },
        "sign_certificate_count": len(signs),
        "all_sign_root_counts_zero": all(item["sturm_root_count"] == 0 for item in signs),
        "finite_exception_modular_gcd_certificate_count": len(gcds),
        "sign_certificates": signs,
        "finite_exception_modular_gcd_certificates": gcds,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path("predecessor_four_block_signs_exact.json")
    )
    args = parser.parse_args()
    report = build_report()
    payload = (json.dumps(report, indent=2) + "\n").encode("utf-8")
    args.output.write_bytes(payload)
    print(
        "PASS: four-block audit with "
        f"{report['sign_certificate_count']} exact sign certificates and "
        f"{report['finite_exception_modular_gcd_certificate_count']} mod-7 gcd certificates"
    )
    print(f"wrote canonical LF bytes to {args.output}")


if __name__ == "__main__":
    main()
