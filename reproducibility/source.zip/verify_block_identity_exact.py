#!/usr/bin/env python3
"""Independent exact audit of the parity-block coefficient identities.

For every cubic catalog entry at v=23, compute the formal quotient two ways:
(i) direct coefficient division of (1+x^v)/(1-x^2) by
1+a*x^2+x^v in Z[a]/(m_a), and (ii) the finite block expansion used by the
uniform proof.  Compare every coefficient through the selected obstruction.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GLOBAL = ROOT / "forced_recurrence_global_exact.json"
DEFAULT_OUTPUT = ROOT / "block_identity_exact_audit.json"

Element = tuple[int, int, int]
ZERO: Element = (0, 0, 0)
ONE: Element = (1, 0, 0)


def add(x: Element, y: Element) -> Element:
    return x[0] + y[0], x[1] + y[1], x[2] + y[2]


def neg(x: Element) -> Element:
    return -x[0], -x[1], -x[2]


def scale(c: int, x: Element) -> Element:
    return c * x[0], c * x[1], c * x[2]


def times_a(x: Element, polynomial: tuple[int, int, int]) -> Element:
    s2, s1, s0 = polynomial
    c0, c1, c2 = x
    return -s0 * c2, c0 - s1 * c2, c1 - s2 * c2


def direct_coefficients(polynomial: tuple[int, int, int], v: int, limit: int) -> list[Element]:
    q = [ZERO] * (limit + 1)
    for n in range(limit + 1):
        product_bit = 1 if n % 2 == 0 or n >= v else 0
        value = (product_bit, 0, 0)
        if n >= 2:
            value = add(value, neg(times_a(q[n - 2], polynomial)))
        if n >= v:
            value = add(value, neg(q[n - v]))
        q[n] = value
    return q


def partials(polynomial: tuple[int, int, int], max_k: int, max_m: int):
    powers = [ONE]
    for _ in range(max_m):
        powers.append(times_a(powers[-1], polynomial))
    result = {}
    for k in range(max_k + 1):
        value = ZERO
        row = []
        for m in range(max_m + 1):
            value = add(value, scale((-1) ** m * math.comb(k + m, m), powers[m]))
            row.append(value)
        result[k] = row
    return result


def block_coefficient(
    n: int,
    v: int,
    partial,
    polynomial: tuple[int, int, int],
) -> Element:
    value = partial[0][n // 2] if n % 2 == 0 else ZERO
    for k in range(1, (n - 2) // v + 1):
        remainder = n - k * v - 2
        if remainder < 0 or remainder % 2:
            continue
        term = times_a(partial[k][remainder // 2], polynomial)
        value = add(value, term if k % 2 else neg(term))
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v", type=int, default=23)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    assert args.v >= 5 and args.v % 2
    report = json.loads(GLOBAL.read_text(encoding="utf-8"))
    records = []
    v = args.v
    for entry in report["records"]:
        candidate_id = int(entry["candidate_id"])
        polynomial = tuple(entry["minimal_polynomial_coefficients"])
        selected = entry["uniform_odd_v_at_least_23"]
        limit = int(selected["k"]) * v + int(selected["offset"])
        direct = direct_coefficients(polynomial, v, limit)
        partial = partials(polynomial, int(selected["k"]), limit // 2)
        checked = 0
        for n in range(limit + 1):
            expanded = block_coefficient(n, v, partial, polynomial)
            assert expanded == direct[n], (candidate_id, n, expanded, direct[n])
            checked += 1
        records.append({"candidate_id": candidate_id, "coefficient_count": checked, "limit": limit})
        print(f"candidate {candidate_id}/126: {checked} exact identities", flush=True)
    output = {
        "schema_version": 1,
        "proof_role": "independent_exact_block_identity_audit",
        "v": v,
        "candidate_count": len(records),
        "coefficient_identity_count": sum(record["coefficient_count"] for record in records),
        "records": records,
    }
    args.output.write_bytes((json.dumps(output, indent=2) + "\n").encode("utf-8"))
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
