#!/usr/bin/env python3
"""Exact finite-v forced-recurrence verification for quartic roots."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction
import json
from pathlib import Path
import sys

sys.set_int_max_str_digits(0)

Element = tuple[int, int, int, int]
Interval = tuple[Fraction, Fraction]
FINITE_V = tuple(range(5, 22, 2))


def iadd(x: Interval, y: Interval) -> Interval:
    return x[0] + y[0], x[1] + y[1]


def imul(x: Interval, y: Interval) -> Interval:
    p = (x[0] * y[0], x[0] * y[1], x[1] * y[0], x[1] * y[1])
    return min(p), max(p)


def polynomial_interval(coefficients: Element, x: Interval) -> Interval:
    value = (Fraction(coefficients[-1]), Fraction(coefficients[-1]))
    for coefficient in reversed(coefficients[:-1]):
        value = iadd(imul(value, x), (Fraction(coefficient), Fraction(coefficient)))
    return value


def quartic_value(polynomial: Element, x: Fraction) -> Fraction:
    s3, s2, s1, s0 = polynomial
    return (((x + s3) * x + s2) * x + s1) * x + s0


@dataclass
class Root:
    polynomial: Element
    interval: Interval

    def refine(self) -> None:
        left, right = self.interval
        middle = (left + right) / 2
        fl = quartic_value(self.polynomial, left)
        fm = quartic_value(self.polynomial, middle)
        fr = quartic_value(self.polynomial, right)
        assert fl and fr and fl * fr < 0
        if fl * fm < 0:
            self.interval = left, middle
        elif fm * fr < 0:
            self.interval = middle, right
        else:
            raise AssertionError("rational target root contradicts irreducibility")

    def sign(self, element: Element) -> int:
        if element == (0, 0, 0, 0):
            return 0
        for _ in range(10000):
            value = polynomial_interval(element, self.interval)
            if value[0] > 0:
                return 1
            if value[1] < 0:
                return -1
            self.refine()
        raise RuntimeError("failed to separate algebraic sign")


def add(x: Element, y: Element) -> Element:
    return x[0] + y[0], x[1] + y[1], x[2] + y[2], x[3] + y[3]


def neg(x: Element) -> Element:
    return -x[0], -x[1], -x[2], -x[3]


def multiply_by_a(x: Element, polynomial: Element) -> Element:
    s3, s2, s1, s0 = polynomial
    c0, c1, c2, c3 = x
    return -s0 * c3, c0 - s1 * c3, c1 - s2 * c3, c2 - s3 * c3


def first_negative(root: Root, v: int, limit: int) -> dict:
    zero: Element = (0, 0, 0, 0)
    one: Element = (1, 0, 0, 0)
    b: list[Element] = [zero] * (limit + 1)
    b[0] = one
    zero_indices: list[int] = []
    for n in range(1, limit + 1):
        if n < v and n % 2:
            continue
        forcing = zero
        if n >= 2:
            forcing = add(forcing, multiply_by_a(b[n - 2], root.polynomial))
        if n >= v:
            forcing = add(forcing, b[n - v])
        forcing_sign = root.sign(forcing)
        if forcing_sign <= 0:
            return {"status": "failed", "reason": "nonpositive_forcing", "n": n}
        b[n] = add(one, neg(forcing))
        coefficient_sign = root.sign(b[n])
        if coefficient_sign < 0:
            return {"status": "negative", "n": n, "zeros": zero_indices}
        if coefficient_sign == 0:
            zero_indices.append(n)
    return {"status": "failed", "reason": "limit_reached", "limit": limit}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", type=Path, required=True)
    parser.add_argument("--tail", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--limit-blocks", type=int, default=130)
    args = parser.parse_args()
    catalog = json.loads(args.catalog.read_text(encoding="utf-8"))
    tail = json.loads(args.tail.read_text(encoding="utf-8"))
    roots = {(r["candidate_id"], r["root_index"]): r for r in tail["records"]}
    records = []
    failures = []
    root_number = 0
    total = sum(item["target_root_count"] for item in catalog["candidate_catalog"])
    maxima = {str(v): 0 for v in FINITE_V}
    for item in catalog["candidate_catalog"]:
        polynomial = tuple(item["minimal_polynomial_coefficients"])
        for root_index, _ in enumerate(item["target_root_intervals"], 1):
            root_number += 1
            source = roots[(item["candidate_id"], root_index)]
            interval = source["certificate"]["root_interval"]
            root = Root(polynomial, (Fraction(interval[0]), Fraction(interval[1])))
            finite = {}
            for v in FINITE_V:
                result = first_negative(root, v, args.limit_blocks * v + 8)
                finite[str(v)] = result
                if result["status"] != "negative" or result["zeros"] != [v]:
                    failures.append({"candidate_id": item["candidate_id"], "root_index": root_index, "v": v, "result": result})
                else:
                    maxima[str(v)] = max(maxima[str(v)], result["n"])
            records.append({"candidate_id": item["candidate_id"], "root_index": root_index, "polynomial": list(polynomial), "final_root_interval": [str(root.interval[0]), str(root.interval[1])], "finite": finite})
            if root_number % 50 == 0 or root_number == total:
                print(f"{root_number}/{total}; failures={len(failures)}", flush=True)
    report = {"schema_version": 1, "proof_status": "exact_complete_quartic_finite_v", "root_count": total, "finite_v": list(FINITE_V), "limit_blocks": args.limit_blocks, "failures": failures, "max_first_negative_index_by_v": maxima, "records": records}
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps({"failures": len(failures), "maxima": maxima}, indent=2))


if __name__ == "__main__":
    main()
