#!/usr/bin/env python3
"""Independent Arb audit of every quartic uniform tail and prefix inequality.

The retained verifier uses exact fmpq interval arithmetic. This replay uses
4096-bit Arb balls, exact dyadic enclosures, and independently coded block and
alternating-tail formulas. Every comparison is a certified ball comparison.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import flint
from flint import arb, ctx

sys.set_int_max_str_digits(0)
ctx.prec = 4096

TAIL_START_V = 23
SCAN_M_MAX = 48


def binary_tuple(value: Fraction) -> tuple[int, int]:
    denominator = value.denominator
    if denominator & (denominator - 1):
        raise ValueError(f"non-dyadic endpoint: {value}")
    return value.numerator, -(denominator.bit_length() - 1)


def exact_arb(value: Fraction | int) -> arb:
    if isinstance(value, int):
        return arb(value)
    return arb(binary_tuple(value))


def root_ball(interval: list[str]) -> tuple[arb, arb]:
    left, right = map(Fraction, interval)
    midpoint = (left + right) / 2
    radius = (right - left) / 2
    return arb(binary_tuple(midpoint), binary_tuple(radius)), exact_arb(right)


def partial(k: int, m: int, a: arb) -> arb:
    value = arb(0)
    for ell in range(m, -1, -1):
        value = value * a + ((-1) ** ell) * math.comb(k + ell, ell)
    return value


def reciprocal_power(j: int, a: arb) -> arb:
    return 1 / (1 + a) ** (j + 1)


def block_limit(k: int, m: int, a: arb) -> arb:
    top = a * partial(k, m, a)
    if k % 2:
        return top + sum(
            (a * reciprocal_power(j, a) for j in range(1, k, 2)),
            arb(0),
        )
    return (
        reciprocal_power(0, a)
        - top
        - sum(
            (a * reciprocal_power(j, a) for j in range(2, k, 2)),
            arb(0),
        )
    )


def full_block_limit(k: int, a: arb) -> arb:
    if k % 2:
        return sum(
            (a * reciprocal_power(j, a) for j in range(1, k + 1, 2)),
            arb(0),
        )
    return reciprocal_power(0, a) - sum(
        (a * reciprocal_power(j, a) for j in range(2, k + 1, 2)),
        arb(0),
    )


def first_omitted(j: int, m: int, upper: arb):
    if not upper * (j + m + 2) < m + 2:
        return None
    return math.comb(j + m + 1, m + 1) * upper ** (m + 1)


def finite_error(k: int, m: int, upper: arb):
    error = arb(0)
    if k % 2 == 0:
        base = (k // 2) * TAIL_START_V + 1 + m
        error += upper ** (base + 1)
    for s in range(1, (k + 1) // 2):
        j = k - 2 * s
        index = m + s * TAIL_START_V
        tail = first_omitted(j, index, upper)
        if tail is None:
            return None
        error += upper * tail
    return error


def tail_error(k: int, offset: int, upper: arb):
    error = arb(0)
    if k % 2 == 0:
        base_m = (k * TAIL_START_V + offset) // 2
        error += upper ** (base_m + 1)
        lower = range(2, k, 2)
    else:
        lower = range(1, k, 2)
    for j in lower:
        m = ((k - j) * TAIL_START_V + offset - 2) // 2
        if not upper * (j + m + 2) < m + 2:
            return None
        error += (
            upper
            * math.comb(j + m + 1, m + 1)
            * upper ** (m + 1)
        )
    return error


def verify_positive_block(k: int, a: arb, upper: arb):
    inequalities = 0
    for m in range(SCAN_M_MAX + 1):
        error = finite_error(k, m, upper)
        if error is None or not block_limit(k, m, a) - error > 0:
            return False, inequalities, f"finite:m={m}"
        inequalities += 1
    m = SCAN_M_MAX + 1
    top_tail = first_omitted(k, m, upper)
    error = finite_error(k, m, upper)
    if (
        top_tail is None
        or error is None
        or not full_block_limit(k, a) - upper * top_tail - error > 0
    ):
        return False, inequalities, "eventual"
    return True, inequalities + 1, None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--tail",
        type=Path,
        default=Path("quartic_uniform_negative_exact.json"),
    )
    args = parser.parse_args()
    tail_bytes = args.tail.read_bytes()
    records = json.loads(tail_bytes)["records"]
    if not 1 <= args.start <= args.end <= len(records):
        raise ValueError((args.start, args.end, len(records)))
    started = time.time()
    failures = []
    blocks_checked = 0
    inequalities_checked = 0
    tail_certificates = 0
    for one_based in range(args.start, args.end + 1):
        record = records[one_based - 1]
        certificate = record["certificate"]
        k = int(certificate["k"])
        offset = int(certificate["offset"])
        a, upper = root_ball(certificate["root_interval"])
        error = tail_error(k, offset, upper)
        if (
            error is None
            or not block_limit(k, (offset - 2) // 2, a) + error < 0
        ):
            failures.append(
                {
                    "root_number": one_based,
                    "candidate_id": record["candidate_id"],
                    "root_index": record["root_index"],
                    "stage": "negative_tail",
                }
            )
            continue
        tail_certificates += 1
        failed = False
        for prior_k in range(1, k):
            ok, inequalities, reason = verify_positive_block(prior_k, a, upper)
            blocks_checked += 1
            inequalities_checked += inequalities
            if not ok:
                failures.append(
                    {
                        "root_number": one_based,
                        "candidate_id": record["candidate_id"],
                        "root_index": record["root_index"],
                        "stage": "positive_block",
                        "k": prior_k,
                        "reason": reason,
                    }
                )
                failed = True
                break
        if failed:
            continue
        for m in range((offset - 2) // 2):
            prefix_error = finite_error(k, m, upper)
            if (
                prefix_error is None
                or not block_limit(k, m, a) - prefix_error > 0
            ):
                failures.append(
                    {
                        "root_number": one_based,
                        "candidate_id": record["candidate_id"],
                        "root_index": record["root_index"],
                        "stage": "selected_prefix",
                        "k": k,
                        "m": m,
                    }
                )
                failed = True
                break
            inequalities_checked += 1
        if one_based % 10 == 0 or one_based == args.end:
            print(
                f"{one_based}/{args.end}; tails={tail_certificates}; "
                f"blocks={blocks_checked}; inequalities={inequalities_checked}; "
                f"failures={len(failures)}; elapsed={time.time()-started:.1f}s",
                flush=True,
            )
    report = {
        "schema_version": 1,
        "proof_status": "independent_4096_bit_arb_uniform_tail_prefix_audit",
        "tail_sha256": hashlib.sha256(tail_bytes).hexdigest(),
        "environment": {
            "python": sys.version.split()[0],
            "python_flint": flint.__version__,
            "arb_precision_bits": ctx.prec,
        },
        "start_root": args.start,
        "end_root": args.end,
        "root_count": args.end - args.start + 1,
        "tail_certificates_checked": tail_certificates,
        "positive_blocks_checked": blocks_checked,
        "certified_inequalities_checked": inequalities_checked,
        "failures": failures,
        "status": "PASS" if not failures else "FAIL",
        "elapsed_seconds": time.time() - started,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(report, indent=2), flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
