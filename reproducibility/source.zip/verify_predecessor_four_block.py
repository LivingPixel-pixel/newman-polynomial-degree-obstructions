#!/usr/bin/env python3
"""Dependency-free exact audit for the four-block safe-lattice theorem.

The manuscript proof is uniform for every odd v >= 5.  This checker verifies
the four-block identities and predecessor routing through a selectable finite
range, records every rational endpoint margin, and emits explicit mod-7
Euclidean certificates for the three finite exceptional (v, s) pairs.

The JSON writer uses explicit UTF-8 bytes with LF line endings.  Therefore the
documented SHA-256 is platform-independent and is the hash of canonical LF
bytes, not the native text-mode output of the host operating system.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path


Poly = tuple[int, ...]
ZERO: Poly = (0,)
ONE: Poly = (1,)


def trim(values: list[int]) -> Poly:
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return tuple(values)


def add(left: Poly, right: Poly) -> Poly:
    values = [0] * max(len(left), len(right))
    for index, value in enumerate(left):
        values[index] += value
    for index, value in enumerate(right):
        values[index] += value
    return trim(values)


def neg(poly: Poly) -> Poly:
    return tuple(-value for value in poly)


def sub(left: Poly, right: Poly) -> Poly:
    return add(left, neg(right))


def shift(poly: Poly, amount: int = 1, scale: int = 1) -> Poly:
    if poly == ZERO or scale == 0:
        return ZERO
    return (0,) * amount + tuple(scale * value for value in poly)


def partial(k: int, m: int) -> Poly:
    return tuple((-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1))


def pvalue(k: int, m: int, t: Fraction) -> Fraction:
    return sum(
        Fraction((-1) ** ell * math.comb(k + ell, ell)) * t**ell
        for ell in range(m + 1)
    )


def sequences(v: int) -> tuple[list[Poly], list[Poly], list[Poly]]:
    r_limit = 5 * v
    q_limit = 10 * v
    r = [ZERO for _ in range(r_limit + 1)]
    even = [ZERO for _ in range(r_limit + 1)]
    q = [ZERO for _ in range(q_limit + 1)]
    q[0] = ONE

    for m in range(r_limit + 1):
        value = ONE
        if m >= 1:
            value = sub(value, shift(r[m - 1], scale=2))
        if m >= 2:
            value = sub(value, shift(r[m - 2], amount=2))
        if m >= v:
            value = add(value, r[m - v])
        r[m] = value

        evalue = ONE
        if m >= 1:
            evalue = sub(evalue, shift(r[m - 1]))
        if m >= 2:
            evalue = sub(evalue, shift(r[m - 2], amount=2))
        even[m] = evalue

    for n in range(1, q_limit + 1):
        value = ONE if n % 2 == 0 or n >= v else ZERO
        if n >= 2:
            value = sub(value, shift(q[n - 2]))
        if n >= v:
            value = sub(value, q[n - v])
        q[n] = value
    return r, even, q


def audit_v(v: int) -> dict[str, int]:
    assert v >= 5 and v % 2 == 1
    r, even, q = sequences(v)
    four_block_checks = 0
    parity_checks = 0
    predecessor_pair_checks = 0

    for m in range(4 * v):
        expected = ZERO
        for block in range(m // v + 1):
            expected = add(expected, partial(2 * block + 1, m - block * v))
        assert r[m] == expected, (v, "four_block", m)
        four_block_checks += 1

    for m in range(5 * v + 1):
        assert q[2 * m] == even[m], (v, "even", m)
        if m >= 1 and v + 2 * m <= 10 * v:
            assert q[v + 2 * m] == shift(r[m - 1]), (v, "odd", m)
        parity_checks += 1

    for j in range(4 * v):
        odd_n = v + 2 * j + 4
        assert q[odd_n - 2] == shift(r[j]), (v, "odd_left", j)
        assert q[odd_n - v] == even[j + 2], (v, "odd_right", j)
        predecessor_pair_checks += 1

        even_n = 2 * j + 2 * v + 2
        assert q[even_n - v] == shift(r[j]), (v, "even_left", j)
        assert q[even_n - 2] == even[j + v], (v, "even_right", j)
        predecessor_pair_checks += 1

    return {
        "v": v,
        "four_block_checks": four_block_checks,
        "parity_checks": parity_checks,
        "predecessor_pair_checks": predecessor_pair_checks,
    }


INTERVALS = {
    1: (Fraction(277, 1000), Fraction(279, 1000)),
    3: (Fraction(288, 1000), Fraction(290, 1000)),
    5: (Fraction(323, 1000), Fraction(325, 1000)),
    7: (Fraction(359, 1000), Fraction(360, 1000)),
    9: (Fraction(391, 1000), Fraction(392, 1000)),
    11: (Fraction(420, 1000), Fraction(421, 1000)),
    13: (Fraction(446, 1000), Fraction(447, 1000)),
    15: (Fraction(469, 1000), Fraction(471, 1000)),
    17: (Fraction(490, 1000), Fraction(492, 1000)),
}


def minimum_v(offset: int) -> int:
    if offset == 1:
        return 7
    return max(5, offset + 2)


def four_block_value(v: int, offset: int, t: Fraction) -> Fraction:
    return (
        pvalue(1, 3 * v + offset, t)
        + pvalue(3, 2 * v + offset, t)
        + pvalue(5, v + offset, t)
        + pvalue(7, offset, t)
    )


def rational_margins() -> dict[str, object]:
    half = Fraction(1, 2)
    nonexceptional = []
    for offset in range(2, 18, 2):
        v0 = max(5, offset + 1)
        lower_at_half = (
            pvalue(1, 3 * v0 + offset, half)
            + Fraction(1, 1) / (1 + half) ** 4
            + pvalue(5, v0 + offset, half)
            + pvalue(7, offset, half)
        )
        assert lower_at_half > 0
        nonexceptional.append(
            {
                "offset": offset,
                "minimum_v": v0,
                "lower_bound_at_one_half": str(lower_at_half),
            }
        )

    offset_zero_v9 = (
        pvalue(1, 27, half)
        + Fraction(1, 1) / (1 + half) ** 4
        + pvalue(5, 9, half)
        + 1
    )
    p5_37 = pvalue(5, 37, half)
    late_odd = (
        Fraction(1, 1) / (1 + half) ** 2
        + pvalue(3, 61, half)
        + Fraction(1, 1) / (1 + half) ** 6
        + pvalue(7, 19, half)
    )
    assert offset_zero_v9 > 0 and p5_37 > 0 and late_odd > 0

    root_records = []
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = (
            Fraction(1, 1) / (1 + alpha) ** 2
            + pvalue(3, 2 * v0 + offset, alpha)
            + Fraction(1, 1) / (1 + alpha) ** 6
            + pvalue(7, offset, alpha)
        )
        upper = (
            pvalue(1, 3 * v0 + offset, beta)
            + Fraction(1, 1) / (1 + beta) ** 4
            + pvalue(5, v0 + offset, beta)
            + pvalue(7, offset, beta)
        )
        ratio = (
            Fraction(
                math.comb(2 * (v0 + 2) + offset + 4, 3),
                math.comb(2 * v0 + offset + 4, 3),
            )
            * beta**4
        )
        odd_margin = 1 - (
            math.comb(offset + 8, 7) * beta ** (offset + 2)
            + math.comb(2 * v0 + offset + 4, 3)
            * beta ** (2 * v0 + offset + 2)
        )
        assert lower > 0 and upper < 0 and ratio < 1 and odd_margin > 0

        if offset == 1:
            exponent = 4 * v0 + offset + 1
            def even_bound(t: Fraction) -> Fraction:
                return (
                    (1 - beta**exponent) / (1 + t)
                    - t
                    * (
                        Fraction(1, 1) / (1 + t) ** 3
                        + pvalue(4, 2 * v0 + offset - 1, t)
                        + Fraction(1, 1) / (1 + t) ** 7
                        + pvalue(8, offset - 1, t)
                    )
                )
            even_left = even_bound(alpha)
            even_right = even_bound(beta)
            assert even_left > 0 and even_right > 0
            even_kind = "lower_positive"
        else:
            def even_bound(t: Fraction) -> Fraction:
                return (
                    Fraction(1, 1) / (1 + t)
                    - t
                    * (
                        pvalue(2, 3 * v0 + offset - 1, t)
                        + Fraction(1, 1) / (1 + t) ** 5
                        + pvalue(6, v0 + offset - 1, t)
                        + pvalue(8, offset - 1, t)
                    )
                )
            even_left = even_bound(alpha)
            even_right = even_bound(beta)
            assert even_left < 0 and even_right < 0
            even_kind = "upper_negative"

        root_records.append(
            {
                "offset": offset,
                "minimum_v": v0,
                "alpha": str(alpha),
                "beta": str(beta),
                "lower_envelope_at_alpha": str(lower),
                "upper_envelope_at_beta": str(upper),
                "v_step_positive_term_ratio_upper": str(ratio),
                "odd_companion_margin": str(odd_margin),
                "even_companion_bound_kind": even_kind,
                "even_companion_bound_at_alpha": str(even_left),
                "even_companion_bound_at_beta": str(even_right),
            }
        )

    return {
        "even_offsets_2_to_16": nonexceptional,
        "offset_zero_v_at_least_9_lower_at_one_half": str(offset_zero_v9),
        "p5_37_at_one_half": str(p5_37),
        "odd_offsets_at_least_19_lower_at_one_half": str(late_odd),
        "root_brackets": root_records,
    }


def primitive_content(poly: Poly) -> int:
    result = 0
    for coefficient in poly:
        result = math.gcd(result, abs(coefficient))
    return result


def mod_trim(values: list[int], prime: int) -> list[int]:
    values = [value % prime for value in values]
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return values


def mod_monic(values: list[int], prime: int) -> list[int]:
    values = mod_trim(values, prime)
    if values == [0]:
        return values
    inverse = pow(values[-1], -1, prime)
    return [(inverse * value) % prime for value in values]


def mod_remainder(left: list[int], right: list[int], prime: int) -> list[int]:
    left = mod_trim(left[:], prime)
    right = mod_trim(right[:], prime)
    assert right != [0]
    inverse = pow(right[-1], -1, prime)
    while left != [0] and len(left) >= len(right):
        amount = len(left) - len(right)
        factor = left[-1] * inverse % prime
        for index, value in enumerate(right):
            left[index + amount] = (left[index + amount] - factor * value) % prime
        left = mod_trim(left, prime)
    return left


def mod_gcd_certificate(left: Poly, right: Poly, prime: int = 7) -> dict[str, object]:
    assert primitive_content(left) == 1 and primitive_content(right) == 1
    assert left[-1] % prime != 0 and right[-1] % prime != 0
    a = mod_monic(list(left), prime)
    b = mod_monic(list(right), prime)
    remainders = []
    while b != [0]:
        remainder = mod_remainder(a, b, prime)
        if remainder != [0]:
            remainder = mod_monic(remainder, prime)
            remainders.append(remainder)
        a, b = b, remainder
    gcd_poly = mod_monic(a, prime)
    assert gcd_poly == [1]
    return {
        "prime": prime,
        "left_content": primitive_content(left),
        "right_content": primitive_content(right),
        "left_degree_preserved": len(left) == len(mod_trim(list(left), prime)),
        "right_degree_preserved": len(right) == len(mod_trim(list(right), prime)),
        "left_monic_coefficients_mod_p_ascending": mod_monic(list(left), prime),
        "right_monic_coefficients_mod_p_ascending": mod_monic(list(right), prime),
        "euclidean_nonzero_remainders_monic_mod_p_ascending": remainders,
        "gcd_monic_coefficients_mod_p_ascending": gcd_poly,
    }


def exceptional_certificates() -> list[dict[str, object]]:
    records = []
    for v, offset in ((5, 0), (7, 0), (5, 1)):
        r, even, _q = sequences(v)
        j = 3 * v + offset
        for companion, poly in (("odd", even[j + 2]), ("even", even[j + v])):
            certificate = mod_gcd_certificate(r[j], poly)
            certificate.update(
                {
                    "v": v,
                    "offset": offset,
                    "j": j,
                    "companion": companion,
                    "r_degree": len(r[j]) - 1,
                    "companion_degree": len(poly) - 1,
                }
            )
            records.append(certificate)
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v-max", type=int, default=251)
    parser.add_argument(
        "--output", type=Path, default=Path("predecessor_four_block_exact.json")
    )
    args = parser.parse_args()
    assert args.v_max >= 5
    v_values = list(range(5, args.v_max + 1, 2))
    records = [audit_v(v) for v in v_values]
    exception_records = exceptional_certificates()
    report = {
        "schema_version": 1,
        "line_ending_and_hash_convention": "UTF-8 bytes with canonical LF newlines",
        "proof_status": "exact_audit_supporting_uniform_four_block_manuscript_proof",
        "theorem": {
            "odd_first_escape_index_at_least": "9*v+4",
            "even_first_escape_index_at_least": "10*v+2",
            "scope": "odd v>=5 and 0<t<1/2",
        },
        "audited_v_values": v_values,
        "totals": {
            "v_count": len(records),
            "four_block_checks": sum(item["four_block_checks"] for item in records),
            "parity_checks": sum(item["parity_checks"] for item in records),
            "predecessor_pair_checks": sum(
                item["predecessor_pair_checks"] for item in records
            ),
            "finite_exception_modular_gcd_certificates": len(exception_records),
        },
        "exact_rational_margins": rational_margins(),
        "finite_exception_modular_gcd_certificates": exception_records,
        "audit_window_record_shape": {
            "per_v_four_block_checks": "4*v",
            "per_v_parity_checks": "5*v+1",
            "per_v_predecessor_pair_checks": "8*v",
        },
    }
    payload = (
        json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n"
    ).encode("utf-8")
    args.output.write_bytes(payload)
    print(
        "PASS: exact four-block identities for "
        f"{len(records)} odd exponents through v={v_values[-1]}"
    )
    print(json.dumps(report["totals"], sort_keys=True))
    print(f"wrote canonical LF bytes to {args.output}")


if __name__ == "__main__":
    main()
