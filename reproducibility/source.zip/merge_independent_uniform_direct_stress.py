#!/usr/bin/env python3
"""Validate and merge the four direct-uniform recurrence stress shards."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
NAMES = [f"independent_uniform_direct_q{i}.json" for i in range(1, 5)]
EXPECTED_RANGES = [(1, 1746), (1747, 3491), (3492, 5237), (5238, 6982)]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    reports = [
        json.loads((ROOT / name).read_text(encoding="utf-8")) for name in NAMES
    ]
    tail_hash = digest(ROOT / "quartic_uniform_negative_exact.json")
    ranges = [(item["start_root"], item["end_root"]) for item in reports]
    failures = [failure for item in reports for failure in item["failures"]]
    cases = sum(item["cases_checked"] for item in reports)
    coefficients = sum(item["coefficients_checked"] for item in reports)
    status = "PASS"
    if (
        ranges != EXPECTED_RANGES
        or not all(item["status"] == "PASS" for item in reports)
        or not all(item["tail_sha256"] == tail_hash for item in reports)
        or not all(item["exponents"] == [23, 251] for item in reports)
        or not all(item["environment"] == reports[0]["environment"] for item in reports)
        or sum(item["root_count"] for item in reports) != 6982
        or cases != 13964
        or failures
    ):
        status = "FAIL"
    report = {
        "schema_version": 1,
        "proof_status": "merged_independent_finite_direct_uniform_stress",
        "logical_scope": "finite redundant stress only; not an infinite proof",
        "tail_sha256": tail_hash,
        "environment": reports[0]["environment"],
        "ranges": EXPECTED_RANGES,
        "target_roots": 6982,
        "exponents": [23, 251],
        "cases_checked": cases,
        "coefficients_checked": coefficients,
        "maximum_obstruction_index": max(
            item["maximum_obstruction_index"] for item in reports
        ),
        "failures": failures,
        "input_sha256": {name: digest(ROOT / name) for name in NAMES},
        "status": status,
    }
    output = ROOT / "independent_uniform_direct_stress.json"
    output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps(report, indent=2))
    if status != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
