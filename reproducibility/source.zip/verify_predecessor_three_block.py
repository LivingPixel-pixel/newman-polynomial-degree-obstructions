#!/usr/bin/env python3
"""Dependency-free exact audit for the three-block safe-lattice theorem.

The manuscript proof is uniform in every odd v >= 5.  This checker audits the
three-block polynomial identities through a user-selected finite v-range and
records every rational endpoint margin used by the analytic proof.  It is an
independent audit, not a substitute for the proof.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path


Poly = tuple[int, ...]


def trim(values: list[int]) -> Poly:
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return tuple(values)


def add(left: Poly, right: Poly) -> Poly:
    values = [0] * max(len(left), len(right))
    for index, value in enumerate(left):
        values[index] += value
    for index, value in enumerate(right):
        values[index] += value
    return trim(values)


def neg(poly: Poly) -> Poly:
    return tuple(-value for value in poly)


def sub(left: Poly, right: Poly) -> Poly:
    return add(left, neg(right))


def shift(poly: Poly, amount: int = 1, scale: int = 1) -> Poly:
    if poly == (0,) or scale == 0:
        return (0,)
    return (0,) * amount + tuple(scale * value for value in poly)


ZERO: Poly = (0,)
ONE: Poly = (1,)


def partial(k: int, m: int) -> Poly:
    return tuple((-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1))


def pvalue(k: int, m: int, t: Fraction) -> Fraction:
    return sum(
        Fraction((-1) ** ell * math.comb(k + ell, ell)) * t**ell
        for ell in range(m + 1)
    )


def sequences(v: int) -> tuple[list[Poly], list[Poly], list[Poly]]:
    r_limit = 4 * v
    q_limit = 8 * v
    r = [ZERO for _ in range(r_limit + 1)]
    even = [ZERO for _ in range(r_limit + 1)]
    q = [ZERO for _ in range(q_limit + 1)]
    q[0] = ONE

    for m in range(r_limit + 1):
        value = ONE
        if m >= 1:
            value = sub(value, shift(r[m - 1], scale=2))
        if m >= 2:
            value = sub(value, shift(r[m - 2], amount=2))
        if m >= v:
            value = add(value, r[m - v])
        r[m] = value

        evalue = ONE
        if m >= 1:
            evalue = sub(evalue, shift(r[m - 1]))
        if m >= 2:
            evalue = sub(evalue, shift(r[m - 2], amount=2))
        even[m] = evalue

    for n in range(1, q_limit + 1):
        value = ONE if n % 2 == 0 or n >= v else ZERO
        if n >= 2:
            value = sub(value, shift(q[n - 2]))
        if n >= v:
            value = sub(value, q[n - v])
        q[n] = value
    return r, even, q


def audit_v(v: int) -> dict[str, int]:
    assert v >= 5 and v % 2 == 1
    r, even, q = sequences(v)
    three_block_checks = 0
    parity_checks = 0
    predecessor_pair_checks = 0

    for m in range(3 * v):
        expected = ZERO
        for block in range(m // v + 1):
            expected = add(expected, partial(2 * block + 1, m - block * v))
        assert r[m] == expected, (v, "three_block", m)
        three_block_checks += 1

    for m in range(4 * v + 1):
        assert q[2 * m] == even[m], (v, "even", m)
        if m >= 1 and v + 2 * m <= 8 * v:
            assert q[v + 2 * m] == shift(r[m - 1]), (v, "odd", m)
        parity_checks += 1

    for j in range(3 * v):
        odd_n = v + 2 * j + 4
        assert q[odd_n - 2] == shift(r[j]), (v, "odd_left", j)
        assert q[odd_n - v] == even[j + 2], (v, "odd_right", j)
        predecessor_pair_checks += 1

        even_n = 2 * j + 2 * v + 2
        assert q[even_n - v] == shift(r[j]), (v, "even_left", j)
        assert q[even_n - 2] == even[j + v], (v, "even_right", j)
        predecessor_pair_checks += 1

    return {
        "v": v,
        "three_block_checks": three_block_checks,
        "parity_checks": parity_checks,
        "predecessor_pair_checks": predecessor_pair_checks,
    }


INTERVALS = {
    1: (Fraction(3178, 10000), Fraction(322, 1000)),
    3: (Fraction(3441, 10000), Fraction(345, 1000)),
    5: (Fraction(3873, 10000), Fraction(388, 1000)),
    7: (Fraction(4270, 10000), Fraction(428, 1000)),
    9: (Fraction(4618, 10000), Fraction(462, 1000)),
    11: (Fraction(4921, 10000), Fraction(493, 1000)),
}


def minimum_v(offset: int) -> int:
    value = max(5, offset + 2)
    return value if value % 2 == 1 else value + 1


def rational_margins() -> dict[str, object]:
    margins: dict[str, object] = {}
    root_records = []
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = (
            pvalue(1, 2 * v0 + offset, alpha)
            + Fraction(1, 1) / (1 + alpha) ** 4
            + pvalue(5, offset, alpha)
        )
        upper = (
            Fraction(1, 1) / (1 + beta) ** 2
            + pvalue(3, v0 + offset, beta)
            + pvalue(5, offset, beta)
        )
        odd_companion_margin = 1 - (
            math.comb(offset + 6, 5) * beta ** (offset + 2)
            + (2 * v0 + offset + 2) * beta ** (2 * v0 + offset + 2)
        )
        assert lower > 0
        assert upper < 0
        assert odd_companion_margin > Fraction(1, 4)
        root_records.append(
            {
                "offset": offset,
                "minimum_v": v0,
                "alpha": str(alpha),
                "beta": str(beta),
                "lower_bracket_at_alpha": str(lower),
                "upper_bracket_at_beta": str(upper),
                "odd_companion_margin": str(odd_companion_margin),
            }
        )

    half = Fraction(1, 2)
    uniform_even_offset = (
        Fraction(1, 1) / (1 + half) ** 2
        + pvalue(3, 7, half)
        + Fraction(1, 1) / (1 + half) ** 6
    )
    special_v5_offset_zero = pvalue(1, 10, half) + pvalue(3, 5, half) + 1
    late_odd_offset = (
        pvalue(1, 43, half)
        + Fraction(1, 1) / (1 + half) ** 4
        + pvalue(5, 13, half)
    )
    assert uniform_even_offset == Fraction(4021, 11664) > 0
    assert special_v5_offset_zero == Fraction(907, 1024) > 0
    assert late_odd_offset > 0
    margins["root_brackets"] = root_records
    margins["uniform_even_offset_lower_bound_at_one_half"] = str(uniform_even_offset)
    margins["special_v5_offset_zero_at_one_half"] = str(special_v5_offset_zero)
    margins["late_odd_offset_lower_bound_at_one_half"] = str(late_odd_offset)
    return margins


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v-max", type=int, default=201)
    parser.add_argument(
        "--output", type=Path, default=Path("predecessor_three_block_exact.json")
    )
    args = parser.parse_args()
    assert args.v_max >= 5
    v_values = list(range(5, args.v_max + 1, 2))
    records = [audit_v(v) for v in v_values]
    report = {
        "schema_version": 1,
        "proof_status": "exact_audit_supporting_uniform_three_block_manuscript_proof",
        "theorem": {
            "odd_first_escape_index_at_least": "7*v+4",
            "even_first_escape_index_at_least": "8*v+2",
            "scope": "odd v>=5 and 0<t<1/2",
        },
        "audited_v_values": v_values,
        "totals": {
            "v_count": len(records),
            "three_block_checks": sum(item["three_block_checks"] for item in records),
            "parity_checks": sum(item["parity_checks"] for item in records),
            "predecessor_pair_checks": sum(
                item["predecessor_pair_checks"] for item in records
            ),
        },
        "exact_rational_margins": rational_margins(),
        "records": records,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(
        "PASS: exact three-block identities for "
        f"{len(records)} odd exponents through v={v_values[-1]}"
    )
    print(json.dumps(report["totals"], sort_keys=True))
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
