#!/usr/bin/env python3
"""Exact finite stress audit of the uniform block proof for odd v=23..99.

This does not use the block-limit formulas.  It iterates in Z[a]/(m_a),
separates every sign with rational target-root intervals, and confirms that the
only zero before the first negative coefficient is b_v.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import sys
import time

sys.set_int_max_str_digits(0)
ROOT = Path(__file__).resolve().parent
MODULE = ROOT / "verify_forced_recurrence_global.py"
GLOBAL = ROOT / "forced_recurrence_global_exact.json"
DEFAULT_OUTPUT = ROOT / "stress_exact_recurrence_v23_v99.json"


def load_module():
    spec = importlib.util.spec_from_file_location("global_recurrence", MODULE)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-v", type=int, default=23)
    parser.add_argument("--max-v", type=int, default=99)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    assert args.min_v % 2 and args.max_v % 2 and args.min_v <= args.max_v
    mod = load_module()
    proof = json.loads(GLOBAL.read_text(encoding="utf-8"))
    records = []
    start = time.perf_counter()
    for entry in proof["records"]:
        candidate_start = time.perf_counter()
        candidate_id = int(entry["candidate_id"])
        polynomial = tuple(entry["minimal_polynomial_coefficients"])
        interval = tuple(Fraction(value) for value in entry["final_target_root_interval"])
        root = mod.AlgebraicRoot(polynomial, interval)
        selected = entry["uniform_odd_v_at_least_23"]
        k, offset = int(selected["k"]), int(selected["offset"])
        cases = []
        for v in range(args.min_v, args.max_v + 1, 2):
            result = mod.forced_negative(root, v, k * v + offset)
            assert result["status"] == "negative", (candidate_id, v, result)
            assert result["structural_zero_indices"] == [v], (candidate_id, v, result)
            cases.append({"v": v, "first_negative_n": result["n"]})
        records.append(
            {
                "candidate_id": candidate_id,
                "selected_uniform_index": f"{k}*v+{offset}",
                "case_count": len(cases),
                "cases": cases,
                "final_target_root_interval": [str(root.interval[0]), str(root.interval[1])],
            }
        )
        args.output.write_bytes(
            (json.dumps(
                {
                    "schema_version": 1,
                    "proof_role": "exact_finite_stress_audit_not_needed_for_uniform_theorem",
                    "records": records,
                },
                indent=2,
            )
            + "\n").encode("utf-8"),
        )
        print(
            f"candidate {candidate_id}/126: {len(cases)} exact odd-v recurrences in "
            f"{time.perf_counter() - candidate_start:.2f}s",
            flush=True,
        )
    report = {
        "schema_version": 1,
        "proof_role": "exact_finite_stress_audit_not_needed_for_uniform_theorem",
        "candidate_count": len(records),
        "case_count": sum(record["case_count"] for record in records),
        "odd_v_range": [args.min_v, args.max_v],
        "records": records,
    }
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(f"wrote {args.output} after {time.perf_counter() - start:.2f}s")


if __name__ == "__main__":
    main()
