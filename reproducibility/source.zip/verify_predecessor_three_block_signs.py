#!/usr/bin/env python3
"""Exact symbolic sign audit for the three-block safe-lattice proof.

Every claimed sign is reduced to a rational endpoint sign plus an exact Sturm
root count on a rational interval.  The output is deterministic JSON and is
intended to make the finite algebra inside the uniform manuscript proof easy
to audit independently.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import sympy as sp


T = sp.Symbol("t")
HALF = sp.Rational(1, 2)


INTERVALS = {
    1: (sp.Rational(3178, 10000), sp.Rational(322, 1000)),
    3: (sp.Rational(3441, 10000), sp.Rational(345, 1000)),
    5: (sp.Rational(3873, 10000), sp.Rational(388, 1000)),
    7: (sp.Rational(4270, 10000), sp.Rational(428, 1000)),
    9: (sp.Rational(4618, 10000), sp.Rational(462, 1000)),
    11: (sp.Rational(4921, 10000), sp.Rational(493, 1000)),
}


def partial(k: int, m: int) -> sp.Expr:
    return sp.expand(
        sum((-1) ** ell * sp.binomial(k + ell, ell) * T**ell for ell in range(m + 1))
    )


def minimum_v(offset: int) -> int:
    value = max(5, offset + 2)
    return value if value % 2 == 1 else value + 1


def numerator(expr: sp.Expr) -> sp.Poly:
    num, den = sp.cancel(expr).as_numer_denom()
    assert sp.Poly(den, T).count_roots(0, HALF) == 0
    return sp.Poly(num, T, domain=sp.QQ)


def certify_sign(
    name: str,
    expr: sp.Expr,
    left: sp.Rational,
    right: sp.Rational,
    expected_sign: int,
) -> dict[str, object]:
    assert left < right
    poly = numerator(expr)
    root_count = int(poly.count_roots(left, right))
    left_value = sp.factor(expr.subs(T, left))
    right_value = sp.factor(expr.subs(T, right))
    assert root_count == 0
    assert sp.sign(left_value) == expected_sign
    assert sp.sign(right_value) == expected_sign
    return {
        "name": name,
        "interval": [str(left), str(right)],
        "expected_sign": expected_sign,
        "numerator_degree": int(poly.degree()),
        "sturm_root_count": root_count,
        "left_value": str(left_value),
        "right_value": str(right_value),
    }


def build_report() -> dict[str, object]:
    certificates: list[dict[str, object]] = []

    # Nonexceptional third-block offsets.
    uniform_even_lower = (1 + T) ** -2 + partial(3, 7) + (1 + T) ** -6
    certificates.append(
        certify_sign("uniform_even_offset_lower", uniform_even_lower, 0, HALF, 1)
    )
    special_v5_offset_zero = partial(1, 10) + partial(3, 5) + 1
    certificates.append(
        certify_sign("special_v5_offset_zero", special_v5_offset_zero, 0, HALF, 1)
    )
    late_odd_lower = partial(1, 43) + (1 + T) ** -4 + partial(5, 13)
    certificates.append(
        certify_sign("late_odd_offset_lower", late_odd_lower, 0, HALF, 1)
    )

    # Exact root brackets for the six exceptional odd offsets.
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = partial(1, 2 * v0 + offset) + (1 + T) ** -4 + partial(5, offset)
        upper = (1 + T) ** -2 + partial(3, v0 + offset) + partial(5, offset)
        certificates.append(
            certify_sign(f"offset_{offset}_lower_before_alpha", lower, 0, alpha, 1)
        )
        certificates.append(
            certify_sign(f"offset_{offset}_upper_after_beta", upper, beta, HALF, -1)
        )

    # The even-event companion at offset one is uniformly positive throughout
    # its root bracket.
    alpha, beta = INTERVALS[1]
    offset_one_companion_lower = (
        (1 + T) ** -1 - T * (partial(2, 10) + (1 + T) ** -5 + 1)
    )
    certificates.append(
        certify_sign(
            "offset_1_even_companion_lower",
            offset_one_companion_lower,
            alpha,
            beta,
            1,
        )
    )

    # At every other exceptional offset, an upper bound for the even-event
    # companion is uniformly negative throughout the corresponding bracket.
    for offset in (3, 5, 7, 9, 11):
        alpha, beta = INTERVALS[offset]
        v0 = minimum_v(offset)
        tail_upper = beta ** (3 * v0 + offset + 1)
        companion_upper = (
            (1 + T) ** -1
            - T
            * (
                (1 + T) ** -3
                + partial(4, v0 + offset - 1)
                + partial(6, offset - 1)
            )
            + tail_upper
        )
        certificates.append(
            certify_sign(
                f"offset_{offset}_even_companion_upper",
                companion_upper,
                alpha,
                beta,
                -1,
            )
        )

    return {
        "schema_version": 1,
        "proof_status": "exact_sturm_sign_audit_supporting_uniform_manuscript_proof",
        "theorem": {
            "odd_first_escape_index_at_least": "7*v+4",
            "even_first_escape_index_at_least": "8*v+2",
            "scope": "odd v>=5 and 0<t<1/2",
        },
        "certificate_count": len(certificates),
        "all_root_counts_zero": all(item["sturm_root_count"] == 0 for item in certificates),
        "certificates": certificates,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path("predecessor_three_block_signs_exact.json")
    )
    args = parser.parse_args()
    report = build_report()
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(
        "PASS: exact three-block sign audit with "
        f"{report['certificate_count']} root-free rational-interval certificates"
    )
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
