#!/usr/bin/env python3
"""Dependency-free exact audit for the six-block safe-lattice theorem."""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path

Poly = tuple[int, ...]
ZERO: Poly = (0,)
ONE: Poly = (1,)

INTERVALS = {
    1: (Fraction(226, 1000), Fraction(228, 1000)),
    3: (Fraction(220, 1000), Fraction(222, 1000)),
    5: (Fraction(246, 1000), Fraction(248, 1000)),
    7: (Fraction(274, 1000), Fraction(276, 1000)),
    9: (Fraction(301, 1000), Fraction(303, 1000)),
    11: (Fraction(326, 1000), Fraction(329, 1000)),
    13: (Fraction(350, 1000), Fraction(352, 1000)),
    15: (Fraction(371, 1000), Fraction(374, 1000)),
    17: (Fraction(391, 1000), Fraction(394, 1000)),
    19: (Fraction(410, 1000), Fraction(413, 1000)),
    21: (Fraction(427, 1000), Fraction(430, 1000)),
    23: (Fraction(443, 1000), Fraction(446, 1000)),
    25: (Fraction(458, 1000), Fraction(462, 1000)),
    27: (Fraction(472, 1000), Fraction(476, 1000)),
    29: (Fraction(486, 1000), Fraction(489, 1000)),
    31: (Fraction(499, 1000), Fraction(4999, 10000)),
}

EXCEPTION_CASES = tuple(
    [(v, 0) for v in range(5, 22, 2)]
    + [(v, 2) for v in range(5, 14, 2)]
    + [(v, 1) for v in range(5, 18, 2)]
    + [(v, 3) for v in range(5, 10, 2)]
)
PRIMES = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31)


def trim(values: list[int]) -> Poly:
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return tuple(values)


def add(left: Poly, right: Poly) -> Poly:
    values = [0] * max(len(left), len(right))
    for i, value in enumerate(left):
        values[i] += value
    for i, value in enumerate(right):
        values[i] += value
    return trim(values)


def sub(left: Poly, right: Poly) -> Poly:
    return add(left, tuple(-value for value in right))


def shift(poly: Poly, amount: int = 1, scale: int = 1) -> Poly:
    if poly == ZERO or scale == 0:
        return ZERO
    return (0,) * amount + tuple(scale * value for value in poly)


def partial(k: int, m: int) -> Poly:
    return tuple((-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1))


def pvalue(k: int, m: int, t: Fraction) -> Fraction:
    return sum(
        Fraction((-1) ** ell * math.comb(k + ell, ell)) * t**ell
        for ell in range(m + 1)
    )


def sequences(v: int) -> tuple[list[Poly], list[Poly], list[Poly]]:
    r_limit = 7 * v
    q_limit = 14 * v
    r = [ZERO for _ in range(r_limit + 1)]
    even = [ZERO for _ in range(r_limit + 1)]
    q = [ZERO for _ in range(q_limit + 1)]
    q[0] = ONE
    for m in range(r_limit + 1):
        value = ONE
        if m >= 1:
            value = sub(value, shift(r[m - 1], scale=2))
        if m >= 2:
            value = sub(value, shift(r[m - 2], amount=2))
        if m >= v:
            value = add(value, r[m - v])
        r[m] = value
        evalue = ONE
        if m >= 1:
            evalue = sub(evalue, shift(r[m - 1]))
        if m >= 2:
            evalue = sub(evalue, shift(r[m - 2], amount=2))
        even[m] = evalue
    for n in range(1, q_limit + 1):
        value = ONE if n % 2 == 0 or n >= v else ZERO
        if n >= 2:
            value = sub(value, shift(q[n - 2]))
        if n >= v:
            value = sub(value, q[n - v])
        q[n] = value
    return r, even, q


def audit_v(v: int) -> dict[str, int]:
    r, even, q = sequences(v)
    for m in range(6 * v):
        expected = ZERO
        for block in range(m // v + 1):
            expected = add(expected, partial(2 * block + 1, m - block * v))
        assert r[m] == expected, (v, "six_block", m)
    for m in range(7 * v + 1):
        assert q[2 * m] == even[m], (v, "even", m)
        if m >= 1 and v + 2 * m <= 14 * v:
            assert q[v + 2 * m] == shift(r[m - 1]), (v, "odd", m)
    for j in range(6 * v):
        odd_n = v + 2 * j + 4
        assert q[odd_n - 2] == shift(r[j])
        assert q[odd_n - v] == even[j + 2]
        even_n = 2 * j + 2 * v + 2
        assert q[even_n - v] == shift(r[j])
        assert q[even_n - 2] == even[j + v]
    return {
        "v": v,
        "six_block_checks": 6 * v,
        "parity_checks": 7 * v + 1,
        "predecessor_pair_checks": 12 * v,
    }


def minimum_v(offset: int) -> int:
    if offset == 1:
        return 19
    if offset == 3:
        return 11
    return offset + 2


def rational_margins() -> dict[str, object]:
    half = Fraction(1, 2)
    small_even = []
    for offset, v0 in ((0, 23), (2, 15), (4, 5), (6, 7), (8, 9)):
        value = (
            pvalue(1, 5 * v0 + offset, half)
            + Fraction(1, 1) / (1 + half) ** 4
            + pvalue(5, 3 * v0 + offset, half)
            + Fraction(1, 1) / (1 + half) ** 8
            + pvalue(9, v0 + offset, half)
            + pvalue(11, offset, half)
        )
        assert value > 0
        small_even.append({"offset": offset, "minimum_v": v0, "lower_at_one_half": str(value)})

    a11 = math.comb(22, 11)
    a9 = math.comb(31, 9)
    a5 = math.comb(49, 5)
    a1 = 67
    even_tail_base = (
        Fraction(a9, a11) * Fraction(24, 1) * Fraction(1, 2) ** 11
        + Fraction(a5, a11) * Fraction(24, 1) * Fraction(1, 2) ** 33
        + Fraction(a1, a11) * Fraction(24, 1) * Fraction(1, 2) ** 55
    )
    assert even_tail_base < 1

    late_odd_error = (
        Fraction(math.comb(45, 11), 2**34)
        + Fraction(math.comb(111, 7), 2**104)
        + Fraction(math.comb(177, 3), 2**174)
    )
    late_odd_limit = sum(Fraction(2, 3) ** (2 * k + 2) for k in range(6))
    assert late_odd_error < late_odd_limit

    roots = []
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = (
            Fraction(1, 1) / (1 + alpha) ** 2
            + pvalue(3, 4 * v0 + offset, alpha)
            + Fraction(1, 1) / (1 + alpha) ** 6
            + pvalue(7, 2 * v0 + offset, alpha)
            + Fraction(1, 1) / (1 + alpha) ** 10
            + pvalue(11, offset, alpha)
        )
        upper = (
            pvalue(1, 5 * v0 + offset, beta)
            + Fraction(1, 1) / (1 + beta) ** 4
            + pvalue(5, 3 * v0 + offset, beta)
            + Fraction(1, 1) / (1 + beta) ** 8
            + pvalue(9, v0 + offset, beta)
            + pvalue(11, offset, beta)
        )
        ratio1 = Fraction(math.comb(4 * (v0 + 2) + offset + 4, 3), math.comb(4 * v0 + offset + 4, 3)) * beta**8
        ratio2 = Fraction(math.comb(2 * (v0 + 2) + offset + 8, 7), math.comb(2 * v0 + offset + 8, 7)) * beta**4
        odd_margin = 1 - (
            math.comb(4 * v0 + offset + 4, 3) * beta ** (4 * v0 + offset + 2)
            + math.comb(2 * v0 + offset + 8, 7) * beta ** (2 * v0 + offset + 2)
            + math.comb(offset + 12, 11) * beta ** (offset + 2)
        )
        assert lower > 0 and upper < 0 and ratio1 < 1 and ratio2 < 1 and odd_margin > 0
        if offset == 1:
            def companion(t: Fraction) -> Fraction:
                return (
                    (1 - t ** (6 * v0 + offset + 1)) / (1 + t)
                    - t * (
                        Fraction(1, 1) / (1 + t) ** 3
                        + pvalue(4, 4 * v0 + offset - 1, t)
                        + Fraction(1, 1) / (1 + t) ** 7
                        + pvalue(8, 2 * v0 + offset - 1, t)
                        + Fraction(1, 1) / (1 + t) ** 11
                        + pvalue(12, offset - 1, t)
                    )
                )
            expected = 1
            kind = "lower_positive"
        else:
            def companion(t: Fraction) -> Fraction:
                return (
                    Fraction(1, 1) / (1 + t)
                    - t * (
                        pvalue(2, 5 * v0 + offset - 1, t)
                        + Fraction(1, 1) / (1 + t) ** 5
                        + pvalue(6, 3 * v0 + offset - 1, t)
                        + Fraction(1, 1) / (1 + t) ** 9
                        + pvalue(10, v0 + offset - 1, t)
                        + pvalue(12, offset - 1, t)
                    )
                )
            expected = -1
            kind = "upper_negative"
        left, right = companion(alpha), companion(beta)
        assert left * expected > 0 and right * expected > 0
        roots.append({
            "offset": offset, "minimum_v": v0, "alpha": str(alpha), "beta": str(beta),
            "lower_at_alpha": str(lower), "upper_at_beta": str(upper),
            "first_positive_term_v_step_ratio": str(ratio1),
            "second_positive_term_v_step_ratio": str(ratio2),
            "odd_companion_margin": str(odd_margin),
            "even_companion_bound_kind": kind,
            "even_companion_bound_at_alpha": str(left),
            "even_companion_bound_at_beta": str(right),
        })
    return {
        "small_even_offset_lower_bounds": small_even,
        "even_offsets_at_least_10_normalized_tail_base": str(even_tail_base),
        "odd_offsets_at_least_33_error_at_one_half": str(late_odd_error),
        "odd_offsets_at_least_33_limit_lower_bound": str(late_odd_limit),
        "root_brackets": roots,
    }


def content(poly: Poly) -> int:
    result = 0
    for value in poly:
        result = math.gcd(result, abs(value))
    return result


def mod_trim(values: list[int], prime: int) -> list[int]:
    values = [value % prime for value in values]
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return values


def monic(values: list[int], prime: int) -> list[int]:
    values = mod_trim(values, prime)
    if values == [0]:
        return values
    inv = pow(values[-1], -1, prime)
    return [(inv * value) % prime for value in values]


def remainder(left: list[int], right: list[int], prime: int) -> list[int]:
    left, right = mod_trim(left[:], prime), mod_trim(right[:], prime)
    inv = pow(right[-1], -1, prime)
    while left != [0] and len(left) >= len(right):
        amount = len(left) - len(right)
        factor = left[-1] * inv % prime
        for i, value in enumerate(right):
            left[i + amount] = (left[i + amount] - factor * value) % prime
        left = mod_trim(left, prime)
    return left


def certificate(left: Poly, right: Poly) -> dict[str, object]:
    assert content(left) == content(right) == 1
    for prime in PRIMES:
        if left[-1] % prime == 0 or right[-1] % prime == 0:
            continue
        a, b = monic(list(left), prime), monic(list(right), prime)
        chain = []
        while b != [0]:
            rem = remainder(a, b, prime)
            if rem != [0]:
                rem = monic(rem, prime)
                chain.append(rem)
            a, b = b, rem
        if monic(a, prime) == [1]:
            return {
                "prime": prime,
                "left_content": 1, "right_content": 1,
                "left_degree_preserved": True, "right_degree_preserved": True,
                "left_monic_coefficients_mod_p_ascending": monic(list(left), prime),
                "right_monic_coefficients_mod_p_ascending": monic(list(right), prime),
                "euclidean_nonzero_remainders_monic_mod_p_ascending": chain,
                "gcd_monic_coefficients_mod_p_ascending": [1],
            }
    raise AssertionError("no degree-preserving prime found")


def exceptional_certificates() -> list[dict[str, object]]:
    records = []
    for v, offset in EXCEPTION_CASES:
        r, even, _ = sequences(v)
        j = 5 * v + offset
        for companion_name, companion in (("odd", even[j + 2]), ("even", even[j + v])):
            item = certificate(r[j], companion)
            item.update({"v": v, "offset": offset, "j": j, "companion": companion_name,
                         "r_degree": len(r[j]) - 1, "companion_degree": len(companion) - 1})
            records.append(item)
    assert len(records) == 48
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v-max", type=int, default=251)
    parser.add_argument("--output", type=Path, default=Path("predecessor_six_block_exact.json"))
    args = parser.parse_args()
    values = list(range(5, args.v_max + 1, 2))
    records = [audit_v(v) for v in values]
    exceptions = exceptional_certificates()
    report = {
        "schema_version": 1,
        "line_ending_and_hash_convention": "UTF-8 bytes with canonical LF newlines",
        "proof_status": "exact_audit_supporting_uniform_six_block_manuscript_proof",
        "theorem": {"odd_first_escape_index_at_least": "13*v+4", "even_first_escape_index_at_least": "14*v+2", "scope": "odd v>=5 and 0<t<1/2"},
        "audited_v_values": values,
        "totals": {
            "v_count": len(records),
            "six_block_checks": sum(x["six_block_checks"] for x in records),
            "parity_checks": sum(x["parity_checks"] for x in records),
            "predecessor_pair_checks": sum(x["predecessor_pair_checks"] for x in records),
            "finite_exception_modular_gcd_certificates": len(exceptions),
        },
        "exact_rational_margins": rational_margins(),
        "finite_exception_modular_gcd_certificates": exceptions,
    }
    args.output.write_bytes((json.dumps(report, indent=2, sort_keys=True) + "\n").encode("utf-8"))
    print(f"PASS: six-block identities through v={values[-1]}")
    print(json.dumps(report["totals"], sort_keys=True))


if __name__ == "__main__":
    main()
