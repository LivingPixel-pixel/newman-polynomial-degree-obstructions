#!/usr/bin/env python3
"""Dependency-free exact audit for the five-block safe-lattice theorem.

The proof is uniform for every odd v >= 5.  This checker verifies the
five-block formulas and predecessor routing through a selectable finite
window, records the rational endpoint margins, and emits full modular
Euclidean certificates for every finite exceptional companion pair.
Output is canonical UTF-8/LF, independent of the host text mode.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path


Poly = tuple[int, ...]
ZERO: Poly = (0,)
ONE: Poly = (1,)

INTERVALS = {
    1: (Fraction(248, 1000), Fraction(250, 1000)),
    3: (Fraction(249, 1000), Fraction(251, 1000)),
    5: (Fraction(279, 1000), Fraction(280, 1000)),
    7: (Fraction(310, 1000), Fraction(312, 1000)),
    9: (Fraction(340, 1000), Fraction(341, 1000)),
    11: (Fraction(367, 1000), Fraction(368, 1000)),
    13: (Fraction(392, 1000), Fraction(393, 1000)),
    15: (Fraction(415, 1000), Fraction(416, 1000)),
    17: (Fraction(435, 1000), Fraction(437, 1000)),
    19: (Fraction(454, 1000), Fraction(456, 1000)),
    21: (Fraction(472, 1000), Fraction(474, 1000)),
    23: (Fraction(488, 1000), Fraction(490, 1000)),
}

EVEN_EXCEPTION_CASES = (
    (5, 0),
    (5, 2),
    (7, 0),
    (9, 0),
    (11, 0),
    (13, 0),
    (15, 0),
)
ODD_EXCEPTION_CASES = ((5, 1), (7, 1), (9, 1), (11, 1))


def trim(values: list[int]) -> Poly:
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return tuple(values)


def add(left: Poly, right: Poly) -> Poly:
    values = [0] * max(len(left), len(right))
    for index, value in enumerate(left):
        values[index] += value
    for index, value in enumerate(right):
        values[index] += value
    return trim(values)


def neg(poly: Poly) -> Poly:
    return tuple(-value for value in poly)


def sub(left: Poly, right: Poly) -> Poly:
    return add(left, neg(right))


def shift(poly: Poly, amount: int = 1, scale: int = 1) -> Poly:
    if poly == ZERO or scale == 0:
        return ZERO
    return (0,) * amount + tuple(scale * value for value in poly)


def partial(k: int, m: int) -> Poly:
    return tuple((-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1))


def pvalue(k: int, m: int, t: Fraction) -> Fraction:
    return sum(
        Fraction((-1) ** ell * math.comb(k + ell, ell)) * t**ell
        for ell in range(m + 1)
    )


def sequences(v: int) -> tuple[list[Poly], list[Poly], list[Poly]]:
    r_limit = 6 * v
    q_limit = 12 * v
    r = [ZERO for _ in range(r_limit + 1)]
    even = [ZERO for _ in range(r_limit + 1)]
    q = [ZERO for _ in range(q_limit + 1)]
    q[0] = ONE

    for m in range(r_limit + 1):
        value = ONE
        if m >= 1:
            value = sub(value, shift(r[m - 1], scale=2))
        if m >= 2:
            value = sub(value, shift(r[m - 2], amount=2))
        if m >= v:
            value = add(value, r[m - v])
        r[m] = value

        evalue = ONE
        if m >= 1:
            evalue = sub(evalue, shift(r[m - 1]))
        if m >= 2:
            evalue = sub(evalue, shift(r[m - 2], amount=2))
        even[m] = evalue

    for n in range(1, q_limit + 1):
        value = ONE if n % 2 == 0 or n >= v else ZERO
        if n >= 2:
            value = sub(value, shift(q[n - 2]))
        if n >= v:
            value = sub(value, q[n - v])
        q[n] = value
    return r, even, q


def audit_v(v: int) -> dict[str, int]:
    r, even, q = sequences(v)
    formula_checks = 0
    parity_checks = 0
    pair_checks = 0
    for m in range(5 * v):
        expected = ZERO
        for block in range(m // v + 1):
            expected = add(expected, partial(2 * block + 1, m - block * v))
        assert r[m] == expected, (v, "five_block", m)
        formula_checks += 1

    for m in range(6 * v + 1):
        assert q[2 * m] == even[m], (v, "even", m)
        if m >= 1 and v + 2 * m <= 12 * v:
            assert q[v + 2 * m] == shift(r[m - 1]), (v, "odd", m)
        parity_checks += 1

    for j in range(5 * v):
        odd_n = v + 2 * j + 4
        assert q[odd_n - 2] == shift(r[j]), (v, "odd_left", j)
        assert q[odd_n - v] == even[j + 2], (v, "odd_right", j)
        pair_checks += 1

        even_n = 2 * j + 2 * v + 2
        assert q[even_n - v] == shift(r[j]), (v, "even_left", j)
        assert q[even_n - 2] == even[j + v], (v, "even_right", j)
        pair_checks += 1
    return {
        "v": v,
        "five_block_checks": formula_checks,
        "parity_checks": parity_checks,
        "predecessor_pair_checks": pair_checks,
    }


def minimum_v(offset: int) -> int:
    return 13 if offset == 1 else max(5, offset + 2)


def rational_margins() -> dict[str, object]:
    half = Fraction(1, 2)
    small_even = []
    for offset, v0 in ((0, 17), (2, 7), (4, 5), (6, 7)):
        value = (
            Fraction(1, 1) / (1 + half) ** 2
            + pvalue(3, 3 * v0 + offset, half)
            + Fraction(1, 1) / (1 + half) ** 6
            + pvalue(7, v0 + offset, half)
            + pvalue(9, offset, half)
        )
        assert value > 0
        small_even.append(
            {"offset": offset, "minimum_v": v0, "lower_at_one_half": str(value)}
        )

    late_odd = (
        pvalue(1, 133, half)
        + Fraction(1, 1) / (1 + half) ** 4
        + pvalue(5, 79, half)
        + Fraction(1, 1) / (1 + half) ** 8
        + pvalue(9, 25, half)
    )
    assert late_odd > 0

    # At s=8 the normalized upper bound for the two negative remainders is
    # already below one; both summands decrease under s -> s+2.
    a9 = math.comb(18, 9)
    a7 = math.comb(25, 7)
    a3 = math.comb(39, 3)
    tail_base = (
        Fraction(a7, a9) * Fraction(20, 1) / 2 ** 9
        + Fraction(a3, a9) * Fraction(20, 1) / 2 ** 27
    )
    assert tail_base < 1

    roots = []
    for offset, (alpha, beta) in INTERVALS.items():
        v0 = minimum_v(offset)
        lower = (
            pvalue(1, 4 * v0 + offset, alpha)
            + Fraction(1, 1) / (1 + alpha) ** 4
            + pvalue(5, 2 * v0 + offset, alpha)
            + Fraction(1, 1) / (1 + alpha) ** 8
            + pvalue(9, offset, alpha)
        )
        upper = (
            Fraction(1, 1) / (1 + beta) ** 2
            + pvalue(3, 3 * v0 + offset, beta)
            + Fraction(1, 1) / (1 + beta) ** 6
            + pvalue(7, v0 + offset, beta)
            + pvalue(9, offset, beta)
        )
        ratio1 = (
            Fraction(4 * (v0 + 2) + offset + 2, 4 * v0 + offset + 2)
            * beta**8
        )
        ratio2 = (
            Fraction(
                math.comb(2 * (v0 + 2) + offset + 6, 5),
                math.comb(2 * v0 + offset + 6, 5),
            )
            * beta**4
        )
        odd_margin = 1 - (
            (4 * v0 + offset + 2) * beta ** (4 * v0 + offset + 2)
            + math.comb(2 * v0 + offset + 6, 5)
            * beta ** (2 * v0 + offset + 2)
            + math.comb(offset + 10, 9) * beta ** (offset + 2)
        )
        assert lower > 0 and upper < 0
        assert ratio1 < 1 and ratio2 < 1 and odd_margin > 0

        if offset == 1:
            def even_bound(t: Fraction) -> Fraction:
                return (
                    Fraction(1, 1) / (1 + t)
                    - t
                    * (
                        pvalue(2, 4 * v0, t)
                        + Fraction(1, 1) / (1 + t) ** 5
                        + pvalue(6, 2 * v0, t)
                        + Fraction(1, 1) / (1 + t) ** 9
                        + 1
                    )
                )
            expected = 1
            kind = "lower_positive"
        else:
            def even_bound(t: Fraction) -> Fraction:
                return (
                    (1 + t ** (5 * v0 + offset + 1)) / (1 + t)
                    - t
                    * (
                        Fraction(1, 1) / (1 + t) ** 3
                        + pvalue(4, 3 * v0 + offset - 1, t)
                        + Fraction(1, 1) / (1 + t) ** 7
                        + pvalue(8, v0 + offset - 1, t)
                        + pvalue(10, offset - 1, t)
                    )
                )
            expected = -1
            kind = "upper_negative"
        even_left = even_bound(alpha)
        even_right = even_bound(beta)
        assert even_left * expected > 0 and even_right * expected > 0
        roots.append(
            {
                "offset": offset,
                "minimum_v": v0,
                "alpha": str(alpha),
                "beta": str(beta),
                "lower_envelope_at_alpha": str(lower),
                "upper_envelope_at_beta": str(upper),
                "first_positive_term_v_step_ratio": str(ratio1),
                "second_positive_term_v_step_ratio": str(ratio2),
                "odd_companion_margin": str(odd_margin),
                "even_companion_bound_kind": kind,
                "even_companion_bound_at_alpha": str(even_left),
                "even_companion_bound_at_beta": str(even_right),
            }
        )
    return {
        "small_even_offset_lower_bounds": small_even,
        "even_offsets_at_least_8_normalized_tail_base": str(tail_base),
        "odd_offsets_at_least_25_lower_at_one_half": str(late_odd),
        "root_brackets": roots,
    }


def primitive_content(poly: Poly) -> int:
    result = 0
    for coefficient in poly:
        result = math.gcd(result, abs(coefficient))
    return result


def mod_trim(values: list[int], prime: int) -> list[int]:
    values = [value % prime for value in values]
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return values


def mod_monic(values: list[int], prime: int) -> list[int]:
    values = mod_trim(values, prime)
    if values == [0]:
        return values
    inverse = pow(values[-1], -1, prime)
    return [(inverse * value) % prime for value in values]


def mod_remainder(left: list[int], right: list[int], prime: int) -> list[int]:
    left = mod_trim(left[:], prime)
    right = mod_trim(right[:], prime)
    assert right != [0]
    inverse = pow(right[-1], -1, prime)
    while left != [0] and len(left) >= len(right):
        amount = len(left) - len(right)
        factor = left[-1] * inverse % prime
        for index, value in enumerate(right):
            left[index + amount] = (left[index + amount] - factor * value) % prime
        left = mod_trim(left, prime)
    return left


def mod_gcd_certificate(left: Poly, right: Poly, prime: int) -> dict[str, object]:
    assert primitive_content(left) == 1 and primitive_content(right) == 1
    assert left[-1] % prime != 0 and right[-1] % prime != 0
    a = mod_monic(list(left), prime)
    b = mod_monic(list(right), prime)
    remainders = []
    while b != [0]:
        remainder = mod_remainder(a, b, prime)
        if remainder != [0]:
            remainder = mod_monic(remainder, prime)
            remainders.append(remainder)
        a, b = b, remainder
    gcd_poly = mod_monic(a, prime)
    assert gcd_poly == [1]
    return {
        "prime": prime,
        "left_content": primitive_content(left),
        "right_content": primitive_content(right),
        "left_degree_preserved": len(left) == len(mod_trim(list(left), prime)),
        "right_degree_preserved": len(right) == len(mod_trim(list(right), prime)),
        "left_monic_coefficients_mod_p_ascending": mod_monic(list(left), prime),
        "right_monic_coefficients_mod_p_ascending": mod_monic(list(right), prime),
        "euclidean_nonzero_remainders_monic_mod_p_ascending": remainders,
        "gcd_monic_coefficients_mod_p_ascending": gcd_poly,
    }


def exceptional_certificates() -> list[dict[str, object]]:
    records = []
    for v, offset in EVEN_EXCEPTION_CASES + ODD_EXCEPTION_CASES:
        r, even, _q = sequences(v)
        j = 4 * v + offset
        for companion, poly in (("odd", even[j + 2]), ("even", even[j + v])):
            prime = 11 if (v, offset) == (5, 0) or (
                (v, offset, companion) == (5, 2, "even")
            ) else 7
            certificate = mod_gcd_certificate(r[j], poly, prime)
            certificate.update(
                {
                    "v": v,
                    "offset": offset,
                    "j": j,
                    "companion": companion,
                    "r_degree": len(r[j]) - 1,
                    "companion_degree": len(poly) - 1,
                }
            )
            records.append(certificate)
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v-max", type=int, default=251)
    parser.add_argument(
        "--output", type=Path, default=Path("predecessor_five_block_exact.json")
    )
    args = parser.parse_args()
    v_values = list(range(5, args.v_max + 1, 2))
    records = [audit_v(v) for v in v_values]
    exceptions = exceptional_certificates()
    report = {
        "schema_version": 1,
        "line_ending_and_hash_convention": "UTF-8 bytes with canonical LF newlines",
        "proof_status": "exact_audit_supporting_uniform_five_block_manuscript_proof",
        "theorem": {
            "odd_first_escape_index_at_least": "11*v+4",
            "even_first_escape_index_at_least": "12*v+2",
            "scope": "odd v>=5 and 0<t<1/2",
        },
        "audited_v_values": v_values,
        "totals": {
            "v_count": len(records),
            "five_block_checks": sum(item["five_block_checks"] for item in records),
            "parity_checks": sum(item["parity_checks"] for item in records),
            "predecessor_pair_checks": sum(
                item["predecessor_pair_checks"] for item in records
            ),
            "finite_exception_modular_gcd_certificates": len(exceptions),
        },
        "exact_rational_margins": rational_margins(),
        "finite_exception_modular_gcd_certificates": exceptions,
        "audit_window_record_shape": {
            "per_v_five_block_checks": "5*v",
            "per_v_parity_checks": "6*v+1",
            "per_v_predecessor_pair_checks": "10*v",
        },
    }
    assert len(exceptions) == 22
    payload = (json.dumps(report, indent=2, sort_keys=True) + "\n").encode("utf-8")
    args.output.write_bytes(payload)
    print(
        "PASS: exact five-block identities for "
        f"{len(records)} odd exponents through v={v_values[-1]}"
    )
    print(json.dumps(report["totals"], sort_keys=True))
    print(f"wrote canonical LF bytes to {args.output}")


if __name__ == "__main__":
    main()
