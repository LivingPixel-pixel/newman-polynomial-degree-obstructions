#!/usr/bin/env python3
"""Exact uniform prefix-positivity audit for quartic tail certificates."""

from __future__ import annotations

import argparse
from functools import lru_cache
from flint import fmpq as Fraction
import json
import math
from pathlib import Path
import sys

sys.set_int_max_str_digits(0)
Interval = tuple[Fraction, Fraction]
TAIL_START_V = 23
SCAN_M_MAX = 48
DYADIC_BITS = 64


def add(x: Interval, y: Interval) -> Interval:
    return x[0] + y[0], x[1] + y[1]


def neg(x: Interval) -> Interval:
    return -x[1], -x[0]


def sub(x: Interval, y: Interval) -> Interval:
    return add(x, neg(y))


def mul(x: Interval, y: Interval) -> Interval:
    p = x[0] * y[0], x[0] * y[1], x[1] * y[0], x[1] * y[1]
    return min(p), max(p)


def positive_pow(x: Interval, exponent: int) -> Interval:
    return x[0] ** exponent, x[1] ** exponent


def reciprocal(x: Interval) -> Interval:
    return 1 / x[1], 1 / x[0]


def polynomial_interval(coefficients: list[int], x: Interval) -> Interval:
    value = (Fraction(coefficients[-1]), Fraction(coefficients[-1]))
    for coefficient in reversed(coefficients[:-1]):
        value = add(mul(value, x), (Fraction(coefficient), Fraction(coefficient)))
    return value


def partial(k: int, m: int, a: Interval) -> Interval:
    return polynomial_interval([(-1) ** ell * math.comb(k + ell, ell) for ell in range(m + 1)], a)


@lru_cache(maxsize=None)
def reciprocal_power(j: int, a: Interval) -> Interval:
    return reciprocal(positive_pow(add((Fraction(1), Fraction(1)), a), j + 1))


def outward_dyadic(a: Interval) -> Interval:
    d = 1 << DYADIC_BITS
    lo = (a[0].numerator * d) // a[0].denominator
    hi = -((-a[1].numerator * d) // a[1].denominator)
    result = Fraction(lo, d), Fraction(hi, d)
    assert result[0] <= a[0] <= a[1] <= result[1]
    return result


def block_limit(k: int, m: int, a: Interval) -> Interval:
    top = mul(a, partial(k, m, a))
    if k % 2:
        value = top
        for j in range(1, k, 2):
            value = add(value, mul(a, reciprocal_power(j, a)))
        return value
    value = sub(reciprocal_power(0, a), top)
    for j in range(2, k, 2):
        value = sub(value, mul(a, reciprocal_power(j, a)))
    return value


def full_block_limit(k: int, a: Interval) -> Interval:
    if k % 2:
        value = (Fraction(0), Fraction(0))
        for j in range(1, k + 1, 2):
            value = add(value, mul(a, reciprocal_power(j, a)))
        return value
    value = reciprocal_power(0, a)
    for j in range(2, k + 1, 2):
        value = sub(value, mul(a, reciprocal_power(j, a)))
    return value


def first_omitted(j: int, m: int, upper: Fraction) -> Fraction | None:
    if upper * (j + m + 2) >= m + 2:
        return None
    return Fraction(math.comb(j + m + 1, m + 1)) * upper ** (m + 1)


def finite_error(k: int, m: int, upper: Fraction) -> Fraction | None:
    error = Fraction(0)
    if k % 2 == 0:
        base = (k // 2) * TAIL_START_V + 1 + m
        error += upper ** (base + 1)
    for s in range(1, (k + 1) // 2):
        j = k - 2 * s
        index = m + s * TAIL_START_V
        tail = first_omitted(j, index, upper)
        if tail is None:
            return None
        error += upper * tail
    return error


def positive_block(k: int, a: Interval) -> tuple[bool, str]:
    for m in range(SCAN_M_MAX + 1):
        limit = block_limit(k, m, a)
        error = finite_error(k, m, a[1])
        if error is None:
            return False, f"tail_not_decreasing:m={m}"
        if limit[0] - error <= 0:
            return False, f"nonpositive:m={m}"
    m = SCAN_M_MAX + 1
    top_tail = first_omitted(k, m, a[1])
    error = finite_error(k, m, a[1])
    if top_tail is None or error is None:
        return False, "eventual_tail_not_decreasing"
    if full_block_limit(k, a)[0] - a[1] * top_tail - error <= 0:
        return False, "eventual_nonpositive"
    return True, "positive"


def selected_prefix(k: int, offset: int, a: Interval) -> tuple[bool, str]:
    for m in range((offset - 2) // 2):
        limit = block_limit(k, m, a)
        error = finite_error(k, m, a[1])
        if error is None or limit[0] - error <= 0:
            return False, f"selected_prefix_failed:m={m}"
    return True, "positive"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tail", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--start", type=int, default=1, help="one-based inclusive root number")
    parser.add_argument("--end", type=int, default=None, help="one-based inclusive root number")
    args = parser.parse_args()
    tail = json.loads(args.tail.read_text(encoding="utf-8"))
    all_records = tail["records"]
    end = len(all_records) if args.end is None else args.end
    assert 1 <= args.start <= end <= len(all_records)
    selected_records = all_records[args.start - 1:end]
    records = []
    failures = []
    total_blocks = 0
    for offset, entry in enumerate(selected_records):
        number = args.start + offset
        cert = entry["certificate"]
        a = outward_dyadic((Fraction(cert["root_interval"][0]), Fraction(cert["root_interval"][1])))
        obstruction_k = int(cert["k"])
        obstruction_offset = int(cert["offset"])
        failure = None
        for k in range(1, obstruction_k):
            ok, reason = positive_block(k, a)
            total_blocks += 1
            if not ok:
                failure = {"k": k, "reason": reason}
                break
        if failure is None:
            ok, reason = selected_prefix(obstruction_k, obstruction_offset, a)
            if not ok:
                failure = {"k": obstruction_k, "reason": reason}
        status = "positive" if failure is None else "failed"
        record = {"candidate_id": entry["candidate_id"], "root_index": entry["root_index"], "obstruction_k": obstruction_k, "obstruction_offset": obstruction_offset, "status": status}
        if failure is not None:
            record["failure"] = failure
            failures.append(record)
        records.append(record)
        if number % 25 == 0 or number == end:
            print(f"{number}/{end}; failures={len(failures)}; blocks={total_blocks}", flush=True)
    report = {"schema_version": 1, "proof_status": "exact_complete_uniform_quartic_prefix", "tail_start_v": TAIL_START_V, "scan_m_max": SCAN_M_MAX, "dyadic_bits": DYADIC_BITS, "start_root": args.start, "end_root": end, "root_count": len(records), "total_blocks_checked": total_blocks, "failures": failures, "records": records}
    args.output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(json.dumps({"failures": len(failures), "total_blocks": total_blocks}, indent=2))


if __name__ == "__main__":
    main()
